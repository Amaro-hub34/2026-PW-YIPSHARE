package com.philopsychia.backend.database.driver.impl;

import com.philopsychia.backend.database.driver.DatabaseDriver;
import com.philopsychia.backend.database.driver.RowMapper;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.h2.tools.Server;

import javax.sql.DataSource;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MySQLDriver implements DatabaseDriver {

    private final HikariDataSource source;

    public MySQLDriver() {
        HikariConfig config = new HikariConfig();

        config.setJdbcUrl("jdbc:mysql://localhost:3306/yiptex?useSSL=false" +
                "&allowPublicKeyRetrieval=true" +
                "&createDatabaseIfNotExist=true");

        // Aqui modicar datos para usar la base de datos MySQL
        config.setUsername("root");
        config.setPassword("n0m310");

        config.addDataSourceProperty("cachePrepStmts", "true");
        config.addDataSourceProperty("prepStmtCacheSize", "250");
        config.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");
        config.setMaximumPoolSize(5);

        config.setDriverClassName("com.mysql.cj.jdbc.Driver");

        source = new HikariDataSource(config);
    }

    @Override
    public void initialize(List<String> schemaCommands) {
        try (Connection connection = source.getConnection()) {
            for (String schemaCommand : schemaCommands) {
                try (PreparedStatement statement = connection.prepareStatement(schemaCommand)) {
                    statement.executeUpdate();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to initialize database", e);
        }
    }

    @Override
    public <T> List<T> query(String SQL, RowMapper<T> mapper, Object... args) {
        try (Connection connection = source.getConnection();
             PreparedStatement statement = connection.prepareStatement(SQL)) {
            for (int i = 0; i < args.length; i++) {
                statement.setObject(i + 1, args[i]);
            }

            try (ResultSet set = statement.executeQuery()) {
                ArrayList<T> results = new ArrayList<>();

                while (set.next()) {
                    results.add(mapper.map(set));
                }

                return results;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Failed to run database query statement", e);
        }
    }

    @Override
    public <T> Optional<T> queryOne(String SQL, RowMapper<T> mapper, Object... args) {
        List<T> results = query(SQL, mapper, args);
        return results.stream().findFirst();
    }

    @Override
    public int update(String SQL, Object... args) {
        try (Connection connection = source.getConnection();
             PreparedStatement statement = connection.prepareStatement(SQL)) {
            for (int i = 0; i < args.length; i++) {
                statement.setObject(i + 1, args[i]);
            }

            return statement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Failed to run database update statement", e);
        }
    }

    @Override
    public void close() throws Exception {
        if (source != null && !source.isClosed()) {
            System.out.println("Closing Hikari connection pool and flushing MySQL database...");
            source.close();
        }
    }
}