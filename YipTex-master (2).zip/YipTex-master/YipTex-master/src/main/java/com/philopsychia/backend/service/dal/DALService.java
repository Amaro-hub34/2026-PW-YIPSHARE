package com.philopsychia.backend.service.dal;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.registration.dal.DALRegistration;
import com.philopsychia.backend.database.repository.*;
import com.philopsychia.backend.util.exception.BadRequestException;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.dal.DALEntityDTO;
import com.philopsychia.shared.dto.dal.DALPayloadDTO;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.schedule.ScheduleEntityDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DALService {

    private final DALRepository dalRepository;
    private final UserRepository userRepository;
    private final DeviceRepository deviceRepository;
    private final ScheduleRepository scheduleRepository;

    public DALService(DALRepository dalRepository, UserRepository userRepository, DeviceRepository deviceRepository, ScheduleRepository scheduleRepository) {
        this.dalRepository = dalRepository;
        this.userRepository = userRepository;
        this.deviceRepository = deviceRepository;
        this.scheduleRepository = scheduleRepository;
    }


    public DALEntityDTO getDALEntry(GUID id) {
        Optional<DALEntityDTO> data = dalRepository.getDALEntryById(id);
        if (data.isPresent()) return data.get();
        else throw new ResourceNotFound("Resource not found");
    }


    public List<DALEntityDTO> getAllDALEntries() {
        return dalRepository.getAllDALEntries();
    }

    public List<DALEntityDTO> getAllDALEntriesByUser(GUID userId) {
        List<DALEntityDTO> allDALEntriesByUser = dalRepository.getAllDALEntriesByUser(userId);
        return allDALEntriesByUser;
    }

    public void deleteAllDALEntriesById(GUID uuid) {
        dalRepository.deleteAllDALEntriesById(uuid);
    }

    public void createDALEntry(DALPayloadDTO dto) {
        Optional<BaseUserDTO> user = userRepository.findUserByUserId(dto.getUser_id());
        Optional<DeviceEntityDTO> device = deviceRepository.getDeviceById(dto.getDevice_id());
        if (user.isEmpty()) throw new ResourceNotFound("Invalid user_id reference");
        if (device.isEmpty()) throw new ResourceNotFound("Invalid device_id reference");

        if (dalRepository.getDALEntryByComposite(dto.getUser_id(), dto.getDevice_id(), dto.getClass_id()).isPresent())
            throw new BadRequestException("Resource already exists");

        dalRepository.registerDALEntry(new DALRegistration(
                dto.getUser_id(),
                dto.getDevice_id(),
                dto.getClass_id(),
                dto.getAssignment_reason()
        ));
    }
}
