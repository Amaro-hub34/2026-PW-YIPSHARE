package com.philopsychia.backend.database.registration.group;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.group.Schedule;
import lombok.Getter;
import lombok.Setter;

public class ClassRegistration {

    @Getter
    private final GUID id;

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private Schedule schedule;

    @Getter
    @Setter
    private GUID primary_teacher_id;

    public ClassRegistration(String name, Schedule schedule, GUID primary_teacher_id) {
        this.id = GUID.v7();
        this.name = name;
        this.schedule = schedule;
        this.primary_teacher_id = primary_teacher_id;
    }
}
