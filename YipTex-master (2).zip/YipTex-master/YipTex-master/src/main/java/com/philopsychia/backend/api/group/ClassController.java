package com.philopsychia.backend.api.group;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.service.device.DeviceService;
import com.philopsychia.backend.service.group.ClassService;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.schedule.SchedulePayloadDTO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAuthority('ADMIN')")
@RequestMapping("/api/classes")
public class ClassController {

    private final ClassService classService;

    public ClassController(ClassService classService) {
        this.classService = classService;
    }

    @PostMapping
    public void createClass(@AuthenticationPrincipal UserDetails userDetails, @RequestBody ClassPayloadDTO dto) {
        classService.createClass(dto);
    }

    @GetMapping("/{uuid}")
    public ClassEntityDTO getClass(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        return classService.getClass(uuid);
    }

    @GetMapping
    public List<ClassEntityDTO> getAllClasses(
            @AuthenticationPrincipal UserDetails userDetails,
            @RequestParam(required = false, name = "teacherId") GUID teacherId) {
        if (teacherId != null) return classService.getAllClassesByTeacher(teacherId);
        return classService.getAllClasses();
    }

    @PutMapping("/{uuid}")
    public void modifyClass(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid, @RequestBody ClassPayloadDTO dto) {
        classService.modifyClass(uuid, dto);
    }

    @DeleteMapping("/{uuid}")
    public void deleteClass(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        classService.deleteClass(uuid);
    }

}
