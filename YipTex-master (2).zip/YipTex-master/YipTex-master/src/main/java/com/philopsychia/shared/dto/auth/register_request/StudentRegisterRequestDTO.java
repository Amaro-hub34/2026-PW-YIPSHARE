package com.philopsychia.shared.dto.auth.register_request;

import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.user.Role;
import com.philopsychia.shared.dto.group.Schedule;
import lombok.Getter;
import lombok.Setter;

public class StudentRegisterRequestDTO extends NonAdminRegisterRequest {
    @Getter
    @Setter
    private long studentId;
    @Getter
    @Setter
    private String group;

    public StudentRegisterRequestDTO() {
        super();
    }

    public StudentRegisterRequestDTO(String password, String name, String paternalSurname, String maternalSurname, String institutionalEmail, long studentId, String group) {
        super(password, Role.STUDENT, name, paternalSurname, maternalSurname, institutionalEmail);
        this.studentId = studentId;
        this.group = group;
    }

    @Override
    public boolean validate() {
        return super.validate()
                &&  Regexes.groupRegex.matcher(getGroup()).matches();
    }
}
