package com.philopsychia.shared.dto.schedule;

import com.philopsychia.shared.dto.user.Role;

public enum Weekday {
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY,
    SUNDAY;

    public static Weekday parse(String value) {
        value = value.toUpperCase().trim();
        return Weekday.valueOf(value);
    }
}
