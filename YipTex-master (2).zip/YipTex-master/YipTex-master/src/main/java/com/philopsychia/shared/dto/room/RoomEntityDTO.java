package com.philopsychia.shared.dto.room;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
public class RoomEntityDTO {

    @Getter
    @Setter
    private GUID id;

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String location;

    @Getter
    @Setter
    private String acronym;

    @Getter
    @Setter
    private int device_amount;
}
