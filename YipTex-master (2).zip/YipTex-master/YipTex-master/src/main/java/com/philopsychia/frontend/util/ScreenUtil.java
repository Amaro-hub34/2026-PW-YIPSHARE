package com.philopsychia.frontend.util;

import com.philopsychia.frontend.skin.AsteriskPasswordFieldSkin;
import javafx.animation.Interpolator;
import javafx.animation.ParallelTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.TranslateTransition;
import javafx.beans.property.ObjectProperty;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.ToggleButton;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;
import org.controlsfx.control.textfield.CustomPasswordField;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;

public class ScreenUtil {

    public static final Font INCONSOLATA = Font.font("Inconsolata ExtraExpanded", FontWeight.SEMI_BOLD, null, 15);
    public static final Paint ERROR_RED = Paint.valueOf("#db1212");

    public static void initializePasswordField(CustomPasswordField passwordField) {
        ToggleButton showPassword = new ToggleButton("");
        FontIcon showIcon = new FontIcon(Feather.EYE);
        showPassword.setGraphic(showIcon);

        showPassword.setStyle("-fx-background-color: transparent; -fx-cursor: hand;");
        passwordField.setRight(showPassword);
        passwordField.setLeft(new FontIcon(Feather.LOCK));
        passwordField.skinProperty().set(new AsteriskPasswordFieldSkin(passwordField, showPassword, showIcon) {
            @Override
            public ObjectProperty<Node> leftProperty() {
                return passwordField.leftProperty();
            }

            @Override
            public ObjectProperty<Node> rightProperty() {
                return passwordField.rightProperty();
            }
        });
    }

    public static Node generateErrorMessage(String message) {
        FontIcon icon = new FontIcon(Feather.ALERT_TRIANGLE);
        icon.setIconColor(ERROR_RED);
        icon.setIconSize(15);

        Text messageText = new Text(message);
        messageText.setFont(INCONSOLATA);
        messageText.setFill(ERROR_RED);

        HBox hBox = new HBox(icon, messageText);
        hBox.setSpacing(10);
        hBox.setAlignment(Pos.CENTER);

        TranslateTransition translateTransition = new TranslateTransition(Duration.millis(400), hBox);
        translateTransition.setInterpolator(Interpolator.EASE_IN);
        translateTransition.setFromY(-10);
        translateTransition.setToY(0);

        ScaleTransition scaleTransition = new ScaleTransition(Duration.millis(400), hBox);
        scaleTransition.setInterpolator(Interpolator.EASE_IN);
        scaleTransition.setFromY(0);
        scaleTransition.setToY(1);

        new ParallelTransition(scaleTransition, translateTransition).play();
        return hBox;
    }
}
