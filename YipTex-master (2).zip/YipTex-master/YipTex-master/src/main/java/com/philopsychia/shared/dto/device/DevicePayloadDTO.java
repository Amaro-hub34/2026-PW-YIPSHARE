package com.philopsychia.shared.dto.device;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
public class DevicePayloadDTO {

    @Getter
    @Setter
    private int number_id;

    @Getter
    @Setter
    private GUID room_id;
}
