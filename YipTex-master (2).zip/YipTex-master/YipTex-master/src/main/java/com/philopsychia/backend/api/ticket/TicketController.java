package com.philopsychia.backend.api.ticket;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.service.ticket.TicketService;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.ticket.TicketEntityDTO;
import com.philopsychia.shared.dto.ticket.TicketPayloadDTO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAuthority('ADMIN')")
@RequestMapping("/api/tickets")
public class TicketController {

    private final TicketService ticketService;

    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }


    @GetMapping
    public List<TicketEntityDTO> getAllTickets(@AuthenticationPrincipal UserDetails userDetails) {
        return ticketService.getAllTickets();
    }

    @PostMapping
    public void createTicket(@AuthenticationPrincipal UserDetails userDetails, @RequestBody TicketPayloadDTO dto) {
        ticketService.createTicket(dto);
    }

    @GetMapping("/{uuid}")
    public TicketEntityDTO getTicket(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        return ticketService.getTicket(uuid);
    }

    @GetMapping("/device/{device_id}")
    public List<TicketEntityDTO> getTickets(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("device_id") GUID uuid) {
        return ticketService.getAllTicketsByDeviceId(uuid);
    }

    @GetMapping("/user/{user_id}")
    public List<TicketEntityDTO> getTicketsByUserId(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("user_id") GUID uuid) {
        return ticketService.getAllTicketsByUserId(uuid);
    }

    @PutMapping("/{uuid}")
    public void modifyTicket(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid, @RequestBody TicketPayloadDTO dto) {
        ticketService.modifyTicket(uuid, dto);
    }

    @DeleteMapping("/{uuid}")
    public void deleteTicket(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        ticketService.deleteTicket(uuid);
    }

}
