package com.philopsychia.backend.util.function;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.entity.user.*;
import com.philopsychia.shared.dto.dal.DALEntityDTO;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.Schedule;
import com.philopsychia.shared.dto.mapping_table.MappingEntryDTO;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.schedule.ScheduleEntityDTO;
import com.philopsychia.shared.dto.schedule.Weekday;
import com.philopsychia.shared.dto.ticket.Status;
import com.philopsychia.shared.dto.ticket.TicketEntityDTO;
import com.philopsychia.shared.dto.user.*;
import com.philopsychia.shared.dto.user.entity.*;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.LocalTime;

public final class DataMappingUtil {

    public static UserEntity mapDataToUserEntity(ResultSet rs) throws SQLException {
        Role role = Role.parse(rs.getString("role"));
        return switch (role) {
            case ADMIN -> new AdminUserEntity(
                    new GUID(rs.getBytes("account_id")),
                    rs.getString("account_username"),
                    rs.getString("password_hash"),
                    Role.parse(rs.getString("role"))
            );
            case STUDENT -> new StudentUserEntity(
                    new GUID(rs.getBytes("account_id")),
                    rs.getString("password_hash"),
                    role,
                    rs.getString("name"),
                    rs.getString("paternal_surname"),
                    rs.getString("maternal_surname"),
                    rs.getString("institutional_email"),
                    rs.getLong("student_id")
            );
            case TEACHER -> new TeacherUserEntity(
                    new GUID(rs.getBytes("account_id")),
                    rs.getString("password_hash"),
                    role,
                    rs.getString("name"),
                    rs.getString("paternal_surname"),
                    rs.getString("maternal_surname"),
                    rs.getString("institutional_email"),
                    rs.getString("rfc")
            );
            case TECHNICIAN -> new TechnicianUserEntity(
                    new GUID(rs.getBytes("account_id")),
                    rs.getString("password_hash"),
                    role,
                    rs.getString("name"),
                    rs.getString("paternal_surname"),
                    rs.getString("maternal_surname"),
                    rs.getString("institutional_email"),
                    rs.getString("rfc")
            );
        };
    }

    public static BaseUserDTO mapDataToUserDTO(ResultSet rs) throws SQLException {
        Role role = Role.parse(rs.getString("role"));
        return switch (role) {
            case ADMIN -> new AdminUserDTO(
                    new GUID(rs.getBytes("id")),
                    rs.getString("account_username"),
                    role
            );
            case STUDENT -> new StudentUserDTO(
                    new GUID(rs.getBytes("id")),
                    rs.getLong("student_id"),
                    rs.getString("name"),
                    rs.getString("paternal_surname"),
                    rs.getString("maternal_surname"),
                    rs.getString("institutional_email"),
                    role
            );
            case TEACHER -> new TeacherUserDTO(
                    new GUID(rs.getBytes("id")),
                    rs.getString("teacher_profile.rfc"),
                    rs.getString("name"),
                    rs.getString("paternal_surname"),
                    rs.getString("maternal_surname"),
                    rs.getString("institutional_email"),
                    role
            );
            case TECHNICIAN -> new TechnicianUserDTO(
                new GUID(rs.getBytes("id")),
                rs.getString("technician_profile.rfc"),
                rs.getString("name"),
                rs.getString("paternal_surname"),
                rs.getString("maternal_surname"),
                rs.getString("institutional_email"),
                role
        );
        };
    }

    public static RoomEntityDTO mapDataToRoomDTO(ResultSet rs) throws SQLException {
        return new RoomEntityDTO(
                new GUID(rs.getBytes("id")),
                rs.getString("name"),
                rs.getString("location"),
                rs.getString("acronym"),
                rs.getInt("device_amount")
        );
    }

    public static DeviceEntityDTO mapDataToDeviceDTO(ResultSet rs) throws SQLException {
        return new DeviceEntityDTO(
                new GUID(rs.getBytes("id")),
                rs.getInt("number_id"),
                new GUID(rs.getBytes("room_id"))
        );
    }

    public static ClassEntityDTO mapDataToClassDTO(ResultSet rs) throws SQLException {
        return new ClassEntityDTO(
                new GUID(rs.getBytes("id")),
                rs.getString("name"),
                Schedule.parse(rs.getString("schedule")),
                new GUID(rs.getBytes("primary_teacher_id"))
        );
    }

    public static ScheduleEntityDTO mapDataToScheduleDTO(ResultSet rs) throws SQLException {
        return new ScheduleEntityDTO(
                new GUID(rs.getBytes("id")),
                new GUID(rs.getBytes("class_id")),
                new GUID(rs.getBytes("room_id")),
                Weekday.parse(rs.getString("weekday")),
                rs.getObject("start_time", LocalTime.class),
                rs.getObject("end_time", LocalTime.class)
        );
    }

    public static MappingEntryDTO mapDataToMappingEntryDTO(ResultSet rs) throws SQLException {
        return new MappingEntryDTO(
                new GUID(rs.getBytes("user_id")),
                new GUID(rs.getBytes("class_id"))
        );
    }

    public static TicketEntityDTO mapDataToTicketDTO(ResultSet rs) throws SQLException {
        return new TicketEntityDTO(
                new GUID(rs.getBytes("id")),
                new GUID(rs.getBytes("created_by")),
                new GUID(rs.getBytes("device_id")),
                rs.getString("description"),
                rs.getObject("created_at", LocalDateTime.class),
                Status.parse(rs.getString("status"))
        );
    }

    public static DALEntityDTO mapDataToDALDTO(ResultSet rs) throws SQLException {
        return new DALEntityDTO(
                new GUID(rs.getBytes("id")),
                new GUID(rs.getBytes("user_id")),
                new GUID(rs.getBytes("device_id")),
                new GUID(rs.getBytes("class_id")),
                rs.getObject("assigned_at", LocalDateTime.class),
                rs.getString("assignment_reason")
        );
    }
}
