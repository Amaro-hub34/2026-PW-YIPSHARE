package com.philopsychia.shared.dto.user.payload;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

public class AdminPayloadDTO extends BasePayloadDTO {
    @Getter
    @Setter
    private String username;

    public AdminPayloadDTO() {}

    public AdminPayloadDTO(String username, Role role) {
        super(role);
        this.username = username;
    }
}
