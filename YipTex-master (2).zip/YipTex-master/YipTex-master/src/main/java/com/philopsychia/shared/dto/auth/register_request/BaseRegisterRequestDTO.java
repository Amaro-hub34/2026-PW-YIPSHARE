package com.philopsychia.shared.dto.auth.register_request;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "userType"
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = StudentRegisterRequestDTO.class, name = "student"),
        @JsonSubTypes.Type(value = TeacherRegisterRequestDTO.class, name = "teacher"),
        @JsonSubTypes.Type(value = TechnicianRegisterRequestDTO.class, name = "technician")
})
public abstract class BaseRegisterRequestDTO {
    @Getter
    @Setter
    private String password;
    @Getter
    @Setter
    private Role role;

    public BaseRegisterRequestDTO() {

    }

    public BaseRegisterRequestDTO(String password, Role role) {
        this.password = password;
        this.role = role;
    }

    public boolean validate() {
        return Regexes.passwordRegex.matcher(getPassword()).matches();
    }
}
