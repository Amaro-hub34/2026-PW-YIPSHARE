package com.philopsychia.backend.api.group;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.repository.MappingRepository;
import com.philopsychia.backend.service.auth.AuthService;
import com.philopsychia.backend.service.mapping.MappingEntryService;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.mapping_table.MappingEntryDTO;
import com.philopsychia.shared.dto.user.Role;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAuthority('ADMIN')")
@RequestMapping("/api/classes/{uuid}/auxiliary_teachers")
public class AuxiliaryTeacherClassController {

    private final MappingEntryService mappingEntryService;
    private final AuthService authService;

    public AuxiliaryTeacherClassController(MappingEntryService mappingEntryService, AuthService authService) {
        this.mappingEntryService = mappingEntryService;
        this.authService = authService;
    }

    @PostMapping
    public void registerAuxiliaryTeacherEntry(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") String uuid, @RequestBody MappingEntryDTO mappingEntryDTO) {
        mappingEntryService.createMappingEntry(mappingEntryDTO, MappingRepository.MappingTable.AUXILIARY_TEACHER_CLASS);
    }

    @GetMapping
    public List<MappingEntryDTO> getAuxiliaryTeachers(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") String uuid,
                                                       @RequestParam(required = false) GUID user_id,
                                                       @RequestParam(required = false) GUID class_id) {
        if (authService.getUserInformation(user_id).getRole() !=  Role.TEACHER) throw new ResourceNotFound("Given id did not map to a teacher");
        return mappingEntryService.getMappingEntries(user_id, class_id, MappingRepository.MappingTable.AUXILIARY_TEACHER_CLASS);
    }

    @DeleteMapping("")
    public void deleteAuxiliaryTeacherEntry(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") String uuid,
                            @RequestParam(required = false) GUID user_id,
                            @RequestParam(required = false) GUID class_id) {
        if (authService.getUserInformation(user_id).getRole() !=  Role.TEACHER) throw new ResourceNotFound("Given id did not map to a teacher");
        mappingEntryService.deleteMappingEntries(user_id, class_id, MappingRepository.MappingTable.AUXILIARY_TEACHER_CLASS);
    }

}
