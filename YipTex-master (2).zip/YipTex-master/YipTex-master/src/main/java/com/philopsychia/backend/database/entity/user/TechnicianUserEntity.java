package com.philopsychia.backend.database.entity.user;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;

public class TechnicianUserEntity extends NonAdminUserEntity {
    private final String rfc;

    public TechnicianUserEntity(GUID id,
                                String password_hash,
                                Role role,
                                String name,
                                String paternalSurname,
                                String maternalSurname,
                                String institutionalEmail,
                                String rfc) {
        super(id, password_hash, role, name, paternalSurname, maternalSurname, institutionalEmail);
        this.rfc = rfc;
    }

    public String rfc() {
        return rfc;
    }
}
