package com.philopsychia.backend.util.data;

import org.jspecify.annotations.NonNull;
import org.springframework.security.core.GrantedAuthority;

public record JwtID(String id) implements GrantedAuthority {
    @Override
    public @NonNull String getAuthority() {
        return "JWTID_"+id;
    }
}
