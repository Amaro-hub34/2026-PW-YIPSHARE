package com.philopsychia.frontend.data_store;

public record SecondPhaseRegistrationData(
        long studentId,
        String email,
        String group
) {
}
