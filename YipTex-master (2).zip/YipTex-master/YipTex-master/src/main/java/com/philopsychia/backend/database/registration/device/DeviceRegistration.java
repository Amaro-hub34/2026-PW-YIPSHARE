package com.philopsychia.backend.database.registration.device;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.Getter;
import lombok.Setter;

public class DeviceRegistration {

    @Getter
    private final GUID id;

    @Getter
    @Setter
    private int number_id;

    @Getter
    @Setter
    private GUID room_id;

    public DeviceRegistration(int number_id, GUID room_id) {
        this.id = GUID.v7();
        this.number_id = number_id;
        this.room_id = room_id;
    }
}
