package com.philopsychia.frontend.control.data_input;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IWithCallback;
import com.philopsychia.frontend.data_store.FirstPhaseRegistrationData;
import com.philopsychia.frontend.data_store.SecondPhaseRegistrationData;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ScreenUtil;
import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.auth.JwtDTO;
import com.philopsychia.shared.dto.auth.register_request.StudentRegisterRequestDTO;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import org.controlsfx.control.textfield.CustomPasswordField;
import org.springframework.core.ParameterizedTypeReference;

public class PasswordInputController extends IWithCallback<String> {

    public static final String MALFORMED_PASSWORD =
            "Su contraseña debe de ser de 6+ caracteres \ny contener una minuscula , mayuscula, \nnumero y un caracter especial";

    public static final String WRONG_CONFIRMATION =
            "Sus contraseñas no coinciden";

    public CustomPasswordField passwordField;
    public Button next;
    public CustomPasswordField passwordConfirmationField;
    public VBox passwordConfirmationVbox;
    public VBox passwordVbox;
    public Button returnButton;

    @FXML
    private void initialize() {
        ScreenUtil.initializePasswordField(passwordField);
        ScreenUtil.initializePasswordField(passwordConfirmationField);
    }

    public void returnToPrevious(MouseEvent mouseEvent) {
        Frontend.pop();
    }

    public void tryNext(MouseEvent mouseEvent) {
        cleanGUI();

        String password = passwordField.getText().trim();
        if (!Regexes.passwordRegex.matcher(password).matches()) {
            passwordVbox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_PASSWORD));
            return;
        }

        String confirmPassword = passwordConfirmationField.getText().trim();

        if (!password.equals(confirmPassword)) {
            passwordVbox.getChildren().add(ScreenUtil.generateErrorMessage(WRONG_CONFIRMATION));
            passwordConfirmationVbox.getChildren().add(ScreenUtil.generateErrorMessage(WRONG_CONFIRMATION));
            return;
        }

        this.callback.accept(password);
    }

    private void cleanGUI() {
        passwordVbox.getChildren().removeIf(node -> (node instanceof HBox));
        passwordConfirmationVbox.getChildren().removeIf(node -> (node instanceof HBox));
    }
}
