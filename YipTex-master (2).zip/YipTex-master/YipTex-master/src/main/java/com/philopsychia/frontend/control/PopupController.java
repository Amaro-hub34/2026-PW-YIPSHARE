package com.philopsychia.frontend.control;

import com.philopsychia.frontend.Frontend;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class PopupController {

    public Button ok;
    public Text message;

    public void setMessage(String message) {
        this.message.setText(message);
    }

    public void ok(MouseEvent mouseEvent) {
        Frontend.pop();
    }
}
