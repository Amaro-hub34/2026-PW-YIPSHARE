package com.philopsychia.frontend.control.teacher;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.mapping_table.MappingEntryDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.StudentUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public class AccountScreenController implements IController  {

    public Text identifier;

    public Text paternalSurnameSlot;
    public Text namesSlot;
    public Text institutionalEmail;
    public Text maternalSurnameSlot;
    public Text rfcSlot;

    @FXML
    private void initialize(){
    }

    @Override
    public void init() {

        RestClient.authorizedGetRequest(task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<BaseUserDTO> apiResponse = task.getValue();

                        if (!apiResponse.isError()) {
                            if (apiResponse.data() instanceof TeacherUserDTO teacher) {
                                identifier.setText(String.format("Prof. %s %s %s", teacher.getName(), teacher.getPaternal_surname(), teacher.getMaternal_surname()));
                                paternalSurnameSlot.setText(teacher.getPaternal_surname());
                                namesSlot.setText(teacher.getName());
                                institutionalEmail.setText(teacher.getInstitutional_email());
                                maternalSurnameSlot.setText(teacher.getMaternal_surname());
                                rfcSlot.setText(teacher.getRfc());
                            }
                        } else {
                            Frontend.pushPopup("Hubo un error inesperado");
                        }
                    });
                }, "/api/auth/me",
                new ParameterizedTypeReference<BaseUserDTO>() {});
    }
}