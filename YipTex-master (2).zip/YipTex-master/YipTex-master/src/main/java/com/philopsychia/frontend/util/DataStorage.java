package com.philopsychia.frontend.util;

import java.util.HashMap;

public class DataStorage {

    private final HashMap<String, Object> data = new HashMap<>();

    public <T> T get(String key, Class<T> clazz) {
        Object value = data.get(key);

        if (clazz.isInstance(value)) return clazz.cast(value);

        throw new ClassMismatchException("Wrong class was provided for key \"" + key + "\"");
    }

    public void clear() {
        data.clear();
    }

    public boolean has(String key) {
        return data.containsKey(key);
    }

    public void put(String key, Object value) {
        data.put(key, value);
    }

    public void remove(String key) {
        data.remove(key);
    }

    public static class ClassMismatchException extends RuntimeException {
        public ClassMismatchException(String message) {
            super(message);
        }
    }
}
