package com.philopsychia.backend.database.repository;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.driver.DatabaseDriver;
import com.philopsychia.backend.database.registration.device.DeviceRegistration;
import com.philopsychia.backend.util.function.DataMappingUtil;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.device.DevicePayloadDTO;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class DeviceRepository {

    private final DatabaseDriver databaseDriver;

    public DeviceRepository(DatabaseDriver databaseDriver) {
        this.databaseDriver = databaseDriver;
    }

    private static final String insertDevice
            = "INSERT INTO device (id, number_id, room_id) VALUES (?, ?, ?)";

    private static final String modifyDevice
            = "UPDATE device SET number_id = ?, room_id = ? WHERE id = ?";

    private static final String deleteDevice
            = "DELETE FROM device WHERE id = ?";

    private static final String getAllDevicesFromRoom
            = "SELECT * FROM device WHERE room_id = ?";

    private static final String getAllDevices
            = "SELECT * FROM device";

    private static final String getDeviceById =
            "SELECT * FROM device WHERE id = ?";

    private static final String getDeviceByNumberIdAndRoomId =
            "SELECT * FROM device WHERE number_id = ? AND room_id = ?";

    public List<DeviceEntityDTO> getAllDevicesFromRoom(GUID roomId) {
        return databaseDriver.query(
                getAllDevicesFromRoom,
                DataMappingUtil::mapDataToDeviceDTO,
                (Object) roomId.toBytes()
        );
    }

    public List<DeviceEntityDTO> getAllDevices() {
        return databaseDriver.query(
                getAllDevices,
                DataMappingUtil::mapDataToDeviceDTO
        );
    }

    public Optional<DeviceEntityDTO> getDeviceById(GUID uuid) {
        return databaseDriver.queryOne(
                getDeviceById,
                DataMappingUtil::mapDataToDeviceDTO,
                (Object) uuid.toBytes()
        );
    }

    public Optional<DeviceEntityDTO> getDeviceByNumberIdAndRoom(int number_id, GUID room_id) {
        return databaseDriver.queryOne(
                getDeviceByNumberIdAndRoomId,
                DataMappingUtil::mapDataToDeviceDTO,
                number_id,
                room_id.toBytes()
        );
    }

    public void registerDevice(DeviceRegistration deviceRegistration) {
        databaseDriver.update(
                insertDevice,
                deviceRegistration.getId().toBytes(),
                deviceRegistration.getNumber_id(),
                deviceRegistration.getRoom_id().toBytes()
        );
    }

    public void modifyDevice(GUID id,  DevicePayloadDTO payload) {
        databaseDriver.update(
                modifyDevice,
                payload.getNumber_id(),
                payload.getRoom_id().toBytes(),
                id.toBytes()
        );
    }

    public void deleteDevice(GUID id) {
        databaseDriver.update(
                deleteDevice,
                (Object) id.toBytes()
        );
    }
}
