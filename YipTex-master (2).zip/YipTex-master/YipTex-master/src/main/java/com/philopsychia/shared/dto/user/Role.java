package com.philopsychia.shared.dto.user;

import org.jspecify.annotations.NonNull;
import org.springframework.security.core.GrantedAuthority;

public enum Role implements GrantedAuthority {
    ADMIN,
    STUDENT,
    TEACHER,
    TECHNICIAN;

    public static Role parse(String value) {
        value = value.toUpperCase().trim();
        return Role.valueOf(value);
    }

    @Override
    public @NonNull String getAuthority() {
        return this.name();
    }
}
