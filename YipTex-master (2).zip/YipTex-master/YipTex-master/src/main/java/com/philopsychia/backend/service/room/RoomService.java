package com.philopsychia.backend.service.room;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.api.device.DeviceController;
import com.philopsychia.backend.database.registration.room.RoomRegistration;
import com.philopsychia.backend.database.repository.RoomRepository;
import com.philopsychia.backend.service.device.DeviceService;
import com.philopsychia.backend.util.exception.BadRequestException;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.device.DevicePayloadDTO;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.room.RoomPayloadDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoomService {

    private final RoomRepository roomRepository;
    private final DeviceService deviceService;

    public RoomService(RoomRepository roomRepository, DeviceService deviceService) {
        this.roomRepository = roomRepository;
        this.deviceService = deviceService;
    }

    public RoomEntityDTO getRoom(GUID uuid) {
        Optional<RoomEntityDTO> data = roomRepository.getRoomById(uuid);
        if (data.isPresent()) return data.get();
        else throw new ResourceNotFound("Resource not found");
    }

    public void modifyRoom(GUID uuid, RoomPayloadDTO dto) {
        if (roomRepository.getRoomById(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        Optional<RoomEntityDTO> roomByName = roomRepository.getRoomByName(dto.getName());
        Optional<RoomEntityDTO> roomByAcronym = roomRepository.getRoomByAcronym(dto.getAcronym());
        if ((roomByName.isPresent() && !roomByName.get().getId().equals(uuid))
                || (roomByAcronym.isPresent() && !roomByAcronym.get().getId().equals(uuid)))
            throw new BadRequestException("Resource already exists");
        roomRepository.modifyRoom(uuid, dto);

        int max = -1;
        for (DeviceEntityDTO device : deviceService.getAllDevices(uuid)) {
            if (device.getNumber_id() > max)
                max = device.getNumber_id();
            if (device.getNumber_id() > dto.getDevice_amount())
                deviceService.deleteDevice(device.getId());
        }

        for (int i = max+1; i <= dto.getDevice_amount(); i++) {
            deviceService.createDevice(new DevicePayloadDTO(
                    i,
                    uuid
            ));
        }
    }

    public void deleteRoom(GUID uuid) {
        if (roomRepository.getRoomById(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        roomRepository.deleteRoom(uuid);
    }

    public List<RoomEntityDTO> getAllRooms() {
        return roomRepository.getAllRooms();
    }

    public List<RoomEntityDTO> getAllRoomsByTeacher(GUID uuid) {
        return roomRepository.getAllRoomsByTeacher(uuid);
    }

    public void createRoom(RoomPayloadDTO dto) {
        if (!(roomRepository.getRoomByName(dto.getName()).isEmpty()
                && roomRepository.getRoomByAcronym(dto.getAcronym()).isEmpty()))
            throw new BadRequestException("Resource already exists");
        RoomRegistration roomRegistration = new RoomRegistration(
                dto.getName(),
                dto.getLocation(),
                dto.getAcronym(),
                dto.getDevice_amount());
        roomRepository.registerRoom(roomRegistration);

        for (int i = 1; i <= roomRegistration.getDevice_amount(); i++) {
            deviceService.createDevice(new DevicePayloadDTO(
                    i,
                    roomRegistration.getId()
            ));
        }

    }
}
