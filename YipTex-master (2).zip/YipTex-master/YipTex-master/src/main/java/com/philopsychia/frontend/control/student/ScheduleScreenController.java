package com.philopsychia.frontend.control.student;

import com.calendarfx.model.Calendar;
import com.calendarfx.model.CalendarSource;
import com.calendarfx.model.Entry;
import com.calendarfx.view.DetailedWeekView;
import com.calendarfx.view.WeekDayHeaderView;
import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.schedule.ScheduleEntityDTO;
import com.philopsychia.shared.dto.schedule.SchedulePayloadDTO;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.input.MouseEvent;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.TextStyle;
import java.time.temporal.TemporalAdjusters;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ScheduleScreenController implements IController  {

    private static final DateTimeFormatter genericDayFormatter;

    static {
        Locale targetLocale = Locale.forLanguageTag("es");

        Map<Long, String> capitalizedDays = new HashMap<>();
        for (DayOfWeek day : DayOfWeek.values()) {
            String standardDay = day.getDisplayName(TextStyle.FULL, targetLocale);

            String capitalized = standardDay.substring(0, 1).toUpperCase(targetLocale)
                    + standardDay.substring(1);

            capitalizedDays.put((long) day.getValue(), capitalized);
        }

        genericDayFormatter = new DateTimeFormatterBuilder()
                .appendText(java.time.temporal.ChronoField.DAY_OF_WEEK, capitalizedDays)
                .toFormatter(targetLocale);
    }

    public Button newButton;
    public DetailedWeekView weekView;

    private final Calendar<ScheduleEntityDTO> calendar = new Calendar<>();

    @FXML
    private void initialize(){
        weekView.setNumberOfDays(5);
        weekView.setWeekFields(java.time.temporal.WeekFields.of(DayOfWeek.MONDAY, 1));
        weekView.getWeekView().setAdjustToFirstDayOfWeek(true);

        LocalDate constantMonday = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        weekView.setDate(constantMonday);

        WeekDayHeaderView weekDayHeaderView = weekView.getWeekDayHeaderView();
        weekDayHeaderView
                .setCellFactory(date -> {
                    WeekDayHeaderView.WeekDayHeaderCell weekDayHeaderCell = new WeekDayHeaderView.WeekDayHeaderCell(weekDayHeaderView);
                    weekDayHeaderCell.setFormatter(genericDayFormatter);
                    return weekDayHeaderCell;
                });

        weekView.setEntryEditPolicy(param -> false);
        weekView.setEntryDetailsPopOverContentCallback(param -> null);
        weekView.setEntryDetailsCallback(param -> null);
        weekView.setEntryContextMenuCallback(param -> null);
        weekView.setContextMenuCallback(null);
    }

    @Override
    public void init() {
        calendar.clear();

        RestClient.authorizedGetRequest(task -> {
            Frontend.loadingOverlay.bindToTask(task);
            task.setOnSucceeded(event -> {
                ApiResponse<List<ScheduleEntityDTO>> apiResponse = task.getValue();

                if (apiResponse.isError()) {
                    Frontend.pushPopup("Hubo un error inesperado");
                } else {

                    LocalDate anchorMonday = LocalDate.now().with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));

                    List<ScheduleEntityDTO> data = apiResponse.data();

                    for (ScheduleEntityDTO dto : data) {
                        DayOfWeek targetDay = DayOfWeek.valueOf(dto.getWeekday().name().toUpperCase());

                        LocalDate eventDate = anchorMonday.with(TemporalAdjusters.nextOrSame(targetDay));

                        LocalDateTime startDateTime = LocalDateTime.of(eventDate, dto.getStart_time());
                        LocalDateTime endDateTime = LocalDateTime.of(eventDate, dto.getEnd_time());

                        RestClient.authorizedGetRequest(t -> {
                                    Frontend.loadingOverlay.bindToTask(t);
                                    t.setOnSucceeded(e -> {
                                        ApiResponse<ClassEntityDTO> apiResponseClass = t.getValue();

                                        if (apiResponseClass.isError()) {
                                            Frontend.pushPopup("Hubo un error inesperado");
                                        } else {
                                            RestClient.authorizedGetRequest(
                                                    t2 -> {
                                                        Frontend.loadingOverlay.bindToTask(t2);
                                                        t2.setOnSucceeded(e2 -> {
                                                            ApiResponse<RoomEntityDTO> apiResponseRoom = t2.getValue();

                                                            if (apiResponseRoom.isError()) {
                                                                Frontend.pushPopup("Hubo un error inesperado");
                                                            } else {
                                                                Entry<ScheduleEntityDTO> entry = new Entry<>(apiResponseClass.data().getName() + " - " + apiResponseRoom.data().getName());
                                                                entry.setInterval(startDateTime, endDateTime);

                                                                entry.setUserObject(dto);

                                                                calendar.addEntry(entry);
                                                            }
                                                        });
                                                    }, "/api/rooms/{id}",
                                                    new ParameterizedTypeReference<RoomEntityDTO>() {},
                                                    dto.getRoom_id()
                                            );
                                        }
                                    });
                                }, "/api/classes/{id}",
                                new ParameterizedTypeReference<ClassEntityDTO>() {},
                                dto.getClass_id());
                    }

                    calendar.setReadOnly(true);
                    CalendarSource source = new CalendarSource("Horario");
                    source.getCalendars().add(calendar);
                    weekView.getCalendarSources().add(source);
                }
            });
        }, "/api/schedule",
                new ParameterizedTypeReference<List<ScheduleEntityDTO>>() {});

    }
}