package com.philopsychia.frontend.control.student;

import com.philopsychia.frontend.Frontend;
import javafx.fxml.FXML;
import javafx.scene.text.Text;

public class HomeScreenController {
    public Text welcomeText;

    @FXML
    private void initialize() {
        welcomeText.setText("Bienvenido, " + Frontend.dataStorage.get("account_identifier", String.class));
    }
}
