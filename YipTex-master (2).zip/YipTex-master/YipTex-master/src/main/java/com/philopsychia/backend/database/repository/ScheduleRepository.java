package com.philopsychia.backend.database.repository;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.driver.DatabaseDriver;
import com.philopsychia.backend.database.registration.schedule.ScheduleRegistration;
import com.philopsychia.backend.util.function.DataMappingUtil;
import com.philopsychia.shared.dto.schedule.ScheduleEntityDTO;
import com.philopsychia.shared.dto.schedule.SchedulePayloadDTO;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ScheduleRepository {

    private final DatabaseDriver databaseDriver;

    public ScheduleRepository(DatabaseDriver databaseDriver) {
        this.databaseDriver = databaseDriver;
    }

    private static final String insertScheduleEntry
            = "INSERT INTO schedule (id, class_id, room_id, weekday, start_time, end_time) VALUES (?, ?, ?, ?, ?, ?)";

    private static final String modifyScheduleEntry
            = "UPDATE schedule SET class_id = ?, room_id = ?, weekday = ?, start_time = ?, end_time = ? WHERE id = ?";

    private static final String deleteScheduleEntry
            = "DELETE FROM schedule WHERE id = ?";

    private static final String getAllScheduleEntries =
            "SELECT * FROM schedule";

    private static final String getScheduleEntryById =
            "SELECT * FROM schedule WHERE id = ?";

    public List<ScheduleEntityDTO> getAllScheduleEntries() {
        return databaseDriver.query(
                getAllScheduleEntries,
                DataMappingUtil::mapDataToScheduleDTO
        );
    }

    public Optional<ScheduleEntityDTO> getScheduleEntryById(GUID uuid) {
        return databaseDriver.queryOne(
                getScheduleEntryById,
                DataMappingUtil::mapDataToScheduleDTO,
                (Object) uuid.toBytes()
        );
    }

    public void registerScheduleEntry(ScheduleRegistration scheduleRegistration) {
        databaseDriver.update(
                insertScheduleEntry,
                scheduleRegistration.getId().toBytes(),
                scheduleRegistration.getClass_id().toBytes(),
                scheduleRegistration.getRoom_id().toBytes(),
                scheduleRegistration.getWeekday().name(),
                scheduleRegistration.getStart_time(),
                scheduleRegistration.getEnd_time()
        );
    }

    public void modifyScheduleEntry(GUID id,  SchedulePayloadDTO payload) {
        databaseDriver.update(
                modifyScheduleEntry,
                payload.getClass_id().toBytes(),
                payload.getRoom_id().toBytes(),
                payload.getWeekday().name(),
                payload.getStart_time(),
                payload.getEnd_time(),
                id.toBytes()
        );
    }

    public void deleteScheduleEntry(GUID id) {
        databaseDriver.update(
                deleteScheduleEntry,
                (Object) id.toBytes()
        );
    }
}
