package com.philopsychia.backend.database.registration.user;

import com.philopsychia.shared.dto.user.Role;

public class TechnicianUserRegistration extends NonAdminUserRegistration {
    private final String rfc;

    public TechnicianUserRegistration(String password_hash,
                                      Role role,
                                      String name,
                                      String paternalSurname,
                                      String maternalSurname,
                                      String institutionalEmail,
                                      String rfc) {
        super(password_hash, role, name, paternalSurname, maternalSurname, institutionalEmail);
        this.rfc = rfc;
    }

    public String rfc() {
        return rfc;
    }
}
