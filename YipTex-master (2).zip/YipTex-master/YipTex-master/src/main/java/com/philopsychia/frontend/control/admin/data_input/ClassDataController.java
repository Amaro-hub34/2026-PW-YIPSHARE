package com.philopsychia.frontend.control.admin.data_input;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.control.util.IWithCallback;
import com.philopsychia.frontend.control.util.IWithLoadFunction;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ScreenUtil;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.group.Schedule;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.room.RoomPayloadDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import org.controlsfx.control.textfield.CustomTextField;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;

import java.util.List;

public class ClassDataController extends IWithCallback<ClassPayloadDTO> implements IWithLoadFunction<ClassEntityDTO>, IController {

    private static final String INVALID_NUMBER = "El numero ingresado es invalido";
    private static final String MALFORMED_CLASS_ID = "La clave no es valida";
    private static final String INVALID_SELECTION = "Seleccione una opcion";

    public GridPane gridContainer;
    public Button returnButton;

    public VBox scheduleVBox;
    public ChoiceBox<String> scheduleField;
    public VBox teacherVBox;
    public ChoiceBox<String> teacherField;
    public Button next;
    public CustomTextField classIdField;
    public VBox classIdVbox;

    private List<GUID> teacherIds = new ObjectArrayList<>();
    private Task<ApiResponse<List<BaseUserDTO>>> task;

    @FXML
    private void initialize() {
    }

    public void tryNext(MouseEvent mouseEvent) {
        cleanGUI();

        boolean passed = true;

        String classId = classIdField.getText().trim();
        if (!Regexes.groupRegex.matcher(classId).matches()) {
            classIdVbox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_CLASS_ID));
            passed = false;
        }

        int teacherSelection  = teacherField.getSelectionModel().getSelectedIndex();
        if (teacherSelection == 0) {
            teacherVBox.getChildren().add(ScreenUtil.generateErrorMessage(INVALID_SELECTION));
            passed = false;
        }

        int scheduleSelection = scheduleField.getSelectionModel().getSelectedIndex();
        if (scheduleSelection == 0) {
            scheduleVBox.getChildren().add(ScreenUtil.generateErrorMessage(INVALID_SELECTION));
            passed = false;
        }

        if (!passed) return;

        this.callback.accept(new ClassPayloadDTO(
                classId,
                scheduleSelection == 1 ? Schedule.MORNING : Schedule.EVENING,
                teacherIds.get(teacherSelection-1)
        ));
    }

    public void returnToPrevious(MouseEvent mouseEvent) {
        Frontend.pop();
    }

    private void cleanGUI() {
        classIdVbox.getChildren().removeIf(node -> (node instanceof HBox));
        teacherVBox.getChildren().removeIf(node -> (node instanceof HBox));
        scheduleVBox.getChildren().removeIf(node -> (node instanceof HBox));
    }

    @Override
    public void init() {

        teacherField.getItems().addAll("Seleccione un profesor");

        task = RestClient.authorizedGetRequest(
                task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<List<BaseUserDTO>> apiResponse = task.getValue();

                        if (apiResponse.isError()) {
                            ViewLoader.generatePopup("Hubo un error insperado");
                        } else {
                            int i = 0;
                            List<TeacherUserDTO> users = apiResponse.data().stream()
                                    .filter(x -> x instanceof TeacherUserDTO)
                                    .map(x -> (TeacherUserDTO) x).toList();

                            for (TeacherUserDTO teacher : users) {
                                i++;

                                teacherIds.add(teacher.getId());
                                teacherField.getItems().add(String.format(
                                        "%s %s %s", teacher.getName(), teacher.getPaternal_surname(), teacher.getMaternal_surname()
                                ));
                            }
                        }
                    });
                }, "/api/users",
                new ParameterizedTypeReference<List<BaseUserDTO>>() {}
        );

        scheduleField.getItems().addAll(
                "Seleccione un turno",
                "Matutino",
                "Vespertino"
        );

        teacherField.getSelectionModel().select(0);
        scheduleField.getSelectionModel().select(0);
    }

    @Override
    public void load(ClassEntityDTO input) {
        if (input == null) return;
        EventHandler<WorkerStateEvent> e = task.getOnSucceeded();
        task.setOnSucceeded(event -> {
            e.handle(event);
            classIdField.setText(input.getName());
            scheduleField.getSelectionModel().select(switch (input.getSchedule()) {
                case MORNING -> 1;
                case EVENING -> 2;
            });
            int index = this.teacherIds.indexOf(input.getPrimary_teacher_id());
            teacherField.getSelectionModel().select(
                    index+1
            );
        });

    }
}
