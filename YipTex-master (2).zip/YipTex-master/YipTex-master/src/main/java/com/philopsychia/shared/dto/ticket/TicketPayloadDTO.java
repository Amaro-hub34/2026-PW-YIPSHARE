package com.philopsychia.shared.dto.ticket;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@NoArgsConstructor
@AllArgsConstructor
public class TicketPayloadDTO {

    @Getter
    @Setter
    private GUID created_by;

    @Getter
    @Setter
    private GUID device_id;

    @Getter
    @Setter
    private String description;

    @Getter
    @Setter
    private Status status;
}
