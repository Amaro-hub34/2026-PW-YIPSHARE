package com.philopsychia.frontend.control;

import com.philopsychia.frontend.Frontend;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class TicketPopupController {

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");


    public Text hourDisplay;
    public Text description;
    public Button ok;

    public void setDescription(String description) {
        this.description.setText(description);
    }

    public void setTime(LocalDateTime time) {
        this.hourDisplay.setText(time.format(formatter));
    }

    public void ok(MouseEvent mouseEvent) {
        Frontend.pop();
    }
}
