package com.philopsychia.backend.database.entity.user;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;

public abstract class NonAdminUserEntity extends UserEntity {
    private final String name;
    private final String paternal_surname;
    private final String maternal_surname;
    private final String institutional_email;

    public NonAdminUserEntity(GUID id, String password_hash, Role role, String name, String paternalSurname, String maternalSurname, String institutionalEmail) {
        super(id, password_hash, role);
        this.name = name;
        paternal_surname = paternalSurname;
        maternal_surname = maternalSurname;
        institutional_email = institutionalEmail;
    }

    public String name() {
        return name;
    }

    public String paternal_surname() {
        return paternal_surname;
    }

    public String maternal_surname() {
        return maternal_surname;
    }

    public String institutional_email() {
        return institutional_email;
    }
}
