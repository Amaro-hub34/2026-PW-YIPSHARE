package com.philopsychia.shared.dto.user.entity;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "userType"
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = StudentUserDTO.class, name = "student"),
        @JsonSubTypes.Type(value = TeacherUserDTO.class, name = "teacher"),
        @JsonSubTypes.Type(value = TechnicianUserDTO.class, name = "technician"),
        @JsonSubTypes.Type(value = AdminUserDTO.class, name = "admin")
})
public abstract class BaseUserDTO {

    @Getter
    @Setter
    private GUID id;

    @Getter
    @Setter
    private Role role;

    public BaseUserDTO() {}

    public BaseUserDTO(
            GUID id,
            Role role) {
        this.id = id;
        this.role = role;
    }
}