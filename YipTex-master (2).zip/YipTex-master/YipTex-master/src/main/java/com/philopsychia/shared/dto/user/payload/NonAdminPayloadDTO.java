package com.philopsychia.shared.dto.user.payload;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

public abstract class NonAdminPayloadDTO extends BasePayloadDTO {
    @Getter
    @Setter
    private String name;
    @Getter
    @Setter
    private String paternal_surname;
    @Getter
    @Setter
    private String maternal_surname;
    @Getter
    @Setter
    private String institutional_email;

    public NonAdminPayloadDTO() {}

    public NonAdminPayloadDTO(String name, String paternal_surname, String maternal_surname, String institutional_email, Role role) {
        super(role);
        this.name = name;
        this.paternal_surname = paternal_surname;
        this.maternal_surname = maternal_surname;
        this.institutional_email = institutional_email;
    }
}
