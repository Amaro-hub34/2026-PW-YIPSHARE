package com.philopsychia.backend.database.registration.schedule;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.schedule.Weekday;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalTime;

public class ScheduleRegistration {

    @Getter
    private final GUID id;

    @Getter
    @Setter
    private GUID class_id;

    @Getter
    @Setter
    private GUID room_id;

    @Getter
    @Setter
    private Weekday weekday;

    @Getter
    @Setter
    private LocalTime start_time;

    @Getter
    @Setter
    private LocalTime end_time;

    public ScheduleRegistration(LocalTime end_time, LocalTime start_time, Weekday weekday, GUID room_id, GUID class_id) {
        this.id = GUID.v7();
        this.end_time = end_time;
        this.start_time = start_time;
        this.weekday = weekday;
        this.room_id = room_id;
        this.class_id = class_id;
    }

}
