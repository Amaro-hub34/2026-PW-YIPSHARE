package com.philopsychia.shared.dto.user.payload;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

@JsonTypeInfo(
        use = JsonTypeInfo.Id.NAME,
        include = JsonTypeInfo.As.PROPERTY,
        property = "userType"
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = StudentPayloadDTO.class, name = "student"),
        @JsonSubTypes.Type(value = TeacherPayloadDTO.class, name = "teacher"),
        @JsonSubTypes.Type(value = TechnicianPayloadDTO.class, name = "technician"),
        @JsonSubTypes.Type(value = AdminPayloadDTO.class, name = "admin")
})
public abstract class BasePayloadDTO {


    @Getter
    @Setter
    private Role role;

    public BasePayloadDTO() {}

    public BasePayloadDTO(
            Role role) {
        this.role = role;
    }
}