package com.philopsychia.frontend.util;

import com.philopsychia.frontend.control.ConfirmationController;
import com.philopsychia.frontend.control.PopupController;
import com.philopsychia.frontend.control.TicketPopupController;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.control.util.IWithCallback;
import com.philopsychia.frontend.control.util.IWithLoadFunction;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Paint;
import javafx.scene.text.Text;

import java.io.InputStream;
import java.time.LocalDateTime;
import java.util.function.Consumer;

public class ViewLoader {


    public static Parent loadView(String name) {
        try (InputStream viewStream = ViewLoader.class.getClassLoader().getResourceAsStream("view/"+name+".fxml")){
            FXMLLoader loader = new FXMLLoader();
            Parent node = loader.load(viewStream);

            Object controller =  loader.getController();
            if (controller instanceof IController icontroller) icontroller.init();

            return node;
        } catch (Exception e) {
            e.printStackTrace();
            return errorView(name);
        }
    }

    public static Parent generatePopup(String message) {
        try (InputStream viewStream = ViewLoader.class.getClassLoader().getResourceAsStream("view/popup.fxml")){
            FXMLLoader loader = new FXMLLoader();
            Parent node = loader.load(viewStream);

            Object controller =  loader.getController();
            if (controller instanceof PopupController popupController) popupController.setMessage(message);

            return node;
        } catch (Exception e) {
            e.printStackTrace();
            return errorView("popup");
        }
    }

    public static Parent generateTicketPopup(String description, LocalDateTime time) {
        try (InputStream viewStream = ViewLoader.class.getClassLoader().getResourceAsStream("view/ticket_popup.fxml")){
            FXMLLoader loader = new FXMLLoader();
            Parent node = loader.load(viewStream);

            Object controller =  loader.getController();
            if (controller instanceof TicketPopupController ticketController) {
                ticketController.setDescription(description);
                ticketController.setTime(time);
            }

            return node;
        } catch (Exception e) {
            e.printStackTrace();
            return errorView("ticket_popup");
        }
    }

    public static Parent generateConfirmationScreen(String message, Runnable callback) {
        try (InputStream viewStream = ViewLoader.class.getClassLoader().getResourceAsStream("view/confirmation.fxml")){
            FXMLLoader loader = new FXMLLoader();
            Parent node = loader.load(viewStream);

            Object controller =  loader.getController();
            if (controller instanceof ConfirmationController confirmationController) {
                confirmationController.setMessage(message);
                confirmationController.setCallback(callback);
            }

            return node;
        } catch (Exception e) {
            e.printStackTrace();
            return errorView("confirmation");
        }
    }

    public static <T, U> Parent loadScreenWithIO(String id, Consumer<T> callback, U loadData) {
        try (InputStream viewStream = ViewLoader.class.getClassLoader().getResourceAsStream("view/"+id+".fxml")){
            FXMLLoader loader = new FXMLLoader();
            Parent node = loader.load(viewStream);

            Object controller =  loader.getController();

            if (controller instanceof IController iController) {
                iController.init();
            }

            if (controller instanceof IWithCallback) {
                @SuppressWarnings("unchecked")
                IWithCallback<T> withCallback = (IWithCallback<T>) controller;
                withCallback.setCallback(callback);
            }

            if (controller instanceof IWithLoadFunction) {
                @SuppressWarnings("unchecked")
                IWithLoadFunction<U> withInput = (IWithLoadFunction<U>) controller;
                withInput.load(loadData);
            }

            return node;
        } catch (Exception e) {
            e.printStackTrace();
            return errorView(id);
        }
    }

    private static Parent errorView(String name){
        StackPane pane = new StackPane();
        pane.setPrefSize(600,400);

        Text error_text = new Text("Failed to load view \"" + name + "\"");
        error_text.setFill(Paint.valueOf("#a63535"));

        pane.getChildren().add(error_text);
        return pane;
    }
}
