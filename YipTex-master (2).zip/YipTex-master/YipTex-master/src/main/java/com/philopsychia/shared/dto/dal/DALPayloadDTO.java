package com.philopsychia.shared.dto.dal;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
public class DALPayloadDTO {

    @Getter
    @Setter
    private GUID user_id;

    @Getter
    @Setter
    private GUID device_id;

    @Getter
    @Setter
    private GUID class_id;

    @Getter
    @Setter
    private String assignment_reason;

    public boolean validate() {return true;}
}
