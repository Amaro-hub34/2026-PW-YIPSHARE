package com.philopsychia.frontend.data_store;

public record FirstPhaseRegistrationData(String name,
                                         String paternalSurname,
                                         String maternalSurname) {
}
