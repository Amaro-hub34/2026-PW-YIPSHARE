package com.philopsychia.backend.util.function;

import com.github.f4b6a3.uuid.alt.GUID;
import org.jspecify.annotations.NonNull;
import org.springframework.core.convert.converter.Converter;

public class StringToGUIDConverter implements Converter<String, GUID> {
    @Override
    public GUID convert(@NonNull String source) {
        return new GUID(source);
    }
}
