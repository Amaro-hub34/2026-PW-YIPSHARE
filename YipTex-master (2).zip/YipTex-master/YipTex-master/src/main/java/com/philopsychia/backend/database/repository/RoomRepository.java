package com.philopsychia.backend.database.repository;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.driver.DatabaseDriver;
import com.philopsychia.backend.database.registration.room.RoomRegistration;
import com.philopsychia.backend.util.function.DataMappingUtil;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.room.RoomPayloadDTO;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class RoomRepository {

    private final DatabaseDriver databaseDriver;

    public RoomRepository(DatabaseDriver databaseDriver) {
        this.databaseDriver = databaseDriver;
    }
    
    private static final String insertRoom
            = "INSERT INTO room (id, name, location, acronym, device_amount) VALUES (?, ?, ?, ?, ?)";

    private static final String modifyRoom
            = "UPDATE room SET name = ?, location = ?, acronym = ?, device_amount = ? WHERE id = ?";

    private static final String deleteRoom
            = "DELETE FROM room WHERE id = ?";

    private static final String getAllRooms =
            "SELECT * FROM room";

    private static final String getRoomById =
            "SELECT * FROM room WHERE id = ?";

    private static final String getRoomByName =
            "SELECT * FROM room WHERE name = ?";

    private static final String getRoomByAcronym =
            "SELECT * FROM room WHERE acronym = ?";

    private static final String getRoomsByTeacher =
            """
            SELECT DISTINCT
                r.id,
                r.name,
                r.location,
                r.acronym,
                r.device_amount
            FROM schedule s
            INNER JOIN class c ON s.class_id = c.id
            INNER JOIN room r ON s.room_id = r.id
            WHERE c.primary_teacher_id = ?;
            """;

    public List<RoomEntityDTO> getAllRooms() {
        return databaseDriver.query(
                getAllRooms,
                DataMappingUtil::mapDataToRoomDTO
        );
    }

    public List<RoomEntityDTO> getAllRoomsByTeacher(GUID teacher) {
        return databaseDriver.query(
                getRoomsByTeacher,
                DataMappingUtil::mapDataToRoomDTO,
                (Object) teacher.toBytes()
        );
    }

    public Optional<RoomEntityDTO> getRoomById(GUID uuid) {
        return databaseDriver.queryOne(
                getRoomById,
                DataMappingUtil::mapDataToRoomDTO,
                (Object) uuid.toBytes()
        );
    }

    public Optional<RoomEntityDTO> getRoomByName(String name) {
        return databaseDriver.queryOne(
                getRoomByName,
                DataMappingUtil::mapDataToRoomDTO,
                name
        );
    }

    public Optional<RoomEntityDTO> getRoomByAcronym(String acronym) {
        return databaseDriver.queryOne(
                getRoomByAcronym,
                DataMappingUtil::mapDataToRoomDTO,
                acronym
        );
    }

    public void registerRoom(RoomRegistration roomRegistration) {
        databaseDriver.update(
                insertRoom,
                roomRegistration.getId().toBytes(),
                roomRegistration.getName(),
                roomRegistration.getLocation(),
                roomRegistration.getAcronym(),
                roomRegistration.getDevice_amount()
        );
    }

    public void modifyRoom(GUID id,  RoomPayloadDTO payload) {
        databaseDriver.update(
                modifyRoom,
                payload.getName(),
                payload.getLocation(),
                payload.getAcronym(),
                payload.getDevice_amount(),
                id.toBytes()
        );
    }

    public void deleteRoom(GUID id) {
        databaseDriver.update(
                deleteRoom,
                (Object) id.toBytes()
        );
    }
}
