package com.philopsychia.shared.dto.group;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
public class ClassPayloadDTO {

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private Schedule schedule;

    @Getter
    @Setter
    private GUID primary_teacher_id;

}
