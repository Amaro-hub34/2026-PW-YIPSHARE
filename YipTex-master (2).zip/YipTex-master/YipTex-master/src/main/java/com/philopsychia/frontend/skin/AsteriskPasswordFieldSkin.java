package com.philopsychia.frontend.skin;

import impl.org.controlsfx.skin.CustomTextFieldSkin;
import javafx.scene.control.ToggleButton;
import org.controlsfx.control.textfield.CustomPasswordField;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;

public abstract class AsteriskPasswordFieldSkin extends CustomTextFieldSkin {
    private final ToggleButton toggleButton;

    public AsteriskPasswordFieldSkin(CustomPasswordField control, ToggleButton toggleButton, FontIcon icon) {
        super(control);
        this.toggleButton = toggleButton;


        toggleButton.selectedProperty().addListener((_, _, newValue) -> {
           String text = control.getText();
           control.setText(null);
           control.setText(text);

           if (newValue) {
               icon.setIconCode(Feather.EYE_OFF);
           } else {
               icon.setIconCode(Feather.EYE);
           }
        });
    }

    @Override
    protected String maskText(String s) {

        if (toggleButton != null && toggleButton.isSelected()) {
            return s;
        }

        return "*".repeat(s.length());
    }
}
