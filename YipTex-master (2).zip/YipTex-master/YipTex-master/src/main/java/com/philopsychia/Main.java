package com.philopsychia;

import com.philopsychia.backend.Backend;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import javafx.application.Application;
import org.springframework.context.ConfigurableApplicationContext;

public class Main {

    private static ConfigurableApplicationContext context;

    static void main(String[] args) {
        context = Backend.run();
        Application.launch(Frontend.class, args);
    }

    public static void stop() {
        System.out.println("Initiating application exit sequence...");

        if (context != null) {
            try {
                context.close();
            } catch (Exception e) {
                System.err.println("Spring context closed with errors (expected during deadlock): " + e.getMessage());
            }
        }

        RestClient.shutdown();

        try {
            String homeDir = System.getProperty("user.home");
            java.nio.file.Path portFile = java.nio.file.Paths.get(homeDir, ".philopsychia", "yiptex", "yiptex.port");
            java.nio.file.Files.deleteIfExists(portFile);
        } catch (Exception e) {
            System.err.println("Could not delete port file: " + e.getMessage());
        }
    }
}