package com.philopsychia.frontend.control;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.data_store.SecondPhaseRegistrationData;
import com.philopsychia.frontend.util.ScreenUtil;
import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.group.Schedule;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import org.controlsfx.control.textfield.CustomTextField;

public class SecondaryRegistrationController {
    
    private static final String MALFORMED_STUDENT_ID = "Solo los 10 caracteres numericos";
    private static final String MALFORMED_EMAIL = "Solo terminacion \"@alumno.ipn.mx\"";
    private static final String MALFORMED_CLASS_NAME = "El grupo seleccionado no existe";
    private static final String UNSELECTED_SCHEDULE = "Porfavor selecione una opcion";

    public Button returnButton;
    public GridPane gridContainer;

    public VBox studentIdVbox;
    public CustomTextField studentIdField;

    public VBox emailVBox;
    public CustomTextField emailField;

    public VBox classVbox;
    public CustomTextField classField;

    public Button next;

    @FXML
    private void initialize() {
    }

    public void tryNext(MouseEvent mouseEvent) {
        cleanGUI();

        boolean passed = true;

        String studentId = studentIdField.getText().trim();
        long parsedStudentId = 0;
        if (!Regexes.studentIdRegex.matcher(studentId).matches()) {
            studentIdVbox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_STUDENT_ID));
            passed = false;
        } else {
            parsedStudentId = Long.parseLong(studentId);
        }

        String email = emailField.getText().trim();
        if (!Regexes.institutionalEmailStudentRegex.matcher(email).matches()) {
            emailVBox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_EMAIL));
            passed = false;
        }

        String group = classField.getText().trim();
        if (!Regexes.groupRegex.matcher(group).matches()) {
            classVbox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_CLASS_NAME));
            passed = false;
        }

        if (!passed) return;

        Frontend.dataStorage.put("second_stage_registration_data", new SecondPhaseRegistrationData(
                parsedStudentId,
                email,
                group
        ));

        Frontend.pop();
        Frontend.push("registration_screen3");
    }

    public void returnToPrevious(MouseEvent mouseEvent) {
        Frontend.pop();
    }

    private void cleanGUI() {
        studentIdVbox.getChildren().removeIf(node -> (node instanceof HBox));
        emailVBox.getChildren().removeIf(node -> (node instanceof HBox));
        classVbox.getChildren().removeIf(node -> (node instanceof HBox));
    }
}
