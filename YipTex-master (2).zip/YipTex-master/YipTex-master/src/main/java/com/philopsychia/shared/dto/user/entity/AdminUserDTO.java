package com.philopsychia.shared.dto.user.entity;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

public class AdminUserDTO extends BaseUserDTO {
    @Getter
    @Setter
    private String username;

    public AdminUserDTO() {}

    public AdminUserDTO(GUID id, String username, Role role) {
        super(id, role);
        this.username = username;
    }
}
