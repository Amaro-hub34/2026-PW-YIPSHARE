package com.philopsychia.frontend.util;

import javafx.animation.Transition;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Paint;
import javafx.util.Duration;

public final class TransitionUtil {

    private static final CornerRadii radii = new CornerRadii(15);

    public static void applyHoverTransition(Button button, Paint start_color, Paint end_color) {
        Transition hoverTransition = new Transition() {
            { setCycleDuration(Duration.millis(100)); }
            @Override
            protected void interpolate(double frac) {
                Paint color = start_color.interpolate(end_color, frac);
                button.setBackground(new Background(new BackgroundFill(color, radii, Insets.EMPTY)));
            }
        };

        button.hoverProperty().addListener((obs, wasHovered, isNowHovered) -> {
            if (isNowHovered) {
                hoverTransition.setRate(1.0);
                hoverTransition.playFrom(hoverTransition.getCurrentTime());
            } else {
                hoverTransition.setRate(-1.0);
                hoverTransition.playFrom(hoverTransition.getCurrentTime());
            }
        });
    }
}
