package com.philopsychia.backend.database.driver;

import java.util.List;
import java.util.Optional;

public interface DatabaseDriver extends AutoCloseable {

    void initialize(List<String> schemaCommands);

    <T> List<T> query (String SQL, RowMapper<T> mapper, Object... args);
    <T> Optional<T> queryOne(String SQL, RowMapper<T> mapper, Object... args);

    int update(String SQL, Object... args);
}
