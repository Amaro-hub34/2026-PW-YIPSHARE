package com.philopsychia.backend.service.group;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.registration.group.ClassRegistration;
import com.philopsychia.backend.database.repository.ClassRepository;
import com.philopsychia.backend.database.repository.UserRepository;
import com.philopsychia.backend.util.exception.BadRequestException;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.Role;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ClassService {

    private final ClassRepository classRepository;
    private final UserRepository userRepository;

    public ClassService(ClassRepository classRepository, UserRepository userRepository) {
        this.classRepository = classRepository;
        this.userRepository = userRepository;
    }

    public ClassEntityDTO getClassByName(String name) {
        Optional<ClassEntityDTO> data = classRepository.getClassByName(name);
        if (data.isPresent()) return data.get();
        else throw new ResourceNotFound("Resource not found");
    }

    public ClassEntityDTO getClass(GUID id) {
        Optional<ClassEntityDTO> data = classRepository.getClassById(id);
        if (data.isPresent()) return data.get();
        else throw new ResourceNotFound("Resource not found");
    }

    public void modifyClass(GUID uuid, ClassPayloadDTO dto) {
        if (classRepository.getClassById(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        Optional<ClassEntityDTO> data = classRepository.getClassByName(dto.getName());
        if (data.isPresent() && !data.get().getId().equals(uuid)) throw new BadRequestException("Modification attempted to duplicate data");
        classRepository.modifyClass(uuid, dto);
    }

    public void deleteClass(GUID uuid) {
        if (classRepository.getClassById(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        classRepository.deleteClass(uuid);
    }

    public List<ClassEntityDTO> getAllClasses() {
        return classRepository.getAllClasses();
    }

    public List<ClassEntityDTO> getAllClassesByTeacher(GUID teacher) {
        return classRepository.getClassesByTeacher(teacher);
    }

    public void createClass(ClassPayloadDTO dto) {
        Optional<BaseUserDTO> user = userRepository.findUserByUserId(dto.getPrimary_teacher_id());
        if (user.isEmpty()) throw new ResourceNotFound("Invalid primary_teacher_id reference");
        else if (user.get().getRole() == Role.TEACHER) classRepository.registerClass(new ClassRegistration(dto.getName(), dto.getSchedule(), dto.getPrimary_teacher_id()));
        else throw new ResourceNotFound("Passed reference is of another role than teacher");
    }
}
