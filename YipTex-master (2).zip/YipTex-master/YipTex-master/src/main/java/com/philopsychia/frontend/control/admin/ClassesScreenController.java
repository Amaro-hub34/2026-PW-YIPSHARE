package com.philopsychia.frontend.control.admin;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.auth.register_request.TechnicianRegisterRequestDTO;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.group.Schedule;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import com.philopsychia.shared.dto.user.entity.TechnicianUserDTO;
import com.philopsychia.shared.dto.user.payload.NonAdminPayloadDTO;
import com.philopsychia.shared.dto.user.payload.TechnicianPayloadDTO;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public class ClassesScreenController implements IController  {
    public Button newButton;
    public GridPane roomTable;

    @FXML
    private void initialize(){}

    @Override
    public void init() {

        List<Node> nodesToRemove = new ArrayList<>();
        for (Node node : roomTable.getChildren()) {
            Integer rowIndex = GridPane.getRowIndex(node);
            if (rowIndex != null && rowIndex > 0) {
                nodesToRemove.add(node);
            }
        }

        roomTable.getRowConstraints().removeIf(x -> {
            return roomTable.getRowConstraints().indexOf(x) != 0;
        });

        roomTable.getChildren().removeAll(nodesToRemove);

        RestClient.authorizedGetRequest(
                task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<List<ClassEntityDTO>> apiResponse = task.getValue();

                        if (apiResponse.isError()) {
                            ViewLoader.generatePopup("Hubo un error insperado");
                        } else {
                            int i = 0;

                            for (ClassEntityDTO group : apiResponse.data()) {
                                i++;

                                int finalI = i;
                                RestClient.authorizedGetRequest(t -> {
                                    Frontend.loadingOverlay.bindToTask(t);
                                    t.setOnSucceeded(e -> {
                                        ApiResponse<BaseUserDTO> apiResponse2 = t.getValue();
                                        if (apiResponse2.isError() ) {
                                            Frontend.pushPopup("Hubo un error inesperado");
                                        } else if (apiResponse2.data() instanceof TeacherUserDTO teacher){
                                            List<Node> nodesForRow = List.of(
                                                    new Label(group.getName()),
                                                    new Label(group.getSchedule() == Schedule.MORNING ? "Matutino" : "Vespertino"),
                                                    new Label(String.format("%s %s %s", teacher.getName(), teacher.getPaternal_surname(), teacher.getMaternal_surname())),
                                                    new Button("", new FontIcon(Feather.PEN_TOOL) {{this.setIconColor(Color.WHITE);}}) {
                                                        {
                                                            this.setStyle("-fx-background-color: #991859; -fx-background-radius: 100");
                                                            this.setOnMouseClicked(event -> modifyClass(event, group, group.getId()));
                                                        }
                                                    },
                                                    new Button("", new FontIcon(Feather.TRASH) {{this.setIconColor(Color.WHITE);}}) {
                                                        {
                                                            this.setStyle("-fx-background-color: #262626; -fx-background-radius: 100");
                                                            this.setOnMouseClicked(event -> deleteClass(event, group.getId()));
                                                        }
                                                    }
                                            );

                                            int j = 0;
                                            for (Node node : nodesForRow) {
                                                roomTable.add(node,j, finalI);
                                                GridPane.setHalignment(node, HPos.CENTER);
                                                j++;
                                            }
                                        } else {
                                            Frontend.pushPopup("Se encontro un usuario con rol incorrecto");
                                        }
                                    });
                                }, "api/users/{id}",
                                        new ParameterizedTypeReference<BaseUserDTO>() {},
                                        group.getPrimary_teacher_id());

                                roomTable.getRowConstraints().add(
                                        new RowConstraints(50)
                                );
                            }
                        }
                    });
                }, "/api/classes",
                new ParameterizedTypeReference<List<ClassEntityDTO>>() {}
        );

    }

    public void createClass(MouseEvent mouseEvent) {
        Frontend.pushWithIO("admin/data_input/class_data", (ClassPayloadDTO classPayloadDto) -> {

            RestClient.authorizedPostRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                if (apiResponse.code() == HttpStatus.BAD_REQUEST) {
                                    Frontend.pop(); Frontend.pop();
                                    Frontend.pushPopup("Los datos usados ya han sido registrados");
                                } else {
                                    Frontend.pushPopup("Hubo un error inesperado");
                                }
                            } else {
                                Frontend.pop();
                                init();
                            }
                        });
                    }, "/api/classes",
                    classPayloadDto,
                    new ParameterizedTypeReference<Void>() {}
            );
        }, null);
    }

    private void modifyClass(MouseEvent mouseEvent, ClassEntityDTO input, GUID id) {
        Frontend.pushWithIO("admin/data_input/class_data", (ClassPayloadDTO classPayloadDto) -> {
            RestClient.authorizedPutRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                if (apiResponse.code() == HttpStatus.BAD_REQUEST) {
                                    Frontend.pop();
                                    Frontend.pushPopup("Los datos usados ya han sido registrados");
                                } else {
                                    Frontend.pushPopup("Hubo un error inesperado");
                                }
                            } else {
                                Frontend.pop();
                                init();
                            }
                        });
                    }, "/api/classes/{id}",
                    classPayloadDto,
                    new ParameterizedTypeReference<Void>() {},
                    id
            );
        }, input);
    }

    private void deleteClass(MouseEvent mouseEvent, GUID id) {
        Frontend.pushConfirmation("Esta seguro de que desea borrar esta clase", () -> {
            RestClient.authorizedDeleteRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                ViewLoader.generatePopup("Hubo un error insperado");
                            } else {
                                init();
                            }
                        });
                    }, "/api/classes/{id}",
                    new ParameterizedTypeReference<Void>() {},
                    id
            );
        });
    }
}