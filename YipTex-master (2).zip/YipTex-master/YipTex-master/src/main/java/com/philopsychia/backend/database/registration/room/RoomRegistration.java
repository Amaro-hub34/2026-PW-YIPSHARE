package com.philopsychia.backend.database.registration.room;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.Getter;
import lombok.Setter;

public class RoomRegistration {

    @Getter
    private final GUID id;

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String location;

    @Getter
    @Setter
    private String acronym;

    @Getter
    @Setter
    private int device_amount;

    public RoomRegistration(String name, String location, String acronym, int device_amount) {
        this.id = GUID.v7();
        this.name = name;
        this.location = location;
        this.acronym = acronym;
        this.device_amount = device_amount;
    }
}
