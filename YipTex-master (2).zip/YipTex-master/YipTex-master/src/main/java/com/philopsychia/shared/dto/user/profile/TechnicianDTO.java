package com.philopsychia.shared.dto.user.profile;

public record TechnicianDTO(String rfc) {
}
