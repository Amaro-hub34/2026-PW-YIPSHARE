package com.philopsychia.frontend.control.admin.data_input;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.control.util.IWithCallback;
import com.philopsychia.frontend.control.util.IWithLoadFunction;
import com.philopsychia.frontend.util.ScreenUtil;
import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import com.philopsychia.shared.dto.user.payload.TeacherPayloadDTO;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import org.controlsfx.control.textfield.CustomTextField;

public class TeacherDataController extends IWithCallback<TeacherPayloadDTO> implements IWithLoadFunction<TeacherUserDTO> {

    private static final String INVALID_NUMBER = "El numero ingresado es invalido";
    private static final String EMPTY_FIELD = "El campo no puede estar vacio";

    private static final String MALFORMED_NAME = "Solo caracteres de un alfabeto, apostrofes, guiones y espacios";
    private static final String MALFORMED_SURNAME = "Solo caracteres de un alfabeto, apostrofes y guiones";
    private static final String MALFORMED_EMAIL = "Solo terminacion \"@ipn.mx\"";

    private static final String MALFORMED_RFC = "El RFC ingresado no es valido";

    public GridPane gridContainer;

    public Button returnButton;
    public VBox paternalSurnameVBox;
    public CustomTextField paternalSurnameField;

    public VBox maternalSurnameVBox;
    public CustomTextField maternalSurnameField;

    public VBox nameVBox;
    public CustomTextField nameField;

    public VBox emailVBox;
    public CustomTextField emailField;

    public VBox rfcVBox;
    public CustomTextField rfcField;

    public Button next;


    @FXML
    private void initialize() {
    }

    public void tryNext(MouseEvent mouseEvent) {
        cleanGUI();

        boolean passed = true;

        String paternalSurname = paternalSurnameField.getText().trim();
        if (!Regexes.surnameRegex.matcher(paternalSurname).matches()) {
            paternalSurnameVBox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_SURNAME));
            passed = false;
        }

        String maternalSurname = maternalSurnameField.getText().trim();
        if (!Regexes.surnameRegex.matcher(maternalSurname).matches()) {
            maternalSurnameVBox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_SURNAME));
            passed = false;
        }

        String name = nameField.getText().trim();
        if (!Regexes.nameRegex.matcher(name).matches()) {
            nameVBox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_NAME));
            passed = false;
        }

        String email = emailField.getText().trim();
        if (!Regexes.institutionalEmailNonStudentRegex.matcher(email).matches()) {
            emailVBox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_EMAIL));
            passed = false;
        }

        String rfc =  rfcField.getText().trim();
        if (!Regexes.rfcRegex.matcher(rfc).matches()) {
            rfcVBox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_RFC));
            passed = false;
        }

        if (!passed) return;

        this.callback.accept(new TeacherPayloadDTO(
                rfc,
                name,
                paternalSurname,
                maternalSurname,
                email
        ));
    }

    public void returnToPrevious(MouseEvent mouseEvent) {
        Frontend.pop();
    }

    private void cleanGUI() {
        nameVBox.getChildren().removeIf(node -> (node instanceof HBox));
        paternalSurnameVBox.getChildren().removeIf(node -> (node instanceof HBox));
        maternalSurnameVBox.getChildren().removeIf(node -> (node instanceof HBox));
        emailVBox.getChildren().removeIf(node -> (node instanceof HBox));
        rfcVBox.getChildren().removeIf(node -> (node instanceof HBox));
    }

    @Override
    public void load(TeacherUserDTO input) {
        if (input == null) return;
        nameField.setText(input.getName());
        paternalSurnameField.setText(input.getPaternal_surname());
        maternalSurnameField.setText(input.getMaternal_surname());
        emailField.setText(input.getInstitutional_email());
        rfcField.setText(input.getRfc());
    }
}
