package com.philopsychia.backend.util.function;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Objects;

public final class SchemaUtil {
    public static List<String> getSchemaInit() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(Objects.requireNonNull(SchemaUtil.class.getClassLoader().getResourceAsStream("sql/database_schema.sql"))))) {
            return List.of(reader.readAllAsString().split(";"));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return List.of();
    }
}
