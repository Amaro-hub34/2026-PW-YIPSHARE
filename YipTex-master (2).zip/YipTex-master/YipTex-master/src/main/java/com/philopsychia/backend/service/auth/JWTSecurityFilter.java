package com.philopsychia.backend.service.auth;

import com.github.f4b6a3.uuid.alt.GUID;
import com.nimbusds.jwt.JWTClaimsSet;
import com.philopsychia.backend.database.repository.UserRepository;
import com.philopsychia.backend.util.data.JwtID;
import com.philopsychia.shared.dto.user.Role;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.jspecify.annotations.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Component
public class JWTSecurityFilter extends OncePerRequestFilter {

    private final UserRepository userRepository;
    private final JWTService jwtService;

    public JWTSecurityFilter(UserRepository userRepository,  JWTService jwtService) {
        this.userRepository = userRepository;
        this.jwtService = jwtService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, @NonNull HttpServletResponse response, @NonNull FilterChain filterChain) throws ServletException, IOException {

        String header = request.getHeader("Authorization");

        if (header == null || !header.startsWith("Bearer ")) {
            filterChain.doFilter(request, response);
            return;
        }

        String jwt = header.substring(7);
        Optional<JWTClaimsSet> validatedClaims = jwtService.validateToken(jwt);

        if (validatedClaims.isEmpty()) {
            sendUnauthorizedResponse(response, "Invalid JWT structure");
            return;
        }

        if (validatedClaims.get().getExpirationTime().before(new Date())) {
            sendUnauthorizedResponse(response, "Expired JWT token");
            return;
        }
        Optional<Role> role = userRepository.findRoleByUserId(new GUID(validatedClaims.get().getSubject()));
        if (role.isEmpty()) {
            sendUnauthorizedResponse(response, "User not found");
            return;
        }

        String userId = validatedClaims.get().getSubject();
        UserDetails details = new User(userId, "", List.of(role.get(), new JwtID(validatedClaims.get().getJWTID())));

        UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(details, null, details.getAuthorities());
        authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        SecurityContextHolder.getContext().setAuthentication(authToken);

        filterChain.doFilter(request, response);
    }

    private void sendUnauthorizedResponse(HttpServletResponse response, String message) throws IOException {
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json");
        response.getWriter().write(String.format("{\"error\": \"Unauthorized\", \"message\": \"%s\"}", message));
    }
}
