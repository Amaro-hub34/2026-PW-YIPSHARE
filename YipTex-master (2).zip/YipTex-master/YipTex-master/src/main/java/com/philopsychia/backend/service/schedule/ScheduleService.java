package com.philopsychia.backend.service.schedule;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.registration.room.RoomRegistration;
import com.philopsychia.backend.database.registration.schedule.ScheduleRegistration;
import com.philopsychia.backend.database.repository.RoomRepository;
import com.philopsychia.backend.database.repository.ScheduleRepository;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.room.RoomPayloadDTO;
import com.philopsychia.shared.dto.schedule.ScheduleEntityDTO;
import com.philopsychia.shared.dto.schedule.SchedulePayloadDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ScheduleService {

    private final ScheduleRepository scheduleRepository;

    public ScheduleService(ScheduleRepository scheduleRepository) {
        this.scheduleRepository = scheduleRepository;
    }

    public ScheduleEntityDTO getSchedule(GUID uuid) {
        Optional<ScheduleEntityDTO> data = scheduleRepository.getScheduleEntryById(uuid);
        if (data.isPresent()) return data.get();
        else throw new ResourceNotFound("Resource not found");
    }

    public void modifySchedule(GUID uuid, SchedulePayloadDTO dto) {
        if (scheduleRepository.getScheduleEntryById(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        scheduleRepository.modifyScheduleEntry(uuid, dto);
    }

    public void deleteSchedule(GUID uuid) {
        if (scheduleRepository.getScheduleEntryById(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        scheduleRepository.deleteScheduleEntry(uuid);
    }

    public List<ScheduleEntityDTO> getAllScheduleEntries() {
        return scheduleRepository.getAllScheduleEntries();
    }

    public void createScheduleEntry(SchedulePayloadDTO dto) {
        scheduleRepository.registerScheduleEntry(new ScheduleRegistration(
                dto.getEnd_time(),
                dto.getStart_time(),
                dto.getWeekday(),
                dto.getRoom_id(),
                dto.getClass_id()
        ));
    }
}
