package com.philopsychia.shared.dto.mapping_table;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
public class MappingEntryDTO {

    @Getter
    @Setter
    private GUID user_id;

    @Getter
    @Setter
    private GUID class_id;
}
