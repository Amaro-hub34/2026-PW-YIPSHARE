package com.philopsychia.shared.dto.auth;

public record LoginRequestDTO(String identifier, String password) {
}
