package com.philopsychia.frontend.control.technician;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.ticket.Status;
import com.philopsychia.shared.dto.ticket.TicketEntityDTO;
import com.philopsychia.shared.dto.ticket.TicketPayloadDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public class TicketsScreenController implements IController  {

    public Button newButton;
    public GridPane ticketTable;

    @FXML
    private void initialize(){}

    @Override
    public void init() {

        List<Node> nodesToRemove = new ArrayList<>();
        for (Node node : ticketTable.getChildren()) {
            Integer rowIndex = GridPane.getRowIndex(node);
            if (rowIndex != null && rowIndex > 0) {
                nodesToRemove.add(node);
            }
        }

        ticketTable.getRowConstraints().removeIf(x -> {
            return ticketTable.getRowConstraints().indexOf(x) != 0;
        });

        ticketTable.getChildren().removeAll(nodesToRemove);

        RestClient.authorizedGetRequest(
                task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<List<TicketEntityDTO>> tickets = task.getValue();

                        if (tickets.isError()) {
                            ViewLoader.generatePopup("Hubo un error insperado");
                        } else {
                            int i = 0;

                            for (TicketEntityDTO ticket : tickets.data()) {
                                i++;

                                int finalI = i;
                                RestClient.authorizedGetRequest(t2 -> {
                                            Frontend.loadingOverlay.bindToTask(t2);
                                            t2.setOnSucceeded(e2 -> {
                                                ApiResponse<DeviceEntityDTO> deviceEntityDTO = t2.getValue();

                                                if (deviceEntityDTO.isError()) {
                                                    Frontend.pushPopup("Hubo un error insperado");
                                                } else {
                                                    DeviceEntityDTO device = deviceEntityDTO.data();
                                                    RestClient.authorizedGetRequest(t3 -> {
                                                                Frontend.loadingOverlay.bindToTask(t3);
                                                                t3.setOnSucceeded(e1 -> {
                                                                    ApiResponse<RoomEntityDTO> roomEntityDTOApiResponse = t3.getValue();

                                                                    if (roomEntityDTOApiResponse.isError()) {
                                                                        Frontend.pushPopup("Hubo un error inesperado");
                                                                    } else {
                                                                        ChoiceBox<String> choiceBox = new ChoiceBox<>();
                                                                        choiceBox.getItems().addAll(
                                                                                "Abierto",
                                                                                "En Progreso",
                                                                                "Resuelto",
                                                                                "Cerrado"
                                                                        );

                                                                        choiceBox.setStyle("-fx-background-color: #EEEEEE; -fx-border-color: #736E6E; -fx-border-width: 1.5; -fx-border-radius: 15; -fx-background-radius: 15; -fx-font: 14px");

                                                                        choiceBox.getSelectionModel().select(ticket.getStatus().ordinal());

                                                                        choiceBox.getSelectionModel().selectedItemProperty().addListener((observable, oldValue, newValue) -> {
                                                                            if (newValue != null) {
                                                                                Status status = Status.values()[choiceBox.getItems().indexOf(newValue)];

                                                                                TicketPayloadDTO payload = new TicketPayloadDTO(
                                                                                        ticket.getCreated_by(),
                                                                                        ticket.getDevice_id(),
                                                                                        ticket.getDescription(),
                                                                                        status
                                                                                );

                                                                                RestClient.authorizedPutRequest(t4 -> {
                                                                                            Frontend.loadingOverlay.bindToTask(t4);
                                                                                            t4.setOnSucceeded(e3 -> {
                                                                                                ApiResponse<Void> voidApiResponse = t4.getValue();
                                                                                                if (voidApiResponse.isError()) {
                                                                                                    Frontend.pushPopup("Hubo un error inesperado");
                                                                                                } else {
                                                                                                    init();
                                                                                                }
                                                                                            });
                                                                                        }, "/api/tickets/{ticket_id}",
                                                                                        payload,
                                                                                        new ParameterizedTypeReference<Void>() {},
                                                                                        ticket.getId());
                                                                            }
                                                                        });

                                                                        List<Node> nodesForRow = List.of(
                                                                                new Label(roomEntityDTOApiResponse.data().getName()),
                                                                                new Label(String.valueOf(device.getNumber_id())),
                                                                                choiceBox,
                                                                                new Button("", new FontIcon(Feather.MESSAGE_SQUARE) {{this.setIconColor(Color.WHITE);}}) {
                                                                                    {
                                                                                        this.setStyle("-fx-background-color: #991859; -fx-background-radius: 100");
                                                                                        this.setOnMouseClicked(event -> {
                                                                                            Frontend.pushTicketPopup(ticket.getDescription(),
                                                                                                    ticket.getCreated_at());
                                                                                        });
                                                                                    }
                                                                                }
                                                                        );

                                                                        int j = 0;
                                                                        for (Node node : nodesForRow) {
                                                                            ticketTable.add(node,j, finalI);
                                                                            GridPane.setHalignment(node, HPos.CENTER);
                                                                            j++;
                                                                        }

                                                                        ticketTable.getRowConstraints().add(
                                                                                new RowConstraints(50)
                                                                        );
                                                                    }
                                                                });
                                                            }, "/api/rooms/{room_id}",
                                                            new ParameterizedTypeReference<RoomEntityDTO>() {},
                                                            device.getRoom_id());
                                                }
                                            });
                                        }, "/api/devices/{device_id}",
                                        new ParameterizedTypeReference<DeviceEntityDTO>() {},
                                        ticket.getDevice_id());
                            }
                        }
                    });
                }, "/api/tickets",
                new ParameterizedTypeReference<List<TicketEntityDTO>>() {}
        );

    }
}