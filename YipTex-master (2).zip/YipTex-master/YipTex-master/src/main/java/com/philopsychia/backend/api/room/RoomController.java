package com.philopsychia.backend.api.room;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.service.auth.AuthService;
import com.philopsychia.backend.service.device.DeviceService;
import com.philopsychia.backend.util.data.JwtID;
import com.philopsychia.backend.util.exception.BadRequestException;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.backend.service.room.RoomService;
import com.philopsychia.shared.dto.room.RoomPayloadDTO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAuthority('ADMIN')")
@RequestMapping("/api/rooms")
public class RoomController {

    private final RoomService roomService;

    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    @GetMapping
    public List<RoomEntityDTO> getAllRooms(@AuthenticationPrincipal UserDetails userDetails) {
        return roomService.getAllRooms();
    }

    @GetMapping("/teacher")
    public List<RoomEntityDTO> getAllRoomsByTeacher(@AuthenticationPrincipal UserDetails userDetails) {
        return roomService.getAllRoomsByTeacher(new GUID(userDetails.getUsername()));
    }

    @PostMapping
    public void createRoom(@AuthenticationPrincipal UserDetails userDetails, @RequestBody RoomPayloadDTO dto) {
        if (!dto.validate()) throw new BadRequestException("Invalid room payload");
        roomService.createRoom(dto);
    }

    @GetMapping("/{uuid}")
    public RoomEntityDTO getRoom(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        return roomService.getRoom(uuid);
    }

    @PutMapping("/{uuid}")
    public void modifyRoom(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid, @RequestBody RoomPayloadDTO dto) {
        if (!dto.validate()) throw new BadRequestException("Invalid room payload");
        roomService.modifyRoom(uuid, dto);
    }

    @DeleteMapping("/{uuid}")
    public void deleteRoom(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        roomService.deleteRoom(uuid);
    }

}
