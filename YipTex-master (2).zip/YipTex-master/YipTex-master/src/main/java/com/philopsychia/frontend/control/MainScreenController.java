package com.philopsychia.frontend.control;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.*;
import com.philopsychia.shared.dto.user.entity.AdminUserDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.NonAdminUserDTO;
import com.philopsychia.shared.dto.user.Role;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import org.kordamp.ikonli.Ikon;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;

import java.util.Arrays;
import java.util.EnumMap;

public class MainScreenController implements IController {

    private static final EnumMap<Role, SidebarEntry[]> sidebarDefinitions = new EnumMap<>(Role.class);
    public HBox account_display;

    private ContextMenu contextMenu;

    static {
        sidebarDefinitions.put(Role.STUDENT, new SidebarEntry[]{
                new SidebarEntry("Inicio", "home", Feather.HOME),
                new SidebarEntry("Horario", "schedule", Feather.CALENDAR),
                new SidebarEntry("Equipo de Computo", "device", Feather.MONITOR),
                new SidebarEntry("Grupo", "class",  Feather.GRID),
                new SidebarEntry("Cuenta", "account", Feather.USER),
        });
        sidebarDefinitions.put(Role.TEACHER, new SidebarEntry[]{
                new SidebarEntry("Inicio", "home", Feather.HOME),
                new SidebarEntry("Grupos", "classes",  Feather.GRID),
                new SidebarEntry("Reportes", "reports", Feather.BOOKMARK),
                new SidebarEntry("Cuenta", "account", Feather.USER),
        });
        sidebarDefinitions.put(Role.TECHNICIAN, new SidebarEntry[]{
                new SidebarEntry("Inicio", "home",  Feather.HOME),
                new SidebarEntry("Tickets", "tickets", Feather.TAG),
                new SidebarEntry("Equipos de Computo", "devices",  Feather.MONITOR),
                new SidebarEntry("Cuenta", "account", Feather.USER),
        });
        sidebarDefinitions.put(Role.ADMIN, new SidebarEntry[]{
                new SidebarEntry("Inicio", "home",  Feather.HOME),
                new SidebarEntry("Laboratorios", "rooms", Feather.SERVER),
                new SidebarEntry("Grupos", "classes", Feather.GRID),
                new SidebarEntry("Horario", "schedule",  Feather.CALENDAR),
                new SidebarEntry("Profesores", "teachers",  Feather.BOOK_OPEN),
                new SidebarEntry("Tecnicos", "technicians", Feather.TOOL),
        });
    }

    private static final Object2ObjectOpenHashMap<String, Button> buttonMap =
            new Object2ObjectOpenHashMap<>();

    public Text account_type_display;
    public Text name_display;
    public VBox sidebar;
    public Pane main_area;

    private Role currentRole;

    private void populateSidebar(BaseUserDTO user) {
        sidebar.getChildren().addAll(Arrays.stream(sidebarDefinitions.get(user.getRole())).map(entry -> {
            FontIcon icon = new FontIcon(entry.icon);
            icon.setIconSize(16);
            icon.setFill(Color.WHITE);

            Button button = new Button(entry.name);
            button.setGraphic(icon);
            button.setStyle("-fx-background-color: transparent; -fx-font-family: 'Encode Sans Semi Expanded Medium';");
            button.setTextFill(Color.WHITE);

            button.setGraphicTextGap(8);

            button.setOnMouseClicked(_ -> onClickButton(entry.screen_identifier, button));

            buttonMap.put(entry.screen_identifier, button);

            return button;
        }).toList());


        onClickButton("home", buttonMap.get("home"));
    }

    private void onClickButton(String screen, Button button) {
        buttonMap.forEach((id, entry) -> {
            entry.setTextFill(Color.WHITE);
            if (entry.getGraphic() instanceof FontIcon icon) {
                icon.setFill(Color.WHITE);
            }
        });

        button.setTextFill(Paints.HIGHLIGHT_PAINT);
        if (button.getGraphic() instanceof FontIcon icon) {
            icon.setFill(Paints.HIGHLIGHT_PAINT);
        }

        main_area.getChildren().clear();
        main_area.getChildren().add(ViewLoader.loadView(currentRole.name().toLowerCase()+"/"+screen));
    }

    private void setAccountTypeDisplay(BaseUserDTO user) {
        Frontend.dataStorage.put("role_text", switch (user.getRole()) {
                    case ADMIN -> "Administrador";
                    case STUDENT -> "Estudiante";
                    case TEACHER -> "Profesor";
                    case TECHNICIAN -> "Tecnico";
                });
        account_type_display.setText(Frontend.dataStorage.get("role_text", String.class));
    }

    private void setName(BaseUserDTO user) {
        Frontend.dataStorage.put("account_identifier",
                switch (user.getRole()) {
                    case ADMIN -> {
                        if (user instanceof AdminUserDTO adminUser)
                            yield adminUser.getUsername();
                        else throw new IllegalStateException("Unexpected java type for role ADMIN");
                    }
                    case STUDENT, TEACHER, TECHNICIAN -> {
                        if (user instanceof NonAdminUserDTO nonAdminUser)
                            yield String.format("%s %s %s", nonAdminUser.getName(), nonAdminUser.getPaternal_surname(), nonAdminUser.getMaternal_surname());
                        else throw new IllegalStateException("Unexpected java type for non administrator account");
                    }
                });
        name_display.setText(Frontend.dataStorage.get("account_identifier", String.class));
    }

    @Override
    public void init() {
        RestClient.authorizedGetRequest(task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<BaseUserDTO> apiResponse = task.getValue();

                        if (!apiResponse.isError()) {
                            BaseUserDTO user = apiResponse.data();
                            currentRole = user.getRole();

                            setAccountTypeDisplay(user);
                            setName(user);
                            populateSidebar(user);
                        }
                    });
                }, "/api/auth/me",
                new ParameterizedTypeReference<BaseUserDTO>() {});
    }

    public void showMainMenuAccountContext(ContextMenuEvent contextMenuEvent) {
        if (contextMenu == null) {
            contextMenu = new ContextMenu();

            MenuItem action1 = new MenuItem("Cerrar Sesion");

            action1.setOnAction(e -> RestClient.logout(false));

            contextMenu.getItems().addAll(action1);
        }

        contextMenu.show(account_display, contextMenuEvent.getScreenX(), contextMenuEvent.getScreenY());
    }

    private record SidebarEntry(String name, String screen_identifier, Ikon icon){}
}
