package com.philopsychia.frontend.util;

import javafx.scene.paint.Paint;

public final class Paints {

    public static final Paint HIGHLIGHT_PAINT = Paint.valueOf("#991859FF");
    public static final Paint BASE_PAINT = Paint.valueOf("#5A1236FF");
    public static final Paint GRADIENT_PAINT = Paint.valueOf("#3b0b23FF");
}
