package com.philopsychia.backend.database.entity.user;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;

public class StudentUserEntity extends NonAdminUserEntity{
    private final long studentId;

    public StudentUserEntity(GUID id,
                             String password_hash,
                             Role role,
                             String name,
                             String paternalSurname,
                             String maternalSurname,
                             String institutionalEmail,
                             long studentId) {
        super(id, password_hash, role, name, paternalSurname, maternalSurname, institutionalEmail);
        this.studentId = studentId;
    }

    public long studentId() {
        return studentId;
    }
}
