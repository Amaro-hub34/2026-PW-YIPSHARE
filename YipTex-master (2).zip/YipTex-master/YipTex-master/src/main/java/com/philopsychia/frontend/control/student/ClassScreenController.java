package com.philopsychia.frontend.control.student;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.mapping_table.MappingEntryDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.StudentUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ClassScreenController implements IController  {

    public GridPane usersTable;
    public HBox groupsBar;
    public VBox contents;

    @FXML
    private void initialize(){
    }

    @Override
    public void init() {
        RestClient.authorizedGetRequest(task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<BaseUserDTO> apiResponse = task.getValue();

                        if (!apiResponse.isError()) {
                            BaseUserDTO user = apiResponse.data();
                            if (user instanceof StudentUserDTO studentUserDTO) {
                                RestClient.authorizedGetRequest(t -> {
                                            Frontend.loadingOverlay.bindToTask(t);
                                            t.setOnSucceeded(e -> {
                                                ApiResponse<Optional<ClassEntityDTO>> apiResponse2 = t.getValue();
                                                if (!apiResponse2.isError()) {
                                                    if (apiResponse2.data().isEmpty()) {
                                                        contents.setVisible(false);
                                                        contents.setDisable(true);
                                                        Frontend.pushPopup("Su cuenta no ha sido aceptada todavia");
                                                    } else {
                                                        contents.setVisible(true);
                                                        contents.setDisable(false);
                                                        selectClass(apiResponse2.data().get());
                                                    }
                                                }
                                            });
                                        }, "api/students/{user_id}",
                                        new ParameterizedTypeReference<Optional<ClassEntityDTO>>() {},
                                        studentUserDTO.getId());
                            }
                        }
                    });
                }, "/api/auth/me",
                new ParameterizedTypeReference<BaseUserDTO>() {});
    }

    private void selectClass(ClassEntityDTO classEntityDTO) {

        clearTable(usersTable);

        RestClient.authorizedGetRequest(t -> {
                    Frontend.loadingOverlay.bindToTask(t);
                    t.setOnSucceeded(event -> {
                        ApiResponse<List<MappingEntryDTO>> mappingEntriesApiResponse
                                = t.getValue();
                        if (!mappingEntriesApiResponse.isError()) {
                            int i = 0;
                            for (MappingEntryDTO mappingEntryDTO : mappingEntriesApiResponse.data()) {
                                i++;
                                int finalI = i;
                                RestClient.authorizedGetRequest(t2 -> {
                                            Frontend.loadingOverlay.bindToTask(t2);
                                            t2.setOnSucceeded(e2 -> {
                                                ApiResponse<BaseUserDTO> userDTOApiResponse = t2.getValue();
                                                if (!userDTOApiResponse.isError() && userDTOApiResponse.data() instanceof StudentUserDTO student) {
                                                    List<Node> nodesForRow = List.of(
                                                            new Label(String.format("%s %s %s", student.getName(), student.getPaternal_surname(), student.getMaternal_surname())),
                                                            new Label(String.valueOf(student.getStudentId())),
                                                            new Label(student.getInstitutional_email())
                                                    );

                                                    int j = 0;
                                                    for (Node node : nodesForRow) {
                                                        usersTable.add(node,j, finalI);
                                                        GridPane.setHalignment(node, HPos.CENTER);
                                                        j++;
                                                    }

                                                    usersTable.getRowConstraints().add(
                                                            new RowConstraints(50)
                                                    );
                                                }
                                            });
                                        }, "api/users/{id}",
                                        new ParameterizedTypeReference<BaseUserDTO>() {},
                                        mappingEntryDTO.getUser_id());
                            }
                        }
                    });
                }, "/api/classes/{class_id}/students",
                new ParameterizedTypeReference<List<MappingEntryDTO>>() {},
                classEntityDTO.getId());
    }

    private void clearTable(GridPane gridPane) {
        List<Node> nodesToRemove = new ArrayList<>();
        for (Node node : gridPane.getChildren()) {
            Integer rowIndex = GridPane.getRowIndex(node);
            if (rowIndex != null && rowIndex > 0) {
                nodesToRemove.add(node);
            }
        }

        gridPane.getRowConstraints().removeIf(x -> {
            return gridPane.getRowConstraints().indexOf(x) != 0;
        });

        gridPane.getChildren().removeAll(nodesToRemove);
    }

    public void createClass(MouseEvent mouseEvent) {
        Frontend.pushWithIO("admin/data_input/class_data", (ClassPayloadDTO classPayloadDto) -> {

            RestClient.authorizedPostRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                if (apiResponse.code() == HttpStatus.BAD_REQUEST) {
                                    Frontend.pop(); Frontend.pop();
                                    Frontend.pushPopup("Los datos usados ya han sido registrados");
                                } else {
                                    Frontend.pushPopup("Hubo un error inesperado");
                                }
                            } else {
                                Frontend.pop();
                                init();
                            }
                        });
                    }, "/api/classes",
                    classPayloadDto,
                    new ParameterizedTypeReference<Void>() {}
            );
        }, null);
    }

    private void modifyClass(MouseEvent mouseEvent, ClassEntityDTO input, GUID id) {
        Frontend.pushWithIO("admin/data_input/class_data", (ClassPayloadDTO classPayloadDto) -> {
            RestClient.authorizedPutRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                if (apiResponse.code() == HttpStatus.BAD_REQUEST) {
                                    Frontend.pop();
                                    Frontend.pushPopup("Los datos usados ya han sido registrados");
                                } else {
                                    Frontend.pushPopup("Hubo un error inesperado");
                                }
                            } else {
                                Frontend.pop();
                                init();
                            }
                        });
                    }, "/api/classes/{id}",
                    classPayloadDto,
                    new ParameterizedTypeReference<Void>() {},
                    id
            );
        }, input);
    }

    private void deleteClass(MouseEvent mouseEvent, GUID id) {
        Frontend.pushConfirmation("Esta seguro de que desea borrar esta clase", () -> {
            RestClient.authorizedDeleteRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                ViewLoader.generatePopup("Hubo un error insperado");
                            } else {
                                init();
                            }
                        });
                    }, "/api/classes/{id}",
                    new ParameterizedTypeReference<Void>() {},
                    id
            );
        });
    }
}