package com.philopsychia.frontend;

import com.philopsychia.Main;
import com.philopsychia.frontend.components.LoadingOverlay;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.DataStorage;
import com.philopsychia.frontend.util.IconLoader;
import com.philopsychia.frontend.util.ViewLoader;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import javafx.animation.*;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.springframework.core.ParameterizedTypeReference;

import java.time.LocalDateTime;
import java.util.IdentityHashMap;
import java.util.function.Consumer;

public class Frontend extends Application {

    public static StackPane root;
    public static final LoadingOverlay loadingOverlay = new LoadingOverlay();
    public static final DataStorage dataStorage = new DataStorage();

    private static final IdentityHashMap<Node, Runnable> callbacks
            = new IdentityHashMap<>();

    @Override
    public void start(Stage stage) {

        stage.setTitle("YipTex");
        IconLoader.loadAppIcons(stage);

        root = new StackPane();

        Parent splashScreen = ViewLoader.loadView("splash_screen");
        Parent login = ViewLoader.loadView("login");

        SequentialTransition transition = startupAnimation(splashScreen, root);
        root.getChildren().addAll(login, splashScreen, loadingOverlay);

        Scene scene = new Scene(root);

        transition.play();

        stage.setScene(scene);
        stage.show();
        stage.setMaximized(true);
    }

    private static SequentialTransition startupAnimation(Parent splashScreen, StackPane root) {
        FadeTransition nameFade = new FadeTransition(Duration.seconds(1), splashScreen.getChildrenUnmodifiable().get(1));
        nameFade.setFromValue(1);
        nameFade.setToValue(0);

        TranslateTransition translate = new TranslateTransition(Duration.seconds(1), splashScreen.getChildrenUnmodifiable().getFirst());
        translate.setInterpolator(Interpolator.EASE_IN);
        translate.setByY(-2000);

        FadeTransition splashFade = new FadeTransition(Duration.seconds(1), splashScreen);
        splashFade.setFromValue(1);
        splashFade.setToValue(0);

        ParallelTransition parallel = new ParallelTransition(splashFade, translate);
        SequentialTransition transition = new SequentialTransition(nameFade, parallel);
        transition.setOnFinished(_ -> root.getChildren().remove(splashScreen));
        return transition;
    }

    public static void reset(String name) {
        Frontend.root.getChildren().removeIf(child -> child != loadingOverlay);
        Frontend.root.getChildren().addFirst(
                ViewLoader.loadView(name)
        );
    }

    public static void push(String name) {
        ObservableList<Node> children = Frontend.root.getChildren();
        children.add(children.size()-1, ViewLoader.loadView(name));
    }

    public static void push(String name, Runnable callback) {
        ObservableList<Node> children = Frontend.root.getChildren();
        Node node = ViewLoader.loadView(name);
        children.add(children.size()-1, node);
        Frontend.callbacks.put(node, callback);
    }

    public static <T, U> void pushWithIO(String name, Consumer<T> callback, U input) {
        ObservableList<Node> children = Frontend.root.getChildren();
        Node node = ViewLoader.loadScreenWithIO(name, callback, input);
        children.add(children.size()-1, node);
    }

    public static void pushPopup(String message) {
        ObservableList<Node> children = Frontend.root.getChildren();
        children.add(children.size()-1, ViewLoader.generatePopup(message));
    }

    public static void pushTicketPopup(String description, LocalDateTime time) {
        ObservableList<Node> children = Frontend.root.getChildren();
        children.add(children.size()-1, ViewLoader.generateTicketPopup(description, time));
    }

    public static void pushConfirmation(String message, Runnable callback) {
        ObservableList<Node> children = Frontend.root.getChildren();
        children.add(children.size()-1, ViewLoader.generateConfirmationScreen(message, callback));
    }

    public static void pop() {
        ObservableList<Node> children = Frontend.root.getChildren();
        Node node = children.remove(children.size()-2);
        if (callbacks.containsKey(node)) {
            callbacks.get(node).run();
            callbacks.remove(node);
        }
    }

    @Override
    public void stop() {
        Main.stop();
    }
}
