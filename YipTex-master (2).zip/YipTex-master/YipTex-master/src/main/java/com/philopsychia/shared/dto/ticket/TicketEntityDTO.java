package com.philopsychia.shared.dto.ticket;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
public class TicketEntityDTO {

    @Getter
    @Setter
    private GUID id;

    @Getter
    @Setter
    private GUID created_by;

    @Getter
    @Setter
    private GUID device_id;

    @Getter
    @Setter
    private String description;

    @Getter
    @Setter
    private LocalDateTime created_at;

    @Getter
    @Setter
    private Status status;
}
