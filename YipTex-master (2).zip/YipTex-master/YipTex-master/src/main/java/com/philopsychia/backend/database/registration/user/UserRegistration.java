package com.philopsychia.backend.database.registration.user;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;

public abstract class UserRegistration {
    private final GUID uuid;
    private final String password_hash;
    private final Role role;

    public UserRegistration(
            String password_hash,
            Role role
    ) {
        this.uuid = GUID.v7();
        this.password_hash = password_hash;
        this.role = role;
    }

    public String password_hash() {
        return password_hash;
    }

    public Role role() {
        return role;
    }

    public GUID uuid() {
        return uuid;
    }

    public byte[] idBytes() {
        return uuid.toBytes();
    }
}
