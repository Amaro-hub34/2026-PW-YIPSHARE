package com.philopsychia.frontend.control;

import com.philopsychia.frontend.Frontend;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class ConfirmationController {

    public Button ok;
    public Text message;
    public Button cancel;

    private Runnable onClose;

    public void setMessage(String message) {
        this.message.setText(message);
    }

    public void setCallback(Runnable onClose) {
        this.onClose = onClose;
    }

    public void ok(MouseEvent mouseEvent) {
        Frontend.pop();
        onClose.run();
    }

    public void cancel(MouseEvent mouseEvent) {
        Frontend.pop();
    }
}
