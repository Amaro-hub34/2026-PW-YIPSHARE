package com.philopsychia.frontend.control.technician;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import com.philopsychia.shared.dto.user.entity.TechnicianUserDTO;
import javafx.fxml.FXML;
import javafx.scene.text.Text;
import org.springframework.core.ParameterizedTypeReference;

public class AccountScreenController implements IController  {

    public Text identifier;

    public Text paternalSurnameSlot;
    public Text namesSlot;
    public Text institutionalEmail;
    public Text maternalSurnameSlot;
    public Text rfcSlot;

    @FXML
    private void initialize(){
    }

    @Override
    public void init() {

        RestClient.authorizedGetRequest(task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<BaseUserDTO> apiResponse = task.getValue();

                        if (!apiResponse.isError()) {
                            if (apiResponse.data() instanceof TechnicianUserDTO technician) {
                                identifier.setText(String.format("%s %s %s", technician.getName(), technician.getPaternal_surname(), technician.getMaternal_surname()));
                                paternalSurnameSlot.setText(technician.getPaternal_surname());
                                namesSlot.setText(technician.getName());
                                institutionalEmail.setText(technician.getInstitutional_email());
                                maternalSurnameSlot.setText(technician.getMaternal_surname());
                                rfcSlot.setText(technician.getRfc());
                            }
                        } else {
                            Frontend.pushPopup("Hubo un error inesperado");
                        }
                    });
                }, "/api/auth/me",
                new ParameterizedTypeReference<BaseUserDTO>() {});
    }
}