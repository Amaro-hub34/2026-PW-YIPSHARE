package com.philopsychia.backend.database.repository;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.driver.DatabaseDriver;
import com.philopsychia.backend.database.entity.user.UserEntity;
import com.philopsychia.backend.database.registration.user.*;
import com.philopsychia.backend.util.function.DataMappingUtil;
import com.philopsychia.shared.dto.user.*;
import com.philopsychia.shared.dto.user.entity.*;
import com.philopsychia.shared.dto.user.payload.*;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class UserRepository {

    private final DatabaseDriver databaseDriver;

    public UserRepository(DatabaseDriver databaseDriver) {
        this.databaseDriver = databaseDriver;
    }

    private static final String deleteUser
            = "DELETE FROM account WHERE id = ?";

    private static final String registerBaseUser
            = "INSERT INTO account (id, password_hash, role) VALUES (?, ?, ?)";
    private static final String registerNonAdminUser
            = "INSERT INTO profile (account_id, name, paternal_surname, maternal_surname, institutional_email) VALUES (?, ?, ?, ?, ?)";
    private static final String registerStudentUser
            = "INSERT INTO student_profile (account_id, student_id) VALUES (?, ?)";
    private static final String registerTeacherUser
            = "INSERT INTO teacher_profile (account_id, rfc) VALUES (?, ?)";
    private static final String registerTechnicianUser
            = "INSERT INTO technician_profile (account_id, rfc) VALUES (?, ?)";
    private static final String registerAdminUser
            = "INSERT INTO admin_profile (account_id, account_username) VALUES (?, ?)";

    private static final String updateBaseUser
            = "UPDATE account SET role = ? WHERE id = ?";

    private static final String updateNonAdminUser
            = "UPDATE profile SET name = ?, paternal_surname = ?, maternal_surname = ?, institutional_email = ? WHERE account_id = ?";

    private static final String updateStudentUser
            = "UPDATE student_profile SET student_id = ? WHERE account_id = ?";

    private static final String updateTeacherUser
            = "UPDATE teacher_profile SET rfc = ? WHERE account_id = ?";

    private static final String updateTechnicianUser
            = "UPDATE technician_profile SET rfc = ? WHERE account_id = ?";

    private static final String updateAdminUser
            = "UPDATE admin_profile SET account_username = ? WHERE account_id = ?";

    private static final String findStudentByStudentID
            = """
            SELECT * FROM student_profile
            INNER JOIN profile ON student_profile.account_id = profile.account_id
            INNER JOIN account ON student_profile.account_id = account.id
            WHERE student_id = ?
            """;
    private static final String findNonAdminUserByEmail
            = """
            SELECT * FROM profile
            INNER JOIN account ON profile.account_id = account.id
            LEFT JOIN student_profile ON profile.account_id = student_profile.account_id AND account.role = 'student'
            LEFT JOIN teacher_profile ON profile.account_id = teacher_profile.account_id AND account.role = 'teacher'
            LEFT JOIN technician_profile ON profile.account_id = technician_profile.account_id AND account.role = 'technician'
            WHERE institutional_email = ?
            """;
    private static final String findAdminByUsername
            = "SELECT * FROM admin_profile INNER JOIN account ON admin_profile.account_id = account.id WHERE account_username = ?";

    private static final String findRoleByUserId
            = "SELECT role FROM account WHERE id = ?";

    private static final String findUserByUserId
            = """
            SELECT * FROM account
            LEFT JOIN profile ON account.id = profile.account_id
            LEFT JOIN admin_profile ON account.id = admin_profile.account_id
            LEFT JOIN student_profile ON account.id = student_profile.account_id
            LEFT JOIN teacher_profile ON account.id = teacher_profile.account_id
            LEFT JOIN technician_profile ON account.id = technician_profile.account_id
            WHERE id = ?;
            """;

    private static final String findAllUsers
            = """
            SELECT * FROM account
            LEFT JOIN profile ON account.id = profile.account_id
            LEFT JOIN admin_profile ON account.id = admin_profile.account_id
            LEFT JOIN student_profile ON account.id = student_profile.account_id
            LEFT JOIN teacher_profile ON account.id = teacher_profile.account_id
            LEFT JOIN technician_profile ON account.id = technician_profile.account_id
            """;

    private static final String findTeacherUserByRfc
            = """
            SELECT * FROM profile
            INNER JOIN account ON profile.account_id = account.id
            LEFT JOIN teacher_profile ON profile.account_id = teacher_profile.account_id AND account.role = 'teacher'
            WHERE rfc = ?
            """;

    private static final String findTechnicianUserByRfc
            = """
            SELECT * FROM profile
            INNER JOIN account ON profile.account_id = account.id
            LEFT JOIN technician_profile ON profile.account_id = technician_profile.account_id AND account.role = 'technician'
            WHERE rfc = ?
            """;

    public List<BaseUserDTO> getAllUsers() {
        return databaseDriver.query(
                findAllUsers,
                DataMappingUtil::mapDataToUserDTO
        );
    }

    public Optional<BaseUserDTO> findUserByUserId(GUID userId) {
        return databaseDriver.queryOne(
                findUserByUserId,
                DataMappingUtil::mapDataToUserDTO,
                (Object) userId.toBytes()
        );
    }

    public Optional<Role> findRoleByUserId(GUID userId) {
        return databaseDriver.queryOne(
                findRoleByUserId,
                resultSet -> Role.parse(resultSet.getString("role")),
                (Object) userId.toBytes()
        );
    }

    public Optional<UserEntity> findAdminByUsername(String username) {
        return databaseDriver.queryOne(
                findAdminByUsername,
                DataMappingUtil::mapDataToUserEntity,
                username
        );
    }

    public Optional<UserEntity> findNonAdminUserByEmail(String email) {
        return databaseDriver.queryOne(
                findNonAdminUserByEmail,
                DataMappingUtil::mapDataToUserEntity,
                email
        );
    }

    public Optional<UserEntity> findTeacherUserByRfc(String rfc) {
        return databaseDriver.queryOne(
                findTeacherUserByRfc,
                DataMappingUtil::mapDataToUserEntity,
                rfc
        );
    }

    public Optional<UserEntity> findTechnicianUserByRfc(String rfc) {
        return databaseDriver.queryOne(
                findTechnicianUserByRfc,
                DataMappingUtil::mapDataToUserEntity,
                rfc
        );
    }

    public Optional<UserEntity> findStudentByStudentID(long id) {
        return databaseDriver.queryOne(
                findStudentByStudentID,
                DataMappingUtil::mapDataToUserEntity,
                id
        );
    }

    public void registerStudentUser(StudentUserRegistration studentUser) {
        registerBaseUser(studentUser);
        registerNonAdminUser(studentUser);
        databaseDriver.update(
                registerStudentUser,
                studentUser.idBytes(),
                studentUser.studentId()
        );
    }

    public void registerTeacherUser(TeacherUserRegistration teacherUser) {
        registerBaseUser(teacherUser);
        registerNonAdminUser(teacherUser);
        databaseDriver.update(
                registerTeacherUser,
                teacherUser.idBytes(),
                teacherUser.rfc()
        );
    }

    public void registerTechnicianUser(TechnicianUserRegistration technicianUser) {
        registerBaseUser(technicianUser);
        registerNonAdminUser(technicianUser);
        databaseDriver.update(
                registerTechnicianUser,
                technicianUser.idBytes(),
                technicianUser.rfc()
        );
    }

    public void registerAdminUser(AdminUserRegistration adminUser) {
        registerBaseUser(adminUser);
        databaseDriver.update(
                registerAdminUser,
                adminUser.idBytes(),
                adminUser.account_username()
        );
    }

    private void registerNonAdminUser(NonAdminUserRegistration nonAdminUser) {
        databaseDriver.update(
                registerNonAdminUser,
                nonAdminUser.idBytes(),
                nonAdminUser.name(),
                nonAdminUser.paternal_surname(),
                nonAdminUser.maternal_surname(),
                nonAdminUser.institutional_email()
        );
    }

    private void registerBaseUser(UserRegistration user) {
        databaseDriver.update(
                registerBaseUser,
                user.idBytes(),
                user.password_hash(),
                user.role().name().toLowerCase());
    }

    public void modifyStudentUser(StudentPayloadDTO studentUser, GUID userId) {
        modifyNonAdminUser(studentUser, userId);
        databaseDriver.update(
                updateStudentUser,
                studentUser.getStudentId(),
                userId.toBytes()
        );
    }

    public void modifyTeacherUser(TeacherPayloadDTO teacherUser, GUID userId) {
        modifyNonAdminUser(teacherUser, userId);
        databaseDriver.update(
                updateTeacherUser,
                teacherUser.getRfc(),
                userId.toBytes()
        );
    }

    public void modifyTechnicianUser(TechnicianPayloadDTO technicianUser, GUID userId) {
        modifyNonAdminUser(technicianUser, userId);
        databaseDriver.update(
                updateTechnicianUser,
                technicianUser.getRfc(),
                userId.toBytes()
        );
    }

    public void modifyAdminUser(AdminPayloadDTO adminUser, GUID userId) {
        modifyBaseUser(adminUser, userId);
        databaseDriver.update(
                updateAdminUser,
                adminUser.getUsername(),
                userId.toBytes()
        );
    }

    private void modifyNonAdminUser(NonAdminPayloadDTO nonAdminUser, GUID userId) {
        modifyBaseUser(nonAdminUser, userId);
        databaseDriver.update(
                updateNonAdminUser,
                nonAdminUser.getName(),
                nonAdminUser.getPaternal_surname(),
                nonAdminUser.getMaternal_surname(),
                nonAdminUser.getInstitutional_email(),
                userId.toBytes()
        );
    }

    private void modifyBaseUser(BasePayloadDTO baseUser, GUID userId) {
        databaseDriver.update(
                updateBaseUser,
                baseUser.getRole().name(),
                userId.toBytes()
        );
    }

    public void deleteUser(GUID id) {
        databaseDriver.update(
                deleteUser,
                (Object) id.toBytes());
    }
}
