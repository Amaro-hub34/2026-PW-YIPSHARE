package com.philopsychia.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.server.context.WebServerPortFileWriter;
import org.springframework.context.ConfigurableApplicationContext;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

@SpringBootApplication
public class Backend {

    public static ConfigurableApplicationContext run(){
        SpringApplication app = new SpringApplication(Backend.class);

        try {
            String homeDir = System.getProperty("user.home");
            String folderPath = homeDir + File.separator + ".philopsychia" + File.separator + "yiptex";

            Files.createDirectories(Paths.get(folderPath));

            String fullFilePath = folderPath + File.separator + "yiptex.port";
            app.addListeners(new WebServerPortFileWriter(fullFilePath));

        } catch (Exception e) {
            System.err.println("CRITICAL: Failed to setup port file path: " + e.getMessage());
            System.err.println("The application will start, but the frontend may not be able to find it.");
        }

        return app.run();
    }
}
