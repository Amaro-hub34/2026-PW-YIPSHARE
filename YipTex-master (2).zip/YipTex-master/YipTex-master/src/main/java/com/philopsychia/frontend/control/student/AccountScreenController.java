package com.philopsychia.frontend.control.student;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.StudentUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import javafx.fxml.FXML;
import javafx.scene.text.Text;
import org.springframework.core.ParameterizedTypeReference;

public class AccountScreenController implements IController  {

    public Text identifier;

    public Text paternalSurnameSlot;
    public Text namesSlot;
    public Text institutionalEmail;
    public Text maternalSurnameSlot;
    public Text studentIdSlot;

    @FXML
    private void initialize(){
    }

    @Override
    public void init() {

        RestClient.authorizedGetRequest(task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<BaseUserDTO> apiResponse = task.getValue();

                        if (!apiResponse.isError()) {
                            if (apiResponse.data() instanceof StudentUserDTO student) {
                                identifier.setText(String.format("%s %s %s", student.getName(), student.getPaternal_surname(), student.getMaternal_surname()));
                                paternalSurnameSlot.setText(student.getPaternal_surname());
                                namesSlot.setText(student.getName());
                                institutionalEmail.setText(student.getInstitutional_email());
                                maternalSurnameSlot.setText(student.getMaternal_surname());
                                studentIdSlot.setText(String.valueOf(student.getStudentId()));
                            }
                        } else {
                            Frontend.pushPopup("Hubo un error inesperado");
                        }
                    });
                }, "/api/auth/me",
                new ParameterizedTypeReference<BaseUserDTO>() {});
    }
}