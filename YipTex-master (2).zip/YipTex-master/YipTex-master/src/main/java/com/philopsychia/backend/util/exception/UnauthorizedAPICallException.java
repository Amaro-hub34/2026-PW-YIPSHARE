package com.philopsychia.backend.util.exception;

public class UnauthorizedAPICallException extends RuntimeException {
    public UnauthorizedAPICallException(String message) {
        super(message);
    }
}
