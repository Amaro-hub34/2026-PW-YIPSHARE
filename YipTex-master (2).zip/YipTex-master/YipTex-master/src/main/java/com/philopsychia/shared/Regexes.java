package com.philopsychia.shared;

import java.util.regex.Pattern;

public final class Regexes {
    public static final Pattern passwordRegex
            = Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[\\W_])[!-~][ -~]{4,253}[!-~]$");
    public static final Pattern nameRegex
            = Pattern.compile("^[\\p{L}\\s'-]+$");
    public static final Pattern surnameRegex
            = Pattern.compile("^[\\p{L}'-]+$");
    public static final Pattern institutionalEmailRegex
            = Pattern.compile("^[a-z0-9.]+@(alumno\\.ipn\\.mx|ipn\\.mx)$");
    public static final Pattern institutionalEmailStudentRegex
            = Pattern.compile("^[a-z0-9.]+@alumno\\.ipn\\.mx$");
    public static final Pattern institutionalEmailNonStudentRegex
            = Pattern.compile("^[a-z0-9.]+@(ipn\\.mx)$");
    public static final Pattern studentIdRegex
            = Pattern.compile("^\\d{10}$");
    public static final Pattern groupRegex
            = Pattern.compile("^\\dI[VM]\\d{1,2}$");
    public static final Pattern rfcRegex
            = Pattern.compile("^[A-ZÑ\\x26]{4}[0-9]{2}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])[A-Z0-9]{3}$");
    public static final Pattern machineAmountRegex
            = Pattern.compile("^\\d+$");
}
