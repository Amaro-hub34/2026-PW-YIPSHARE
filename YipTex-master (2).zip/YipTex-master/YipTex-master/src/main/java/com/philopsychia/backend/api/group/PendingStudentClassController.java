package com.philopsychia.backend.api.group;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.repository.MappingRepository;
import com.philopsychia.backend.service.auth.AuthService;
import com.philopsychia.backend.service.mapping.MappingEntryService;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.mapping_table.MappingEntryDTO;
import com.philopsychia.shared.dto.user.Role;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@PreAuthorize("hasAnyAuthority('ADMIN', 'TEACHER')")
@RequestMapping("/api/classes/{class_id}/pending_students")
public class PendingStudentClassController {

    private final MappingEntryService mappingEntryService;
    private final AuthService authService;

    public PendingStudentClassController(MappingEntryService mappingEntryService, AuthService authService) {
        this.mappingEntryService = mappingEntryService;
        this.authService = authService;
    }

    @PostMapping
    public void registerPendingStudentEntry(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("class_id") GUID class_id, @RequestBody GUID pendingStudentId) {
        mappingEntryService.createMappingEntry(new MappingEntryDTO(pendingStudentId, class_id), MappingRepository.MappingTable.PENDING_STUDENT_CLASS);
    }

    @GetMapping
    public List<MappingEntryDTO> getPendingStudents(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("class_id") GUID class_id) {
        return mappingEntryService.getMappingEntries(null, class_id, MappingRepository.MappingTable.PENDING_STUDENT_CLASS);
    }

    @GetMapping("/{user_id}")
    public Optional<MappingEntryDTO> getPendingStudent(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("class_id") GUID class_id, @PathVariable("user_id") GUID user_id) {
        if (user_id != null && authService.getUserInformation(user_id).getRole() !=  Role.STUDENT) throw new ResourceNotFound("Given id did not map to a student");
        return Optional.ofNullable(mappingEntryService.getMappingEntries(user_id, class_id, MappingRepository.MappingTable.PENDING_STUDENT_CLASS).getFirst());
    }

    @DeleteMapping("/{user_id}")
    public void deletePendingStudentEntry(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("class_id") GUID class_id, @PathVariable("user_id") GUID user_id) {
        if (authService.getUserInformation(user_id).getRole() !=  Role.STUDENT) throw new ResourceNotFound("Given id did not map to a student");
        mappingEntryService.deleteMappingEntries(user_id, class_id, MappingRepository.MappingTable.PENDING_STUDENT_CLASS);
    }

}
