package com.philopsychia.shared.dto.group;

import com.philopsychia.shared.dto.user.Role;
import org.jspecify.annotations.NonNull;

public enum Schedule {
    MORNING,
    EVENING;

    public static Schedule parse(String value) {
        value = value.toUpperCase().trim();
        return Schedule.valueOf(value);
    }
}
