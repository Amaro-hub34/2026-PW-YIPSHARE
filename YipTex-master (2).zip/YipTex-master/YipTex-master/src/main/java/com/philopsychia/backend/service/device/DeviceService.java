package com.philopsychia.backend.service.device;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.registration.device.DeviceRegistration;
import com.philopsychia.backend.database.repository.DeviceRepository;
import com.philopsychia.backend.database.repository.RoomRepository;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.device.DevicePayloadDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DeviceService {

    private final DeviceRepository deviceRepository;
    private final RoomRepository roomRepository;

    public DeviceService(DeviceRepository deviceRepository, RoomRepository roomRepository) {
        this.deviceRepository = deviceRepository;
        this.roomRepository = roomRepository;
    }

    public DeviceEntityDTO getDevice(GUID id) {
        Optional<DeviceEntityDTO> data = deviceRepository.getDeviceById(id);
        if (data.isPresent()) return data.get();
        else throw new ResourceNotFound("Resource not found");
    }

    public DeviceEntityDTO getDevice(int numberId, GUID roomId) {
        Optional<DeviceEntityDTO> data = deviceRepository.getDeviceByNumberIdAndRoom(numberId, roomId);
        if (data.isPresent()) return data.get();
        else throw new ResourceNotFound("Resource not found");
    }

    public void modifyDevice(GUID uuid, DevicePayloadDTO dto) {
        if (deviceRepository.getDeviceById(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        deviceRepository.modifyDevice(uuid, dto);
    }

    public void deleteDevice(GUID uuid) {
        if (deviceRepository.getDeviceById(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        deviceRepository.deleteDevice(uuid);
    }

    public List<DeviceEntityDTO> getAllDevices(GUID room_id) {
        if (roomRepository.getRoomById(room_id).isEmpty()) throw new ResourceNotFound("Invalid room_id reference");
        return deviceRepository.getAllDevicesFromRoom(room_id);
    }

    public List<DeviceEntityDTO> getAllDevices() {
        return deviceRepository.getAllDevices();
    }

    public void createDevice(DevicePayloadDTO dto) {
        if (roomRepository.getRoomById(dto.getRoom_id()).isEmpty()) throw new ResourceNotFound("Invalid room_id reference");
        deviceRepository.registerDevice(new DeviceRegistration(dto.getNumber_id(), dto.getRoom_id()));
    }
}
