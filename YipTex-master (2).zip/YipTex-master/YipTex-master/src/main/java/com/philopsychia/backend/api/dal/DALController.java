package com.philopsychia.backend.api.dal;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.service.dal.DALService;
import com.philopsychia.shared.dto.dal.DALEntityDTO;
import com.philopsychia.shared.dto.dal.DALPayloadDTO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAuthority('ADMIN')")
@RequestMapping("/api/dal")
public class DALController {


    private final DALService dALService;

    public DALController(DALService dALService) {
        this.dALService = dALService;
    }

    @GetMapping
    public List<DALEntityDTO> getAllDALEntries(@AuthenticationPrincipal UserDetails userDetails) {
        return dALService.getAllDALEntries();
    }

    @GetMapping("/{uuid}")
    public List<DALEntityDTO> getAllDALEntriesByUser(@AuthenticationPrincipal UserDetails userDetails, @PathVariable(name = "uuid") GUID uuid) {
        return dALService.getAllDALEntriesByUser(uuid);
    }

    @DeleteMapping("/{uuid}")
    public void deleteAllDALEntriesById(@AuthenticationPrincipal UserDetails userDetails, @PathVariable(name = "uuid") GUID uuid) {
        dALService.deleteAllDALEntriesById(uuid);
    }

    @PostMapping
    public void createDALEntry(@AuthenticationPrincipal UserDetails userDetails, @RequestBody DALPayloadDTO dto) {
        dALService.createDALEntry(dto);
    }
}
