package com.philopsychia.backend.database.repository;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.driver.DatabaseDriver;
import com.philopsychia.backend.database.registration.group.ClassRegistration;
import com.philopsychia.backend.util.function.DataMappingUtil;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class ClassRepository {

    private final DatabaseDriver databaseDriver;

    public ClassRepository(DatabaseDriver databaseDriver) {
        this.databaseDriver = databaseDriver;
    }
    
    private static final String insertClass
            = "INSERT INTO class (id, name, schedule, primary_teacher_id) VALUES (?, ?, ?, ?)";

    private static final String modifyClass
            = "UPDATE class SET name = ?, schedule = ?, primary_teacher_id = ? WHERE id = ?";

    private static final String deleteClass
            = "DELETE FROM class WHERE id = ?";

    private static final String getAllClasses
            = "SELECT * FROM class";

    private static final String getClassById =
            "SELECT * FROM class WHERE id = ?";

    private static final String getClassByName =
            "SELECT * FROM class WHERE name = ?";

    private static final String getClassesByTeacher =
            "SELECT * FROM class WHERE primary_teacher_id = ?";

    public List<ClassEntityDTO> getAllClasses() {
        return databaseDriver.query(
                getAllClasses,
                DataMappingUtil::mapDataToClassDTO
        );
    }

    public List<ClassEntityDTO> getClassesByTeacher(GUID teacher) {
        return databaseDriver.query(
                getClassesByTeacher,
                DataMappingUtil::mapDataToClassDTO,
                (Object) teacher.toBytes()
        );
    }

    public Optional<ClassEntityDTO> getClassById(GUID uuid) {
        return databaseDriver.queryOne(
                getClassById,
                DataMappingUtil::mapDataToClassDTO,
                (Object) uuid.toBytes()
        );
    }

    public Optional<ClassEntityDTO> getClassByName(String name) {
        return databaseDriver.queryOne(
                getClassByName,
                DataMappingUtil::mapDataToClassDTO,
                name
        );
    }

    public void registerClass(ClassRegistration classRegistration) {
        databaseDriver.update(
                insertClass,
                classRegistration.getId().toBytes(),
                classRegistration.getName(),
                classRegistration.getSchedule().name(),
                classRegistration.getPrimary_teacher_id().toBytes()
        );
    }

    public void modifyClass(GUID id,  ClassPayloadDTO payload) {
        databaseDriver.update(
                modifyClass,
                payload.getName(),
                payload.getSchedule().name(),
                payload.getPrimary_teacher_id().toBytes(),
                id.toBytes()
        );
    }

    public void deleteClass(GUID id) {
        databaseDriver.update(
                deleteClass,
                (Object) id.toBytes()
        );
    }
}
