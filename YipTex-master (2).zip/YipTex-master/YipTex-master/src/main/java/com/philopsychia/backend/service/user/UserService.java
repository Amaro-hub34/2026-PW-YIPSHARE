package com.philopsychia.backend.service.user;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.entity.user.UserEntity;
import com.philopsychia.backend.database.repository.UserRepository;
import com.philopsychia.backend.service.auth.AuthService;
import com.philopsychia.backend.util.exception.BadRequestException;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.user.entity.*;
import com.philopsychia.shared.dto.user.payload.*;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;
    public UserService(UserRepository userRepository, AuthService authService) {
        this.userRepository = userRepository;
    }

    public List<BaseUserDTO> getAllUsers() {
        return userRepository.getAllUsers();
    }

    public void deleteUser(GUID uuid) {
        if (userRepository.findUserByUserId(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        userRepository.deleteUser(uuid);
    }

    public void modify(BasePayloadDTO request, GUID userId) {
        switch (request.getRole()) {
            case ADMIN -> {
                if (request instanceof AdminPayloadDTO adminDTO) {
                    Optional<UserEntity> adminByUsername = userRepository.findAdminByUsername(adminDTO.getUsername());
                    if (adminByUsername.isPresent() && !adminByUsername.get().id().equals(userId))
                        throw new BadRequestException("Resource already exists");
                    userRepository.modifyAdminUser(adminDTO, userId);
                    return;
                } else {
                    throw new BadRequestException("DTO data validation failed");
                }
            }
            case STUDENT -> {
                if (request instanceof StudentPayloadDTO studentDTO) {
                    Optional<UserEntity> nonAdminByEmail = userRepository.findNonAdminUserByEmail(studentDTO.getInstitutional_email());
                    Optional<UserEntity> studentByStudentId = userRepository.findStudentByStudentID(studentDTO.getStudentId());
                    if (nonAdminByEmail.isPresent() && !nonAdminByEmail.get().id().equals(userId)
                    || (studentByStudentId.isPresent() && !studentByStudentId.get().id().equals(userId)))
                        throw new BadRequestException("Resource already exists");
                    userRepository.modifyStudentUser(studentDTO, userId);
                    return;
                } else {
                    throw new BadRequestException("DTO data validation failed");
                }
            }
            case TEACHER -> {
                if (request instanceof TeacherPayloadDTO teacherDTO) {
                    Optional<UserEntity> nonAdminByEmail = userRepository.findNonAdminUserByEmail(teacherDTO.getInstitutional_email());
                    Optional<UserEntity> teacherByRFC = userRepository.findTeacherUserByRfc(teacherDTO.getRfc());
                    if ((nonAdminByEmail.isPresent() && !nonAdminByEmail.get().id().equals(userId))
                    || (teacherByRFC.isPresent() && !teacherByRFC.get().id().equals(userId)))
                        throw new BadRequestException("Resource already exists");
                    userRepository.modifyTeacherUser(teacherDTO, userId);
                    return;
                } else {
                    throw new BadRequestException("DTO data validation failed");
                }
            }
            case TECHNICIAN -> {
                if (request instanceof TechnicianPayloadDTO technicianDTO) {
                    Optional<UserEntity> nonAdminByEmail = userRepository.findNonAdminUserByEmail(technicianDTO.getInstitutional_email());
                    Optional<UserEntity> technicianByRFC = userRepository.findTeacherUserByRfc(technicianDTO.getRfc());
                    if ((nonAdminByEmail.isPresent() && !nonAdminByEmail.get().id().equals(userId))
                            || (technicianByRFC.isPresent() && !technicianByRFC.get().id().equals(userId)))
                        throw new BadRequestException("Resource already exists");
                    userRepository.modifyTechnicianUser(technicianDTO, userId);
                    return;

                } else {
                    throw new BadRequestException("Unexpected type found while trying to parse a request with role of student");
                }
            }
        }
        throw new IllegalStateException("Unexpected exception happened while attempting to register an account");
    }
}
