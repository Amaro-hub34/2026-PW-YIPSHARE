package com.philopsychia.shared.dto.user.payload;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

public class TechnicianPayloadDTO extends NonAdminPayloadDTO {
    @Getter
    @Setter
    private String rfc;

    public TechnicianPayloadDTO() {}

    public TechnicianPayloadDTO(String rfc, String name, String paternal_surname, String maternal_surname, String institutional_email) {
        super(name, paternal_surname, maternal_surname, institutional_email, Role.TECHNICIAN);
        this.rfc = rfc;
    }
}
