package com.philopsychia.backend.database.repository;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.driver.DatabaseDriver;
import com.philopsychia.backend.database.registration.dal.DALRegistration;
import com.philopsychia.backend.database.registration.ticket.TicketRegistration;
import com.philopsychia.backend.util.function.DataMappingUtil;
import com.philopsychia.shared.dto.dal.DALEntityDTO;
import com.philopsychia.shared.dto.ticket.TicketEntityDTO;
import com.philopsychia.shared.dto.ticket.TicketPayloadDTO;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class DALRepository {

    private final DatabaseDriver databaseDriver;

    public DALRepository(DatabaseDriver databaseDriver) {
        this.databaseDriver = databaseDriver;
    }
    
    private static final String insertDALEntry
            = "INSERT INTO device_assignment_log (id, user_id, device_id, class_id, assignment_reason) VALUES (?, ?, ?, ?, ?)";

    private static final String getDALEntries
            = "SELECT * FROM device_assignment_log";

    private static final String getDALEntryById =
            "SELECT * FROM device_assignment_log WHERE id = ?";

    private static final String getDALEntryByUser =
            "SELECT * FROM device_assignment_log WHERE user_id = ?";

    private static final String deleteDALEntryByUser =
            "DELETE FROM device_assignment_log WHERE id = ?";

    private static final String getDALEntryByComposite =
            "SELECT * FROM device_assignment_log WHERE user_id = ? AND device_id = ? AND class_id = ?";



    public List<DALEntityDTO> getAllDALEntries() {
        return databaseDriver.query(
                getDALEntries,
                DataMappingUtil::mapDataToDALDTO
        );
    }

    public List<DALEntityDTO> getAllDALEntriesByUser(GUID userId) {
        return databaseDriver.query(
                getDALEntryByUser,
                DataMappingUtil::mapDataToDALDTO,
                (Object) userId.toBytes()
        );
    }

    public Optional<DALEntityDTO> getDALEntryByComposite(GUID userId, GUID deviceId, GUID classId) {
        return databaseDriver.queryOne(
                getDALEntryByComposite,
                DataMappingUtil::mapDataToDALDTO,
                userId.toBytes(),
                deviceId.toBytes(),
                classId.toBytes()
        );
    }

    public void deleteAllDALEntriesById(GUID uuid) {
        databaseDriver.update(
                deleteDALEntryByUser,
                (Object) uuid.toBytes()
        );
    }

    public Optional<DALEntityDTO> getDALEntryById(GUID uuid) {
        return databaseDriver.queryOne(
                getDALEntryById,
                DataMappingUtil::mapDataToDALDTO,
                (Object) uuid.toBytes()
        );
    }

    public void registerDALEntry(DALRegistration ticketRegistration) {
        databaseDriver.update(
                insertDALEntry,
                ticketRegistration.getId().toBytes(),
                ticketRegistration.getUser_id().toBytes(),
                ticketRegistration.getDevice_id().toBytes(),
                ticketRegistration.getClass_id().toBytes(),
                ticketRegistration.getAssignment_reason()
        );
    }
}
