package com.philopsychia.frontend.util;

import org.springframework.http.HttpStatus;

public record ApiResponse<T>(T data, HttpStatus code) {

    public static <T> ApiResponse<T> error(HttpStatus code) {
        return new ApiResponse<>(null, code);
    }

    public static <T> ApiResponse<T> ok(T data, HttpStatus code) {
        return new ApiResponse<>(data, code);
    }

    public boolean isError() {
        return code.isError();
    }
}
