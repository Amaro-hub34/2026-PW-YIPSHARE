package com.philopsychia.backend.database.registration.ticket;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.ticket.Status;
import lombok.Getter;
import lombok.Setter;

import java.time.Instant;

public class TicketRegistration {

    @Getter
    private final GUID id;

    @Getter
    @Setter
    private GUID created_by;

    @Getter
    @Setter
    private GUID device_id;


    @Getter
    @Setter
    private String description;

    @Getter
    @Setter
    private Status status;

    public TicketRegistration(GUID created_by, GUID device_id, String description, Status status) {
        this.id = GUID.v7();
        this.created_by = created_by;
        this.device_id = device_id;
        this.description = description;
        this.status = status;
    }
}
