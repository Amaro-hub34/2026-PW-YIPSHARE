package com.philopsychia.backend.service.mapping;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.repository.ClassRepository;
import com.philopsychia.backend.database.repository.MappingRepository;
import com.philopsychia.backend.database.repository.UserRepository;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.mapping_table.MappingEntryDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import jakarta.annotation.Nullable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MappingEntryService {

    private final MappingRepository mappingEntryRepository;
    private final UserRepository userRepository;
    private final ClassRepository classRepository;

    public MappingEntryService(MappingRepository mappingEntryRepository, UserRepository userRepository, ClassRepository classRepository) {
        this.mappingEntryRepository = mappingEntryRepository;
        this.userRepository = userRepository;
        this.classRepository = classRepository;
    }

    public List<MappingEntryDTO> getMappingEntries(@Nullable GUID user_id, @Nullable GUID class_id, MappingRepository.MappingTable mappingTable) {
        if (user_id == null && class_id != null) return mappingEntryRepository.getMappingEntryDTOByClass(class_id, mappingTable);
        if (class_id == null && user_id != null) return mappingEntryRepository.getMappingEntryDTOByUser(user_id, mappingTable);
        if (class_id != null && user_id != null) return mappingEntryRepository.getMappingEntryDTOByComposite(user_id, class_id, mappingTable);
        return mappingEntryRepository.getAllMappingEntries(mappingTable);
    }

    public void deleteMappingEntries(@Nullable GUID user_id, @Nullable GUID class_id, MappingRepository.MappingTable mappingTable) {
        if (user_id == null && class_id != null) mappingEntryRepository.deleteMappingEntryByClass(class_id, mappingTable);
        if (class_id == null && user_id != null) mappingEntryRepository.deleteMappingEntryByUser(user_id, mappingTable);
        if (class_id != null && user_id != null) mappingEntryRepository.deleteMappingEntryByComposite(class_id, user_id, mappingTable);
    }

    public void createMappingEntry(MappingEntryDTO dto, MappingRepository.MappingTable mappingTable) {
        validate(dto);
        mappingEntryRepository.registerMappingEntry(dto, mappingTable);
    }

    private void validate(MappingEntryDTO dto) {
        Optional<BaseUserDTO> user = userRepository.findUserByUserId(dto.getUser_id());
        Optional<ClassEntityDTO> group = classRepository.getClassById(dto.getClass_id());
        if (user.isEmpty()) throw new ResourceNotFound("Invalid user_id reference");
        else if (group.isEmpty()) throw new ResourceNotFound("Invalid class_id reference");
    }
}
