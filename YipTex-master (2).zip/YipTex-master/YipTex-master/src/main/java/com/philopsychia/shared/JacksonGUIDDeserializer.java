package com.philopsychia.shared;

import com.github.f4b6a3.uuid.alt.GUID;
import org.springframework.boot.jackson.JacksonComponent;
import tools.jackson.core.JacksonException;
import tools.jackson.core.JsonParser;
import tools.jackson.databind.DeserializationContext;
import tools.jackson.databind.ValueDeserializer;

@JacksonComponent
public class JacksonGUIDDeserializer extends ValueDeserializer<GUID> {

    @Override
    public GUID deserialize(JsonParser p, DeserializationContext ctxt) throws JacksonException {
        String val = p.getValueAsString();
        return (val != null && !val.isBlank()) ? new GUID(val) : null;
    }
}