package com.philopsychia.backend.database.repository;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.driver.DatabaseDriver;
import com.philopsychia.backend.database.registration.ticket.TicketRegistration;
import com.philopsychia.backend.util.function.DataMappingUtil;
import com.philopsychia.shared.dto.ticket.TicketEntityDTO;
import com.philopsychia.shared.dto.ticket.TicketPayloadDTO;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class TicketRepository {

    private final DatabaseDriver databaseDriver;

    public TicketRepository(DatabaseDriver databaseDriver) {
        this.databaseDriver = databaseDriver;
    }
    
    private static final String insertTicket
            = "INSERT INTO ticket (id, created_by, device_id, description, status) VALUES (?, ?, ?, ?, ?)";

    private static final String modifyTicket
            = "UPDATE ticket SET created_by = ?, device_id = ?, description = ?, status = ? WHERE id = ?";

    private static final String deleteTicket
            = "DELETE FROM ticket WHERE id = ?";

    private static final String getAllTickets
            = "SELECT * FROM ticket";

    private static final String getTicketById =
            "SELECT * FROM ticket WHERE id = ?";

    private static final String getTicketByDeviceId =
            "SELECT * FROM ticket WHERE device_id = ?";

    private static final String getTicketByUserId =
            "SELECT * FROM ticket WHERE created_by = ?";

    public List<TicketEntityDTO> getAllTickets() {
        return databaseDriver.query(
                getAllTickets,
                DataMappingUtil::mapDataToTicketDTO
        );
    }

    public List<TicketEntityDTO> getAllTicketsByDeviceId(GUID id) {
        return databaseDriver.query(
                getTicketByDeviceId,
                DataMappingUtil::mapDataToTicketDTO,
                (Object) id.toBytes()
        );
    }

    public List<TicketEntityDTO> getAllTicketsByUserId(GUID id) {
        return databaseDriver.query(
                getTicketByUserId,
                DataMappingUtil::mapDataToTicketDTO,
                (Object) id.toBytes()
        );
    }

    public Optional<TicketEntityDTO> getTicketById(GUID uuid) {
        return databaseDriver.queryOne(
                getTicketById,
                DataMappingUtil::mapDataToTicketDTO,
                (Object) uuid.toBytes()
        );
    }

    public void registerTicket(TicketRegistration ticketRegistration) {
        databaseDriver.update(
                insertTicket,
                ticketRegistration.getId().toBytes(),
                ticketRegistration.getCreated_by().toBytes(),
                ticketRegistration.getDevice_id().toBytes(),
                ticketRegistration.getDescription(),
                ticketRegistration.getStatus().getValue()
        );
    }

    public void modifyTicket(GUID id,  TicketPayloadDTO payload) {
        databaseDriver.update(
                modifyTicket,
                payload.getCreated_by().toBytes(),
                payload.getDevice_id().toBytes(),
                payload.getDescription(),
                payload.getStatus().getValue(),
                id.toBytes()
        );
    }

    public void deleteTicket(GUID id) {
        databaseDriver.update(
                deleteTicket,
                (Object) id.toBytes()
        );
    }
}
