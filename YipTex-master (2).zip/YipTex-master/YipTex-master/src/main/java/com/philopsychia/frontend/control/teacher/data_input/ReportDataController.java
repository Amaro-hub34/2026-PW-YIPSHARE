package com.philopsychia.frontend.control.teacher.data_input;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.control.util.IWithCallback;
import com.philopsychia.frontend.control.util.IWithLoadFunction;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ScreenUtil;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.room.RoomPayloadDTO;
import com.philopsychia.shared.dto.ticket.Status;
import com.philopsychia.shared.dto.ticket.TicketEntityDTO;
import com.philopsychia.shared.dto.ticket.TicketPayloadDTO;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import org.controlsfx.control.textfield.CustomTextField;
import org.springframework.core.ParameterizedTypeReference;

import java.util.List;

public class ReportDataController extends IWithCallback<TicketPayloadDTO> implements IController, IWithLoadFunction<GUID> {

    private static final String INVALID_NUMBER = "El numero ingresado es invalido";
    private static final String INVALID_SELECTION = "Seleccione una opcion";

    public Button returnButton;
    public GridPane gridContainer;

    public VBox roomVbox;
    public ChoiceBox<String> roomField;

    public VBox numberIdVbox;
    public CustomTextField numberIdField;

    public VBox descriptionVBox;

    public Button next;
    public TextArea descriptionField;

    private List<GUID> roomIds = new ObjectArrayList<>();
    private GUID user;

    @FXML
    private void initialize() {
    }

    public void tryNext(MouseEvent mouseEvent) {
        cleanGUI();

        boolean passed = true;

        int roomSelection = roomField.getSelectionModel().getSelectedIndex();
        if (roomSelection == 0) {
            roomVbox.getChildren().add(ScreenUtil.generateErrorMessage(INVALID_SELECTION));
            passed = false;
        }

        String device_id_txt = numberIdField.getText().trim();
        int number_id = -1;
        try {
            number_id = Integer.parseInt(device_id_txt);
            if (number_id <= 0) {
                throw new IllegalStateException("Number must not be negative");
            }
        } catch (Exception e) {
            numberIdVbox.getChildren().add(ScreenUtil.generateErrorMessage(INVALID_NUMBER));
            passed = false;
        }

        if (!passed) return;

        RestClient.authorizedGetRequest(t -> {
                    Frontend.loadingOverlay.bindToTask(t);
                    t.setOnSucceeded(e -> {
                        ApiResponse<List<DeviceEntityDTO>> apiResponse = t.getValue();

                        if (apiResponse.isError()) {
                            Frontend.pushPopup("Porfavor revise que su informacion sea correcta");
                        } else {
                            this.callback.accept(new TicketPayloadDTO(
                                    user,
                                    apiResponse.data().getFirst().getId(),
                                    descriptionField.getText(),
                                    Status.OPEN
                            ));
                        }
                    });
                }, "/api/devices?number_id={number_id}&room_id={room_id}",
                new ParameterizedTypeReference<List<DeviceEntityDTO>>() {},
                number_id, this.roomIds.get(roomSelection-1));
    }

    public void returnToPrevious(MouseEvent mouseEvent) {
        Frontend.pop();
    }

    private void cleanGUI() {
        numberIdVbox.getChildren().removeIf(node -> (node instanceof HBox));
        roomVbox.getChildren().removeIf(node -> (node instanceof HBox));
        descriptionVBox.getChildren().removeIf(node -> (node instanceof HBox));
    }

    @Override
    public void init() {
        roomField.getItems().addAll("Seleccione un laboratorio");

        RestClient.authorizedGetRequest(
                task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<List<RoomEntityDTO>> apiResponse = task.getValue();

                        if (apiResponse.isError()) {
                            ViewLoader.generatePopup("Hubo un error insperado");
                        } else {
                            int i = 0;
                            List<RoomEntityDTO> rooms = apiResponse.data();

                            for (RoomEntityDTO room : rooms) {
                                i++;

                                roomIds.add(room.getId());
                                roomField.getItems().add(room.getName());
                            }
                        }
                    });
                }, "/api/rooms/teacher",
                new ParameterizedTypeReference<List<RoomEntityDTO>>() {}
        );

        roomField.getSelectionModel().select(0);
    }

    @Override
    public void load(GUID input) {
        if (input == null) return;
        this.user = input;
    }
}
