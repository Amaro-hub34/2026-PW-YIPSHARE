package com.philopsychia.backend.database.repository;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.driver.DatabaseDriver;
import com.philopsychia.backend.database.registration.group.ClassRegistration;
import com.philopsychia.backend.util.function.DataMappingUtil;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.mapping_table.MappingEntryDTO;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class MappingRepository {

    private final DatabaseDriver databaseDriver;

    public MappingRepository(DatabaseDriver databaseDriver) {
        this.databaseDriver = databaseDriver;
    }
    
    private static final String insertMappingEntry
            = "INSERT INTO %s (user_id, class_id) VALUES (?, ?)";
    
    private static final String deleteMappingEntryByUserId
            = "DELETE FROM %s WHERE user_id = ?";

    private static final String deleteMappingEntryByClassId
            = "DELETE FROM %s WHERE class_id = ?";

    private static final String deleteMappingEntryByCompositeId
            = "DELETE FROM %s WHERE class_id = ? AND user_id = ?";

    private static final String getAllMappingEntries
            = "SELECT * FROM %s";

    private static final String getMappingEntryByUserId =
            "SELECT * FROM %s WHERE user_id = ?";

    private static final String getMappingEntryByClassId =
            "SELECT * FROM %s WHERE class_id = ?";

    private static final String getMappingEntryByCompositeId =
            "SELECT * FROM %s WHERE user_id = ? AND class_id = ?";

    public List<MappingEntryDTO> getAllMappingEntries(MappingTable mappingTable) {
        return databaseDriver.query(
                String.format(getAllMappingEntries, mappingTable.getName()),
                DataMappingUtil::mapDataToMappingEntryDTO
        );
    }

    public List<MappingEntryDTO> getMappingEntryDTOByClass(GUID class_id, MappingTable mappingTable) {
        return databaseDriver.query(
                String.format(getMappingEntryByClassId, mappingTable.getName()),
                DataMappingUtil::mapDataToMappingEntryDTO,
                (Object) class_id.toBytes()
        );
    }

    public List<MappingEntryDTO> getMappingEntryDTOByUser(GUID user_id, MappingTable mappingTable) {
        return databaseDriver.query(
                String.format(getMappingEntryByUserId, mappingTable.getName() ),
                DataMappingUtil::mapDataToMappingEntryDTO,
                (Object) user_id.toBytes()
        );
    }

    public List<MappingEntryDTO> getMappingEntryDTOByComposite(GUID user_id, GUID class_id, MappingTable mappingTable) {
        return databaseDriver.query(
                String.format(getMappingEntryByCompositeId, mappingTable.getName()),
                DataMappingUtil::mapDataToMappingEntryDTO,
                user_id.toBytes(),
                class_id.toBytes()
        );
    }

    public void registerMappingEntry(MappingEntryDTO mappingEntryDTO, MappingTable mappingTable) {
        databaseDriver.update(
                String.format(insertMappingEntry, mappingTable.getName()),
                mappingEntryDTO.getUser_id().toBytes(),
                mappingEntryDTO.getClass_id().toBytes()
        );
    }

    public void deleteMappingEntryByUser(GUID user_id, MappingTable mappingTable) {
        databaseDriver.update(
                String.format(deleteMappingEntryByUserId, mappingTable.getName()),
                (Object) user_id.toBytes()
        );
    }

    public void deleteMappingEntryByClass(GUID class_id, MappingTable mappingTable) {
        databaseDriver.update(
                String.format(deleteMappingEntryByClassId, mappingTable.getName()),
                (Object) class_id.toBytes()
        );
    }

    public void deleteMappingEntryByComposite(GUID class_id, GUID user_id, MappingTable mappingTable) {
        databaseDriver.update(
                String.format(deleteMappingEntryByCompositeId, mappingTable.getName()),
                class_id.toBytes(),
                user_id.toBytes()
        );
    }

    public enum MappingTable {
        STUDENT_CLASS("student_class"),
        PENDING_STUDENT_CLASS("pending_student_class"),
        AUXILIARY_TEACHER_CLASS("auxiliary_teacher_class");

        private final String tableName;
        MappingTable(String tableName) { this.tableName = tableName; }
        public String getName() { return tableName; }
    }
}
