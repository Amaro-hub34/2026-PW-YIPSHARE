package com.philopsychia.backend.service.auth;

import com.github.f4b6a3.uuid.alt.GUID;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jose.proc.BadJOSEException;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.philopsychia.backend.util.data.AppKeyPair;
import com.philopsychia.shared.dto.auth.JwtDTO;
import org.jspecify.annotations.NonNull;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

@Service
public class JWTService {

    private final AppKeyPair jwkSet;
    private final ConfigurableJWTProcessor<SecurityContext> jwkProcessor;

    public JWTService(AppKeyPair jwkSet, ConfigurableJWTProcessor<SecurityContext> jwkProcessor) {
        this.jwkSet = jwkSet;
        this.jwkProcessor = jwkProcessor;
    }

    public JwtDTO createToken(GUID identifier) {
        try {
            RSAKey keypair = jwkSet.keypair();
            JWSSigner signer = new RSASSASigner(keypair);

            Date now = new Date();

            JWTClaimsSet claims = new JWTClaimsSet.Builder()
                    .issuer("https://philopsychia.com")
                    .subject(identifier.toString())
                    .expirationTime(new Date(now.getTime() + 1000 * 60 * 30))
                    .issueTime(now)
                    .jwtID(UUID.randomUUID().toString())
                    .build();

            JWSHeader header = new JWSHeader.Builder(JWSAlgorithm.RS256)
                    .keyID(keypair.getKeyID()).build();

            SignedJWT jwt = new SignedJWT(
                    header,
                    claims
            );

            jwt.sign(signer);

            return new JwtDTO(jwt.serialize());
        } catch (JOSEException e) {
            throw new JWTCreationException("Failed to createTicket token:", e);
        }
    }

    public Optional<JWTClaimsSet> validateToken(JwtDTO jwt) {
        String accessToken = jwt.token();
        return validateToken(accessToken);
    }

    public @NonNull Optional<JWTClaimsSet> validateToken(String token) {
        JWTClaimsSet claimsSet;
        try {
            claimsSet = jwkProcessor.process(token, null);
        } catch (ParseException | BadJOSEException | JOSEException e) {
            return Optional.empty();
        }
        return Optional.of(claimsSet);
    }

    public static class JWTCreationException extends RuntimeException {
        public JWTCreationException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
