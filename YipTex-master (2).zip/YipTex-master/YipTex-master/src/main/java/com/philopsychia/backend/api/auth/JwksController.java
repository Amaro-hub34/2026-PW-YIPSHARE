package com.philopsychia.backend.api.auth;

import com.philopsychia.backend.util.data.AppKeyPair;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class JwksController {

    private final AppKeyPair jwkSet;

    public JwksController(AppKeyPair jwkSet) {
        this.jwkSet = jwkSet;
    }

    @GetMapping("/api/auth/.well-known/jwks.json")
    public String jwks() {
        return jwkSet.publicKeyAPI().toJSONObject().toString();
    }
}