package com.philopsychia.shared.dto.user.entity;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

public abstract class NonAdminUserDTO extends BaseUserDTO {
    @Getter
    @Setter
    private String name;
    @Getter
    @Setter
    private String paternal_surname;
    @Getter
    @Setter
    private String maternal_surname;
    @Getter
    @Setter
    private String institutional_email;

    public NonAdminUserDTO() {}

    public NonAdminUserDTO(GUID id, String name, String paternal_surname, String maternal_surname, String institutional_email, Role role) {
        super(id, role);
        this.name = name;
        this.paternal_surname = paternal_surname;
        this.maternal_surname = maternal_surname;
        this.institutional_email = institutional_email;
    }
}
