package com.philopsychia.frontend.util;

import javafx.scene.image.Image;
import javafx.stage.Stage;

public class IconLoader {

    public static void loadAppIcons(Stage stage) {

        int[] sizes = {16, 20, 24, 30, 32, 36, 40, 48, 60, 64, 72, 80, 96, 256, 1024, 1088};

        for (int size : sizes) {
            String path = String.format("icons/icon%d.png", size);
            var resource = IconLoader.class.getClassLoader().getResourceAsStream(path);

            if (resource != null) {
                stage.getIcons().add(new Image(resource));
            } else {
                System.err.println("Missing icon: " + path);
            }
        }
    }
}
