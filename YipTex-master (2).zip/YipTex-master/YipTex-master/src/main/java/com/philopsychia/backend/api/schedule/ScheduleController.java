package com.philopsychia.backend.api.schedule;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.service.schedule.ScheduleService;
import com.philopsychia.shared.dto.schedule.ScheduleEntityDTO;
import com.philopsychia.shared.dto.schedule.SchedulePayloadDTO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAnyAuthority('ADMIN')")
@RequestMapping("/api/schedule")
public class ScheduleController {

    private final ScheduleService scheduleService;

    public ScheduleController(ScheduleService scheduleService) {
        this.scheduleService = scheduleService;
    }

    @GetMapping
    public List<ScheduleEntityDTO> getAllScheduleEntries(@AuthenticationPrincipal UserDetails userDetails) {
        return scheduleService.getAllScheduleEntries();
    }

    @PostMapping
    public void createScheduleEntry(@AuthenticationPrincipal UserDetails userDetails, @RequestBody SchedulePayloadDTO dto) {
        scheduleService.createScheduleEntry(dto);
    }

    @GetMapping("/{uuid}")
    public ScheduleEntityDTO getScheduleEntry(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        return scheduleService.getSchedule(uuid);
    }

    @PutMapping("/{uuid}")
    public void modifyScheduleEntry(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid, @RequestBody SchedulePayloadDTO dto) {
        scheduleService.modifySchedule(uuid, dto);
    }

    @DeleteMapping("/{uuid}")
    public void deleteScheduleEntry(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        scheduleService.deleteSchedule(uuid);
    }
}

