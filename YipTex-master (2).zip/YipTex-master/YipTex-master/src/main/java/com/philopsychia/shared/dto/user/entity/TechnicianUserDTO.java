package com.philopsychia.shared.dto.user.entity;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

public class TechnicianUserDTO extends NonAdminUserDTO {
    @Getter
    @Setter
    private String rfc;

    public TechnicianUserDTO() {}

    public TechnicianUserDTO(GUID id, String rfc, String name, String paternal_surname, String maternal_surname, String institutional_email, Role role) {
        super(id, name, paternal_surname, maternal_surname, institutional_email, role);
        this.rfc = rfc;
    }
}
