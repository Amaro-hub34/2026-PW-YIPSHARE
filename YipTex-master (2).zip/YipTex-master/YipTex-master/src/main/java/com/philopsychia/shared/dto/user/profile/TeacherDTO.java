package com.philopsychia.shared.dto.user.profile;

public record TeacherDTO(String rfc) {
}
