package com.philopsychia.shared.dto.ticket;

import com.philopsychia.shared.dto.schedule.Weekday;
import lombok.Getter;

public enum Status {
    OPEN(1),
    IN_PROGRESS(2),
    RESOLVED(3),
    CLOSED(4);

    @Getter
    private final int value;

    Status(int i) {
        value = i;
    }

    public static Status parse(String value) {
        value = value.toUpperCase().trim();
        return Status.valueOf(value);
    }
}
