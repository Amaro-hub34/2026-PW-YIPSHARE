package com.philopsychia.shared.dto.auth.register_request;

import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

public class TechnicianRegisterRequestDTO extends NonAdminRegisterRequest {
    @Getter
    @Setter
    private String rfc;

    public TechnicianRegisterRequestDTO() {
        super();
    }

    public TechnicianRegisterRequestDTO(String password, String name, String paternalSurname, String maternalSurname, String institutionalEmail, String rfc) {
        super(password, Role.TECHNICIAN, name, paternalSurname, maternalSurname, institutionalEmail);
        this.rfc = rfc;
    }

    @Override
    public boolean validate() {
        return super.validate()
                &&  Regexes.rfcRegex.matcher(rfc).matches();
    }
}
