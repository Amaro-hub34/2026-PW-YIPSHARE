package com.philopsychia.frontend.components;

import javafx.concurrent.Task;
import javafx.geometry.Pos;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

public class LoadingOverlay extends StackPane {

    public LoadingOverlay() {
        ProgressIndicator spinner = new ProgressIndicator();
        spinner.setStyle("-fx-progress-color: #991859FF; -fx-text-fill: #991859FF;");
        spinner.setMaxSize(60, 60);

        this.setBackground(new Background(new BackgroundFill(
                Color.rgb(0, 0, 0, 0.4), null, null
        )));

        this.setAlignment(Pos.CENTER);
        this.getChildren().add(spinner);

        this.setVisible(false);
        this.managedProperty().bind(this.visibleProperty());
    }

    public void bindToTask(Task<?> task) {
        if (task == null) return;

        this.visibleProperty().bind(task.runningProperty());
    }
}

