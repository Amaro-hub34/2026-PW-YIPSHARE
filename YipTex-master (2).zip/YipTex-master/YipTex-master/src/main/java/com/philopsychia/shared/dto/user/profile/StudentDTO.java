package com.philopsychia.shared.dto.user.profile;

public record StudentDTO(long studentId) {
}
