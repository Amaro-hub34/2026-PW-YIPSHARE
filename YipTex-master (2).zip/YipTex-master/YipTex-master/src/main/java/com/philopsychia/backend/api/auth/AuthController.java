package com.philopsychia.backend.api.auth;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.service.auth.AuthService;
import com.philopsychia.backend.util.exception.UnauthorizedAPICallException;
import com.philopsychia.shared.dto.auth.JwtDTO;
import com.philopsychia.shared.dto.auth.LoginRequestDTO;
import com.philopsychia.shared.dto.auth.register_request.BaseRegisterRequestDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }
    
    @PostMapping("/login")
    JwtDTO login(@RequestBody LoginRequestDTO request) {
        Optional<JwtDTO> jwt = authService.tryLogin(request.identifier(), request.password());
        if (jwt.isPresent()) return jwt.get();
        else throw new UnauthorizedAPICallException("Invalid username or password");
    }

    @PostMapping("/register")
    JwtDTO register(@RequestBody BaseRegisterRequestDTO request) {
        if (!request.validate()) throw new UnauthorizedAPICallException("Invalid data was passed in the registry request");
        return authService.tryRegister(request, null);
    }

    @GetMapping("/me")
    BaseUserDTO me(@AuthenticationPrincipal UserDetails userDetails) {
        return authService.getUserInformation(new GUID(userDetails.getUsername()));
    }
}
