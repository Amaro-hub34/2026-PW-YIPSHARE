package com.philopsychia.frontend.control.teacher;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.auth.register_request.TeacherRegisterRequestDTO;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.ticket.Status;
import com.philopsychia.shared.dto.ticket.TicketEntityDTO;
import com.philopsychia.shared.dto.ticket.TicketPayloadDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.StudentUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import com.philopsychia.shared.dto.user.payload.TeacherPayloadDTO;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.philopsychia.shared.dto.ticket.Status.*;

public class ReportsScreenController implements IController  {

    public Button newButton;
    public GridPane ticketTable;

    @FXML
    private void initialize(){}

    @Override
    public void init() {

        List<Node> nodesToRemove = new ArrayList<>();
        for (Node node : ticketTable.getChildren()) {
            Integer rowIndex = GridPane.getRowIndex(node);
            if (rowIndex != null && rowIndex > 0) {
                nodesToRemove.add(node);
            }
        }

        ticketTable.getRowConstraints().removeIf(x -> {
            return ticketTable.getRowConstraints().indexOf(x) != 0;
        });

        ticketTable.getChildren().removeAll(nodesToRemove);

        RestClient.authorizedGetRequest(t -> {
                    Frontend.loadingOverlay.bindToTask(t);
                    t.setOnSucceeded(e -> {
                        ApiResponse<BaseUserDTO> apiResponse = t.getValue();

                        if (!apiResponse.isError()) {
                            RestClient.authorizedGetRequest(
                                    task -> {
                                        Frontend.loadingOverlay.bindToTask(task);
                                        task.setOnSucceeded(event -> {
                                            ApiResponse<List<TicketEntityDTO>> tickets = task.getValue();

                                            if (tickets.isError()) {
                                                ViewLoader.generatePopup("Hubo un error insperado");
                                            } else {
                                                int i = 0;

                                                for (TicketEntityDTO ticket : tickets.data()) {
                                                    i++;

                                                    int finalI = i;
                                                    RestClient.authorizedGetRequest(t2 -> {
                                                                Frontend.loadingOverlay.bindToTask(t2);
                                                                t2.setOnSucceeded(e2 -> {
                                                                    ApiResponse<DeviceEntityDTO> deviceEntityDTO = t2.getValue();

                                                                    if (deviceEntityDTO.isError()) {
                                                                        Frontend.pushPopup("Hubo un error insperado");
                                                                    } else {
                                                                        DeviceEntityDTO device = deviceEntityDTO.data();
                                                                        RestClient.authorizedGetRequest(t3 -> {
                                                                                    Frontend.loadingOverlay.bindToTask(t3);
                                                                                    t3.setOnSucceeded(e1 -> {
                                                                                        ApiResponse<RoomEntityDTO> roomEntityDTOApiResponse = t3.getValue();

                                                                                        if (roomEntityDTOApiResponse.isError()) {
                                                                                            Frontend.pushPopup("Hubo un error inesperado");
                                                                                        } else {
                                                                                            List<Node> nodesForRow = List.of(
                                                                                                    new Label(roomEntityDTOApiResponse.data().getName()),
                                                                                                    new Label(String.valueOf(device.getNumber_id())),
                                                                                                    new Label(switch (ticket.getStatus()) {
                                                                                                        case OPEN -> "Abierto";
                                                                                                        case IN_PROGRESS ->
                                                                                                                "En progreso";
                                                                                                        case RESOLVED -> "Resuelto";
                                                                                                        case CLOSED -> "Cerrado";
                                                                                                    }),
                                                                                                    new Button("", new FontIcon(Feather.MESSAGE_SQUARE) {{this.setIconColor(Color.WHITE);}}) {
                                                                                                        {
                                                                                                            this.setStyle("-fx-background-color: #991859; -fx-background-radius: 100");
                                                                                                            this.setOnMouseClicked(event -> {
                                                                                                                Frontend.pushTicketPopup(ticket.getDescription(),
                                                                                                                        ticket.getCreated_at());
                                                                                                            });
                                                                                                        }
                                                                                                    }
                                                                                            );

                                                                                            int j = 0;
                                                                                            for (Node node : nodesForRow) {
                                                                                                ticketTable.add(node,j, finalI);
                                                                                                GridPane.setHalignment(node, HPos.CENTER);
                                                                                                j++;
                                                                                            }

                                                                                            ticketTable.getRowConstraints().add(
                                                                                                    new RowConstraints(50)
                                                                                            );
                                                                                        }
                                                                                    });
                                                                                }, "/api/rooms/{room_id}",
                                                                                new ParameterizedTypeReference<RoomEntityDTO>() {},
                                                                                device.getRoom_id());
                                                                    }
                                                                });
                                                            }, "/api/devices/{device_id}",
                                                            new ParameterizedTypeReference<DeviceEntityDTO>() {},
                                                            ticket.getDevice_id());
                                                }
                                            }
                                        });
                                    }, "/api/tickets/user/{user_id}",
                                    new ParameterizedTypeReference<List<TicketEntityDTO>>() {},
                                    apiResponse.data().getId()
                            );
                        }
                    });
                }, "/api/auth/me",
                new ParameterizedTypeReference<BaseUserDTO>() {});

    }

    public void addTicket(MouseEvent mouseEvent) {
        RestClient.authorizedGetRequest(t -> {
                    Frontend.loadingOverlay.bindToTask(t);
                    t.setOnSucceeded(e -> {
                        ApiResponse<BaseUserDTO> apiResponse = t.getValue();

                        if (!apiResponse.isError()) {
                            Frontend.pushWithIO("teacher/data_input/report_data", (TicketPayloadDTO ticketPayloadDTO) -> {

                                RestClient.authorizedPostRequest(
                                        task -> {
                                            Frontend.loadingOverlay.bindToTask(task);
                                            task.setOnSucceeded(event -> {
                                                ApiResponse<Void> apiResponse2 = task.getValue();

                                                if (apiResponse2.isError()) {
                                                    if (apiResponse2.code() == HttpStatus.BAD_REQUEST) {
                                                        Frontend.pop(); Frontend.pop();
                                                        Frontend.pushPopup("Los datos usados ya han sido registrados");
                                                    } else {
                                                        Frontend.pushPopup("Hubo un error inesperado");
                                                    }
                                                } else {
                                                    Frontend.pop();
                                                    init();
                                                }
                                            });
                                        }, "/api/tickets",
                                        ticketPayloadDTO,
                                        new ParameterizedTypeReference<Void>() {}
                                );
                            }, apiResponse.data().getId());
                        }
                    });
                }, "/api/auth/me",
                new ParameterizedTypeReference<BaseUserDTO>() {});
    }
}