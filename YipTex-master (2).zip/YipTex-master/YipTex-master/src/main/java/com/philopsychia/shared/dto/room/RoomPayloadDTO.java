package com.philopsychia.shared.dto.room;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
public class RoomPayloadDTO {

    @Getter
    @Setter
    private String name;

    @Getter
    @Setter
    private String location;

    @Getter
    @Setter
    private String acronym;

    @Getter
    @Setter
    private int device_amount;

    public boolean validate() {
        return device_amount > 0;
    }

}
