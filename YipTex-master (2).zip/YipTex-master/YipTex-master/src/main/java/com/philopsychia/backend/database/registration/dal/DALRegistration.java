package com.philopsychia.backend.database.registration.dal;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.Getter;
import lombok.Setter;

public class DALRegistration {

    @Getter
    @Setter
    private GUID id;

    @Getter
    @Setter
    private GUID user_id;

    @Getter
    @Setter
    private GUID device_id;

    @Getter
    @Setter
    private GUID class_id;

    @Getter
    @Setter
    private String assignment_reason;


    public DALRegistration(GUID user_id, GUID device_id, GUID class_id, String assignment_reason) {
        this.id = GUID.v7();
        this.user_id = user_id;
        this.device_id = device_id;
        this.class_id = class_id;
        this.assignment_reason = assignment_reason;
    }
}
