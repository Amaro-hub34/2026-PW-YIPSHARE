package com.philopsychia.shared.dto.user.payload;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

public class StudentPayloadDTO extends NonAdminPayloadDTO {
    @Getter
    @Setter
    private long studentId;

    public StudentPayloadDTO() {}

    public StudentPayloadDTO(long studentId, String name, String paternal_surname, String maternal_surname, String institutional_email, Role role) {
        super(name, paternal_surname, maternal_surname, institutional_email, role);
        this.studentId = studentId;
    }
}
