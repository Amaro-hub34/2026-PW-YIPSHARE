package com.philopsychia.frontend.control.admin;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.auth.register_request.TeacherRegisterRequestDTO;
import com.philopsychia.shared.dto.auth.register_request.TechnicianRegisterRequestDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import com.philopsychia.shared.dto.user.entity.TechnicianUserDTO;
import com.philopsychia.shared.dto.user.payload.TeacherPayloadDTO;
import com.philopsychia.shared.dto.user.payload.TechnicianPayloadDTO;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public class TechniciansScreenController implements IController  {
    public Button newButton;
    public GridPane roomTable;

    @FXML
    private void initialize(){}

    @Override
    public void init() {

        List<Node> nodesToRemove = new ArrayList<>();
        for (Node node : roomTable.getChildren()) {
            Integer rowIndex = GridPane.getRowIndex(node);
            if (rowIndex != null && rowIndex > 0) {
                nodesToRemove.add(node);
            }
        }

        roomTable.getRowConstraints().removeIf(x -> {
            return roomTable.getRowConstraints().indexOf(x) != 0;
        });

        roomTable.getChildren().removeAll(nodesToRemove);

        RestClient.authorizedGetRequest(
                task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<List<BaseUserDTO>> apiResponse = task.getValue();

                        if (apiResponse.isError()) {
                            ViewLoader.generatePopup("Hubo un error insperado");
                        } else {
                            int i = 0;
                            List<TechnicianUserDTO> users = apiResponse.data().stream()
                                    .filter(x -> x instanceof TechnicianUserDTO)
                                    .map(x -> (TechnicianUserDTO) x).toList();

                            for (TechnicianUserDTO technician : users) {
                                i++;

                                List<Node> nodesForRow = List.of(
                                        new Label(technician.getPaternal_surname()),
                                        new Label(technician.getMaternal_surname()),
                                        new Label(technician.getName()),
                                        new Label(technician.getInstitutional_email()),
                                        new Label(technician.getRfc()),
                                        new Button("", new FontIcon(Feather.PEN_TOOL) {{this.setIconColor(Color.WHITE);}}) {
                                            {
                                                this.setStyle("-fx-background-color: #991859; -fx-background-radius: 100");
                                                this.setOnMouseClicked(event -> modifyTechinician(event, technician, technician.getId()));
                                            }
                                        },
                                        new Button("", new FontIcon(Feather.TRASH) {{this.setIconColor(Color.WHITE);}}) {
                                            {
                                                this.setStyle("-fx-background-color: #262626; -fx-background-radius: 100");
                                                this.setOnMouseClicked(event -> deleteTechnician(event, technician.getId()));
                                            }
                                        }
                                );

                                int j = 0;
                                for (Node node : nodesForRow) {
                                    roomTable.add(node,j, i);
                                    GridPane.setHalignment(node, HPos.CENTER);
                                    j++;
                                }

                                roomTable.getRowConstraints().add(
                                        new RowConstraints(50)
                                );
                            }
                        }
                    });
                }, "/api/users",
                new ParameterizedTypeReference<List<BaseUserDTO>>() {}
        );

    }

    public void addTechnician(MouseEvent mouseEvent) {
        Frontend.pushWithIO("admin/data_input/technician_data", (TechnicianPayloadDTO technicianPayloadDTO) -> {

            Frontend.pushWithIO("data_input/password_input", (String password) -> {
                RestClient.authorizedPostRequest(
                        task -> {
                            Frontend.loadingOverlay.bindToTask(task);
                            task.setOnSucceeded(event -> {
                                ApiResponse<Void> apiResponse = task.getValue();

                                if (apiResponse.isError()) {
                                    if (apiResponse.code() == HttpStatus.BAD_REQUEST) {
                                        Frontend.pop(); Frontend.pop();
                                        Frontend.pushPopup("Los datos usados ya han sido registrados");
                                    } else {
                                        Frontend.pushPopup("Hubo un error inesperado");
                                    }
                                } else {
                                    Frontend.pop(); Frontend.pop();
                                    init();
                                }
                            });
                        }, "/api/users",
                        new TechnicianRegisterRequestDTO(
                                password,
                                technicianPayloadDTO.getName(),
                                technicianPayloadDTO.getPaternal_surname(),
                                technicianPayloadDTO.getMaternal_surname(),
                                technicianPayloadDTO.getInstitutional_email(),
                                technicianPayloadDTO.getRfc()
                        ),
                        new ParameterizedTypeReference<Void>() {}
                );
            }, null);
        }, null);
    }

    private void modifyTechinician(MouseEvent mouseEvent, TechnicianUserDTO input, GUID id) {
        Frontend.pushWithIO("admin/data_input/technician_data", (TechnicianPayloadDTO technicianPayloadDTO) -> {
            RestClient.authorizedPutRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                if (apiResponse.code() == HttpStatus.BAD_REQUEST) {
                                    Frontend.pop();
                                    Frontend.pushPopup("Los datos usados ya han sido registrados");
                                } else {
                                    Frontend.pushPopup("Hubo un error inesperado");
                                }
                            } else {
                                Frontend.pop();
                                init();
                            }
                        });
                    }, "/api/users/{id}",
                    technicianPayloadDTO,
                    new ParameterizedTypeReference<Void>() {},
                    id
            );
        }, input);
    }

    private void deleteTechnician(MouseEvent mouseEvent, GUID id) {
        Frontend.pushConfirmation("Esta seguro de que desea borrar este profesor", () -> {
            RestClient.authorizedDeleteRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                ViewLoader.generatePopup("Hubo un error insperado");
                            } else {
                                init();
                            }
                        });
                    }, "/api/users/{id}",
                    new ParameterizedTypeReference<Void>() {},
                    id
            );
        });
    }
}