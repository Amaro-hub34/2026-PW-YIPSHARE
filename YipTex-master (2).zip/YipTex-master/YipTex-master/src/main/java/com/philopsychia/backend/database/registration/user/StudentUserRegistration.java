package com.philopsychia.backend.database.registration.user;

import com.philopsychia.shared.dto.user.Role;

public class StudentUserRegistration extends NonAdminUserRegistration {
    private final long studentId;

    public StudentUserRegistration(String password_hash,
                                   Role role,
                                   String name,
                                   String paternalSurname,
                                   String maternalSurname,
                                   String institutionalEmail,
                                   long studentId) {
        super(password_hash, role, name, paternalSurname, maternalSurname, institutionalEmail);
        this.studentId = studentId;
    }

    public long studentId() {
        return studentId;
    }
}
