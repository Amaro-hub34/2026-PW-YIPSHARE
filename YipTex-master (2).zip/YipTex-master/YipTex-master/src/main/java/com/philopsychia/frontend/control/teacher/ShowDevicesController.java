package com.philopsychia.frontend.control.teacher;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.control.util.IWithCallback;
import com.philopsychia.frontend.control.util.IWithLoadFunction;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ScreenUtil;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.dal.DALEntityDTO;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.group.Schedule;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import org.controlsfx.control.textfield.CustomTextField;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;

import java.util.List;

public class ShowDevicesController implements IWithLoadFunction<GUID>, IController {

    public VBox devices;
    private GUID userId;

    @FXML
    private void initialize() {
    }

    public void returnToPrevious(MouseEvent mouseEvent) {
        Frontend.pop();
    }

    private void cleanGUI() {
        devices.getChildren().clear();
    }

    @Override
    public void init() {
        cleanGUI();

        if (userId != null) {
            RestClient.authorizedGetRequest(t -> {
                Frontend.loadingOverlay.bindToTask(t);
                t.setOnSucceeded(e -> {
                    ApiResponse<List<DALEntityDTO>> apiResponse = t.getValue();

                    if (apiResponse.isError()) {
                        Frontend.pop();
                        Frontend.pushPopup("Hubo un error inesperado");
                    } else {
                        for (DALEntityDTO dalDTO : apiResponse.data()) {
                            GridPane gridPane = new GridPane();
                            gridPane.setPadding(new Insets(10));
                            gridPane.setAlignment(Pos.CENTER);
                            gridPane.setMaxSize(Double.MAX_VALUE, 50);
                            gridPane.setPrefSize(Double.MAX_VALUE, 50);

                            ColumnConstraints col = new ColumnConstraints();
                            col.setPercentWidth(100.0 / 3.0);
                            gridPane.getColumnConstraints().addAll(col, col, col);

                            RestClient.authorizedGetRequest(t2 -> {
                                        Frontend.loadingOverlay.bindToTask(t2);
                                        t2.setOnSucceeded(_ -> {
                                            ApiResponse<DeviceEntityDTO> apiResponse2 = t2.getValue();
                                            if (apiResponse2.isError()) {
                                                Frontend.pop();
                                                Frontend.pushPopup("Hubo un error inesperado");
                                            } else {
                                                RestClient.authorizedGetRequest(t3 -> {
                                                    Frontend.loadingOverlay.bindToTask(t3);
                                                    t3.setOnSucceeded(_ -> {
                                                        ApiResponse<RoomEntityDTO>  apiResponse3 = t3.getValue();
                                                        if (apiResponse3.isError()) {
                                                            Frontend.pop();
                                                            Frontend.pushPopup("Hubo un error inesperado");
                                                        } else {
                                                            Label item1 = new Label("Laboratorio: " + apiResponse3.data().getName());
                                                            Label item2 = new Label("Numero de computadora: " + apiResponse2.data().getNumber_id());
                                                            Button item3 = new Button("", new FontIcon(Feather.TRASH) {{this.setIconColor(Color.WHITE);}}) {
                                                                {
                                                                    this.setStyle("-fx-background-color: #212121; -fx-background-radius: 100");
                                                                    this.setOnMouseClicked(event -> {
                                                                        Frontend.pushConfirmation("Esta seguro que desea borrar este registro de computadora", () -> {
                                                                            RestClient.authorizedDeleteRequest(t4 -> {
                                                                                        Frontend.loadingOverlay.bindToTask(t4);
                                                                                        t4.setOnSucceeded(_ -> {
                                                                                            ApiResponse<Void> response = t4.getValue();
                                                                                            if (response.isError()) {
                                                                                                Frontend.pop();
                                                                                                Frontend.pushPopup("Hubo un error inesperado");
                                                                                            } else {
                                                                                                init();
                                                                                            }
                                                                                        });
                                                                                    }, "/api/dal/{uuid}",
                                                                                    new ParameterizedTypeReference<Void>() {},
                                                                                    dalDTO.getId()
                                                                            );
                                                                        });
                                                                    });
                                                                }
                                                            };
                                                            gridPane.addRow(0, item1, item2, item3);
                                                            GridPane.setHalignment(item1, HPos.CENTER);
                                                            GridPane.setHalignment(item2, HPos.CENTER);
                                                            GridPane.setHalignment(item3, HPos.CENTER);

                                                            devices.getChildren().add(gridPane);
                                                        }
                                                    });
                                                }, "api/rooms/{room_id}",
                                                            new ParameterizedTypeReference<RoomEntityDTO>() {},
                                                            apiResponse2.data().getRoom_id());
                                            }
                                        });
                                    }, "/api/devices/{device_id}",
                                    new ParameterizedTypeReference<DeviceEntityDTO>() {},
                                    dalDTO.getDevice_id()
                                    );

                        }
                    }
                });
                }, "/api/dal/{user_id}",
                    new ParameterizedTypeReference<List<DALEntityDTO>>() {},
                    userId);
        }
    }

    @Override
    public void load(GUID input) {
        if (input == null) return;
        userId = input;
        init();
    }
}
