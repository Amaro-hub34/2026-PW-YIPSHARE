package com.philopsychia.backend.api.device;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.service.device.DeviceService;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.device.DevicePayloadDTO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@PreAuthorize("hasAuthority('ADMIN')")
@RequestMapping("/api/rooms/{room_id}/devices")
public class RoomDeviceController {

    private final DeviceService deviceService;

    public RoomDeviceController(DeviceService deviceService) {
        this.deviceService = deviceService;
    }

    @GetMapping
    public List<DeviceEntityDTO> getAllDevices(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID room_id) {
        return deviceService.getAllDevices(room_id);
    }

    @GetMapping("/{uuid}")
    public DeviceEntityDTO getDevice(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        return deviceService.getDevice(uuid);
    }

    @PutMapping("/{uuid}")
    public void modifyDevice(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid, @RequestBody DevicePayloadDTO dto) {
        deviceService.modifyDevice(uuid, dto);
    }

    @DeleteMapping("/{uuid}")
    public void deleteDevice(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid, @PathVariable String room_id) {
        deviceService.deleteDevice(uuid);
    }

}
