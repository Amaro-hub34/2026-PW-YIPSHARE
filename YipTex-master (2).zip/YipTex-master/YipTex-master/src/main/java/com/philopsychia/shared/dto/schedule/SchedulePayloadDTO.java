package com.philopsychia.shared.dto.schedule;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalTime;

@NoArgsConstructor
@AllArgsConstructor
public class SchedulePayloadDTO {

    @Getter
    @Setter
    private GUID class_id;

    @Getter
    @Setter
    private GUID room_id;

    @Getter
    @Setter
    private Weekday weekday;

    @Getter
    @Setter
    private LocalTime start_time;

    @Getter
    @Setter
    private LocalTime end_time;

}
