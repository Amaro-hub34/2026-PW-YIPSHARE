package com.philopsychia.backend.util.data;

import com.github.javakeyring.Keyring;
import com.github.javakeyring.PasswordAccessException;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import org.jspecify.annotations.NonNull;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public record AppKeyPair(JWKSet publicKeyAPI, RSAKey keypair) {

    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int IV_LENGTH_BYTES = 12;
    private static final int TAG_LENGTH_BITS = 128;

    public static AppKeyPair load(byte[] masterKeyPayload) throws GeneralSecurityException, IOException {

        SecretKey secretKey = new SecretKeySpec(Base64.getDecoder().decode(masterKeyPayload), ALGORITHM);

        String userHome = System.getProperty("user.home");

        File projectFolder = new File(userHome, ".philopsychia/yiptex");

        if (!projectFolder.exists()) projectFolder.mkdirs();

        File dataFile = new File(projectFolder, "data.bin");

        try (FileInputStream fis = new FileInputStream(dataFile)) {
            byte[] encryptedBlob = fis.readAllBytes();
            ByteBuffer decryptedBuffer = ByteBuffer.wrap(decryptBlob(secretKey, encryptedBlob));

            byte[] privateKey = new byte[decryptedBuffer.getInt()];
            decryptedBuffer.get(privateKey);

            byte[] publicKey = new byte[decryptedBuffer.getInt()];
            decryptedBuffer.get(publicKey);

            PKCS8EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateKey);

            X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKey);

            KeyFactory keyFactory = KeyFactory.getInstance("RSA");

            return generateAppKeyPair(new KeyPair(keyFactory.generatePublic(publicKeySpec), keyFactory.generatePrivate(privateKeySpec)));
        }
    }

    public static AppKeyPair create(Keyring keyring) throws GeneralSecurityException, PasswordAccessException, IOException {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");

        keyGenerator.init(256, SecureRandom.getInstanceStrong());

        SecretKey masterKey = keyGenerator.generateKey();

        byte[] masterKeyBytes = Base64.getEncoder().encode(masterKey.getEncoded());

        keyring.setPassword("philopsychia.com", "master-file-encryption-key",
                new String(masterKeyBytes, StandardCharsets.UTF_8));

        KeyPairGenerator gen = KeyPairGenerator.getInstance("RSA");
        gen.initialize(2048);

        KeyPair pair = gen.generateKeyPair();

        byte[] privateKeyBytes = pair.getPrivate().getEncoded();
        byte[] publicKeyBytes = pair.getPublic().getEncoded();

        ByteBuffer buffer = ByteBuffer.allocate(Integer.BYTES*2 + publicKeyBytes.length + privateKeyBytes.length);

        buffer.putInt(privateKeyBytes.length);
        buffer.put(privateKeyBytes);
        buffer.putInt(publicKeyBytes.length);
        buffer.put(publicKeyBytes);

        byte[] encryptedBlob = generateEncryptedBlob(masterKey, buffer.array());

        String userHome = System.getProperty("user.home");

        File projectFolder = new File(userHome, ".philopsychia/yiptex");

        if (!projectFolder.exists()) projectFolder.mkdirs();

        File dataFile = new File(projectFolder, "data.bin");

        try (FileOutputStream fos = new FileOutputStream(dataFile)) {
            fos.write(encryptedBlob);
        }

        return generateAppKeyPair(pair);
    }

    private static @NonNull AppKeyPair generateAppKeyPair(KeyPair pair) {
        RSAKey jwk = new RSAKey.Builder((RSAPublicKey) pair.getPublic())
                .privateKey(pair.getPrivate())
                .keyID("philopsychia-auth-key")
                .build();

        JWKSet set = new JWKSet(jwk.toPublicJWK());
        return new AppKeyPair(set, jwk);
    }

    public static byte[] generateEncryptedBlob(SecretKey key, byte[] input)
            throws GeneralSecurityException {

        byte[] iv = new byte[IV_LENGTH_BYTES];
        SecureRandom random = new SecureRandom();
        random.nextBytes(iv);

        GCMParameterSpec gcmSpec = new GCMParameterSpec(TAG_LENGTH_BITS, iv);
        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.ENCRYPT_MODE, key, gcmSpec);

        byte[] ciphertext = cipher.doFinal(input);

        byte[] encryptedBlob = new byte[iv.length + ciphertext.length];
        ByteBuffer byteBuffer = ByteBuffer.wrap(encryptedBlob);
        byteBuffer.put(iv);
        byteBuffer.put(ciphertext);

        return byteBuffer.array();
    }

    public static byte[] decryptBlob(SecretKey key,  byte[] encryptedBlob)
            throws GeneralSecurityException {

        if (encryptedBlob.length < IV_LENGTH_BYTES) {
            throw new IllegalArgumentException("Encrypted blob is too short to be valid.");
        }

        ByteBuffer buffer = ByteBuffer.wrap(encryptedBlob);

        byte[] iv = new byte[IV_LENGTH_BYTES];
        buffer.get(iv);

        byte[] ciphertext = new byte[buffer.remaining()];
        buffer.get(ciphertext);

        GCMParameterSpec gcmSpec = new GCMParameterSpec(TAG_LENGTH_BITS, iv);

        Cipher cipher = Cipher.getInstance(TRANSFORMATION);
        cipher.init(Cipher.DECRYPT_MODE, key, gcmSpec);

        return cipher.doFinal(ciphertext);
    }
}
