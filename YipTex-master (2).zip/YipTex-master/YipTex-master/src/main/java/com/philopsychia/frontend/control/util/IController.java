package com.philopsychia.frontend.control.util;

public interface IController {
    void init();
}
