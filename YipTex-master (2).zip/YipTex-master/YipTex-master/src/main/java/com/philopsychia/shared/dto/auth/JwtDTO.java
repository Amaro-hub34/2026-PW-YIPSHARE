package com.philopsychia.shared.dto.auth;

public record JwtDTO(String token) {
}
