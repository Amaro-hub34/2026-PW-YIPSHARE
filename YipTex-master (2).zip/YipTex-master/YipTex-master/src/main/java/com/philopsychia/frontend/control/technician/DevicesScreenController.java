package com.philopsychia.frontend.control.technician;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.dal.DALEntityDTO;
import com.philopsychia.shared.dto.dal.DALPayloadDTO;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.ticket.Status;
import com.philopsychia.shared.dto.ticket.TicketEntityDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DevicesScreenController implements IController  {

    public GridPane deviceTable;

    @FXML
    private void initialize(){}

    @Override
    public void init() {

        List<Node> nodesToRemove = new ArrayList<>();
        for (Node node : deviceTable.getChildren()) {
            Integer rowIndex = GridPane.getRowIndex(node);
            if (rowIndex != null && rowIndex > 0) {
                nodesToRemove.add(node);
            }
        }

        deviceTable.getRowConstraints().removeIf(x -> {
            return deviceTable.getRowConstraints().indexOf(x) != 0;
        });

        deviceTable.getChildren().removeAll(nodesToRemove);

        RestClient.authorizedGetRequest(t -> {
                    Frontend.loadingOverlay.bindToTask(t);
                    t.setOnSucceeded(e -> {
                        ApiResponse<List<DeviceEntityDTO>> devicesResponse = t.getValue();

                        if (devicesResponse.isError()) {
                            Frontend.pushPopup("Hubo un error insperado");
                        } else {
                            int i = 0;
                            for (DeviceEntityDTO device : devicesResponse.data()) {
                                i++;
                                int finalI = i;
                                RestClient.authorizedGetRequest(t2 -> {
                                            Frontend.loadingOverlay.bindToTask(t2);
                                            t2.setOnSucceeded(e1 -> {
                                                ApiResponse<RoomEntityDTO> roomEntityDTOApiResponse = t2.getValue();

                                                if (roomEntityDTOApiResponse.isError()) {
                                                    Frontend.pushPopup("Hubo un error inesperado");
                                                } else {

                                                    RestClient.authorizedGetRequest(t3 -> {
                                                                Frontend.loadingOverlay.bindToTask(t3);
                                                                t3.setOnSucceeded(e3 -> {
                                                                    ApiResponse<List<TicketEntityDTO>> ticketsResponse = t3.getValue();

                                                                    if (ticketsResponse.isError()) {
                                                                        Frontend.pushPopup("Hubo un error insperado");
                                                                    } else {
                                                                        List<TicketEntityDTO> tickets = ticketsResponse.data();

                                                                        Status ticketStatusSum = null;

                                                                        for (TicketEntityDTO ticket : tickets) {
                                                                            if (ticketStatusSum == null) {
                                                                                ticketStatusSum = ticket.getStatus();
                                                                            } else if (ticket.getStatus().getValue() < ticketStatusSum.getValue()) {
                                                                                ticketStatusSum = ticket.getStatus();
                                                                            }
                                                                        }

                                                                        List<Node> nodesForRow = List.of(
                                                                                new Label(roomEntityDTOApiResponse.data().getName()),
                                                                                new Label(String.valueOf(device.getNumber_id())),
                                                                                new Label(String.valueOf(tickets.size())),
                                                                                new Label(ticketStatusSum == null ? "No hay tickets" :
                                                                                        switch (ticketStatusSum) {
                                                                                            case OPEN -> "Abierto";
                                                                                            case IN_PROGRESS ->
                                                                                                    "En progreso";
                                                                                            case RESOLVED -> "Resuelto";
                                                                                            case CLOSED -> "Cerrado";
                                                                                        })
                                                                        );

                                                                        int j = 0;
                                                                        for (Node node : nodesForRow) {
                                                                            deviceTable.add(node,j, finalI);
                                                                            GridPane.setHalignment(node, HPos.CENTER);
                                                                            j++;
                                                                        }

                                                                        deviceTable.getRowConstraints().add(
                                                                                new RowConstraints(50)
                                                                        );
                                                                    }
                                                                });
                                                            }, "/api/tickets/device/{device_id}",
                                                            new ParameterizedTypeReference<List<TicketEntityDTO>>() {},
                                                            device.getId());
                                                }
                                            });
                                        }, "/api/rooms/{room_id}",
                                        new ParameterizedTypeReference<RoomEntityDTO>() {},
                                        device.getRoom_id());
                            }
                        }
                    });
                }, "/api/devices",
                new ParameterizedTypeReference<List<DeviceEntityDTO>>() {});
    }
}