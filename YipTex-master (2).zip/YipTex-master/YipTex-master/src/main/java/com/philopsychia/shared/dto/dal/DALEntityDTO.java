package com.philopsychia.shared.dto.dal;

import com.github.f4b6a3.uuid.alt.GUID;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
public class DALEntityDTO {

    @Getter
    @Setter
    private GUID id;

    @Getter
    @Setter
    private GUID user_id;

    @Getter
    @Setter
    private GUID device_id;

    @Getter
    @Setter
    private GUID class_id;

    @Getter
    @Setter
    private LocalDateTime created_at;

    @Getter
    @Setter
    private String assignment_reason;

}
