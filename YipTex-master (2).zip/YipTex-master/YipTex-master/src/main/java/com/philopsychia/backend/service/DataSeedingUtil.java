package com.philopsychia.backend.service;

import com.philopsychia.backend.database.registration.user.AdminUserRegistration;
import com.philopsychia.backend.database.repository.UserRepository;
import com.philopsychia.backend.service.auth.AuthService;
import com.philopsychia.shared.dto.auth.register_request.StudentRegisterRequestDTO;
import com.philopsychia.shared.dto.auth.register_request.TeacherRegisterRequestDTO;
import com.philopsychia.shared.dto.auth.register_request.TechnicianRegisterRequestDTO;
import com.philopsychia.shared.dto.user.Role;
import com.philopsychia.shared.dto.group.Schedule;
import org.jspecify.annotations.NonNull;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataSeedingUtil implements CommandLineRunner {

    private final UserRepository userRepository;
    private final AuthService authService;

    public DataSeedingUtil(UserRepository userRepository, AuthService authService) {
        this.userRepository = userRepository;
        this.authService = authService;
    }

    @Override
    public void run(String @NonNull ... args) {
        if (userRepository.findAdminByUsername("admin").isEmpty()) {
            userRepository.registerAdminUser(
                    new AdminUserRegistration(
                            "admin",
                            authService.hashPassword("admin"),
                            Role.ADMIN
                    )
            );
        }
    }
}
