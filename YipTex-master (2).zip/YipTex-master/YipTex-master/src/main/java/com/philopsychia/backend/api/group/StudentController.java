package com.philopsychia.backend.api.group;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.repository.MappingRepository;
import com.philopsychia.backend.service.auth.AuthService;
import com.philopsychia.backend.service.group.ClassService;
import com.philopsychia.backend.service.mapping.MappingEntryService;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.mapping_table.MappingEntryDTO;
import com.philopsychia.shared.dto.user.Role;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@PreAuthorize("hasAnyAuthority('ADMIN', 'TEACHER', 'STUDENT')")
@RequestMapping("/api/students")
public class StudentController {

    private final MappingEntryService mappingEntryService;
    private final AuthService authService;
    private final ClassService classService;

    public StudentController(MappingEntryService mappingEntryService, AuthService authService, ClassService classService) {
        this.mappingEntryService = mappingEntryService;
        this.authService = authService;
        this.classService = classService;
    }

    @GetMapping("/{user_id}")
    public Optional<ClassEntityDTO> getClassDTO(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("user_id") GUID user_id) {
        if (user_id != null && authService.getUserInformation(user_id).getRole() !=  Role.STUDENT) throw new ResourceNotFound("Given id did not map to a student");
        Optional<MappingEntryDTO> mappingEntryDTO = mappingEntryService.getMappingEntries(user_id, null, MappingRepository.MappingTable.STUDENT_CLASS).stream().findFirst();
        return mappingEntryDTO.map(entryDTO -> classService.getClass(entryDTO.getClass_id()));
    }

}
