package com.philopsychia.frontend.control.util;

import lombok.Setter;

import java.util.function.Consumer;

public interface IWithLoadFunction<T> {

    void load(T input);
}
