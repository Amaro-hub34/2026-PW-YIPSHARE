package com.philopsychia.backend.service.ticket;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.registration.ticket.TicketRegistration;
import com.philopsychia.backend.database.repository.DeviceRepository;
import com.philopsychia.backend.database.repository.ScheduleRepository;
import com.philopsychia.backend.database.repository.TicketRepository;
import com.philopsychia.backend.database.repository.UserRepository;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.schedule.ScheduleEntityDTO;
import com.philopsychia.shared.dto.ticket.TicketEntityDTO;
import com.philopsychia.shared.dto.ticket.TicketPayloadDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TicketService {

    private final TicketRepository ticketRepository;
    private final UserRepository userRepository;
    private final DeviceRepository deviceRepository;
    private final ScheduleRepository scheduleRepository;

    public TicketService(TicketRepository ticketRepository, UserRepository userRepository, DeviceRepository deviceRepository, ScheduleRepository scheduleRepository) {
        this.ticketRepository = ticketRepository;
        this.userRepository = userRepository;
        this.deviceRepository = deviceRepository;
        this.scheduleRepository = scheduleRepository;
    }


    public TicketEntityDTO getTicket(GUID id) {
        Optional<TicketEntityDTO> data = ticketRepository.getTicketById(id);
        if (data.isPresent()) return data.get();
        else throw new ResourceNotFound("Resource not found");
    }

    public void modifyTicket(GUID uuid, TicketPayloadDTO dto) {
        if (ticketRepository.getTicketById(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        ticketRepository.modifyTicket(uuid, dto);
    }

    public void deleteTicket(GUID uuid) {
        if (ticketRepository.getTicketById(uuid).isEmpty()) throw new ResourceNotFound("Resource not found");
        ticketRepository.deleteTicket(uuid);
    }

    public List<TicketEntityDTO> getAllTickets() {
        return ticketRepository.getAllTickets();
    }

    public List<TicketEntityDTO> getAllTicketsByDeviceId(GUID id) {
        return ticketRepository.getAllTicketsByDeviceId(id);

    }

    public List<TicketEntityDTO> getAllTicketsByUserId(GUID id) {
        return ticketRepository.getAllTicketsByUserId(id);
    }

    public void createTicket(TicketPayloadDTO dto) {
        Optional<BaseUserDTO> user = userRepository.findUserByUserId(dto.getCreated_by());
        Optional<DeviceEntityDTO> device = deviceRepository.getDeviceById(dto.getDevice_id());
        if (user.isEmpty()) throw new ResourceNotFound("Invalid primary_teacher_id reference");
        if (device.isEmpty()) throw new ResourceNotFound("Invalid primary_device_id reference");

        ticketRepository.registerTicket(new TicketRegistration(
                dto.getCreated_by(),
                dto.getDevice_id(),
                dto.getDescription(),
                dto.getStatus()
        ));
    }
}
