package com.philopsychia.backend.database.entity.user;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;

public abstract class UserEntity {
    private final GUID id;
    private final String password_hash;
    private final Role role;

    public UserEntity(GUID id,
                      String password_hash,
                      Role role) {
        this.id = id;
        this.password_hash = password_hash;
        this.role = role;
    }

    public GUID id() {
        return id;
    }

    public String password_hash() {
        return password_hash;
    }

    public Role role() {
        return role;
    }
}
