package com.philopsychia.frontend.control.student;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.auth.register_request.TeacherRegisterRequestDTO;
import com.philopsychia.shared.dto.dal.DALEntityDTO;
import com.philopsychia.shared.dto.dal.DALPayloadDTO;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.ticket.Status;
import com.philopsychia.shared.dto.ticket.TicketEntityDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.StudentUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import com.philopsychia.shared.dto.user.payload.TeacherPayloadDTO;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class DeviceScreenController implements IController  {

    public GridPane deviceTable;
    public Button newButton;

    @FXML
    private void initialize(){}

    @Override
    public void init() {
        RestClient.authorizedGetRequest(task -> {
            Frontend.loadingOverlay.bindToTask(task);
            task.setOnSucceeded(event -> {
                ApiResponse<BaseUserDTO> apiResponse = task.getValue();
                if (!apiResponse.isError()) {
                    BaseUserDTO user = apiResponse.data();
                    if (user instanceof StudentUserDTO studentUserDTO) {
                        RestClient.authorizedGetRequest(t -> {
                            Frontend.loadingOverlay.bindToTask(t);
                            t.setOnSucceeded(e -> {
                                ApiResponse<Optional<ClassEntityDTO>> apiResponse2 = t.getValue();
                                if (!apiResponse2.isError()) {
                                    if (apiResponse2.data().isEmpty()) {
                                        deviceTable.setVisible(false);
                                        deviceTable.setDisable(true);
                                        newButton.setVisible(false);
                                        newButton.setDisable(true);
                                        Frontend.pushPopup("Su cuenta no ha sido aceptada todavia");
                                    } else {
                                        deviceTable.setVisible(true);
                                        deviceTable.setDisable(false);
                                        newButton.setVisible(true);
                                        newButton.setDisable(false);
                                    }
                                }
                            });
                            }, "api/students/{user_id}",
                                new ParameterizedTypeReference<Optional<ClassEntityDTO>>() {},
                                studentUserDTO.getId());
                    }
                }
            });
            }, "/api/auth/me",
                new ParameterizedTypeReference<BaseUserDTO>() {});


        List<Node> nodesToRemove = new ArrayList<>();
        for (Node node : deviceTable.getChildren()) {
            Integer rowIndex = GridPane.getRowIndex(node);
            if (rowIndex != null && rowIndex > 0) {
                nodesToRemove.add(node);
            }
        }

        deviceTable.getRowConstraints().removeIf(x -> {
            return deviceTable.getRowConstraints().indexOf(x) != 0;
        });

        deviceTable.getChildren().removeAll(nodesToRemove);

        RestClient.authorizedGetRequest(task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<BaseUserDTO> authMeResponse = task.getValue();

                        if (authMeResponse.isError()) {
                            Frontend.pushPopup("Hubo un error inesperado");
                        } else {
                            RestClient.authorizedGetRequest(
                                    task2 -> {
                                        Frontend.loadingOverlay.bindToTask(task2);
                                        task2.setOnSucceeded(event2 -> {
                                            ApiResponse<List<DALEntityDTO>> apiResponse = task2.getValue();

                                            if (apiResponse.isError()) {
                                                ViewLoader.generatePopup("Hubo un error insperado");
                                            } else {
                                                int i = 0;
                                                List<DALEntityDTO> data = apiResponse.data();
                                                for (DALEntityDTO dal : data) {
                                                    i++;

                                                    int finalI = i;
                                                    RestClient.authorizedGetRequest(t -> {
                                                                Frontend.loadingOverlay.bindToTask(t);
                                                                t.setOnSucceeded(e -> {
                                                                    ApiResponse<DeviceEntityDTO> deviceEntityDTO = t.getValue();

                                                                    if (deviceEntityDTO.isError()) {
                                                                        Frontend.pushPopup("Hubo un error insperado");
                                                                    } else {
                                                                        DeviceEntityDTO device = deviceEntityDTO.data();
                                                                        RestClient.authorizedGetRequest(t2 -> {
                                                                            Frontend.loadingOverlay.bindToTask(t2);
                                                                            t2.setOnSucceeded(e1 -> {
                                                                                ApiResponse<RoomEntityDTO> roomEntityDTOApiResponse = t2.getValue();

                                                                                if (roomEntityDTOApiResponse.isError()) {
                                                                                    Frontend.pushPopup("Hubo un error inesperado");
                                                                                } else {

                                                                                    RestClient.authorizedGetRequest(t3 -> {
                                                                                        Frontend.loadingOverlay.bindToTask(t3);
                                                                                        t3.setOnSucceeded(e3 -> {
                                                                                            ApiResponse<List<TicketEntityDTO>> ticketsResponse = t3.getValue();

                                                                                            if (ticketsResponse.isError()) {
                                                                                                Frontend.pushPopup("Hubo un error insperado");
                                                                                            } else {
                                                                                                List<TicketEntityDTO> tickets = ticketsResponse.data();

                                                                                                Status ticketStatusSum = null;

                                                                                                for (TicketEntityDTO ticket : tickets) {
                                                                                                    if (ticketStatusSum == null) {
                                                                                                        ticketStatusSum = ticket.getStatus();
                                                                                                    } else if (ticket.getStatus().getValue() < ticketStatusSum.getValue()) {
                                                                                                        ticketStatusSum = ticket.getStatus();
                                                                                                    }
                                                                                                }

                                                                                                List<Node> nodesForRow = List.of(
                                                                                                        new Label(roomEntityDTOApiResponse.data().getName()),
                                                                                                        new Label(String.valueOf(device.getNumber_id())),
                                                                                                        new Label(ticketStatusSum == null ? "No hay tickets" :
                                                                                                        switch (ticketStatusSum) {
                                                                                                            case OPEN -> "Abierto";
                                                                                                            case IN_PROGRESS ->
                                                                                                                    "En progreso";
                                                                                                            case RESOLVED -> "Resuelto";
                                                                                                            case CLOSED -> "Cerrado";
                                                                                                        })
                                                                                                );

                                                                                                int j = 0;
                                                                                                for (Node node : nodesForRow) {
                                                                                                    deviceTable.add(node,j, finalI);
                                                                                                    GridPane.setHalignment(node, HPos.CENTER);
                                                                                                    j++;
                                                                                                }

                                                                                                deviceTable.getRowConstraints().add(
                                                                                                        new RowConstraints(50)
                                                                                                );
                                                                                            }
                                                                                        });
                                                                                    }, "/api/tickets/device/{device_id}",
                                                                                            new ParameterizedTypeReference<List<TicketEntityDTO>>() {},
                                                                                            device.getId());
                                                                                }
                                                                            });
                                                                        }, "/api/rooms/{room_id}",
                                                                                new ParameterizedTypeReference<RoomEntityDTO>() {},
                                                                                device.getRoom_id());
                                                                    }
                                                                });
                                                            }, "/api/devices/{device_id}",
                                                            new ParameterizedTypeReference<DeviceEntityDTO>() {},
                                                            dal.getDevice_id());
                                                }
                                            }
                                        });
                                    }, "/api/dal/{user_id}",
                                    new ParameterizedTypeReference<List<DALEntityDTO>>() {},
                                    authMeResponse.data().getId()
                                    );
                        }
                    });
                }, "/api/auth/me",
                new ParameterizedTypeReference<BaseUserDTO>() {});
    }

    public void addDAL(MouseEvent mouseEvent) {
        Frontend.pushWithIO("student/data_input/device_registration", (DeviceEntityDTO deviceEntityDTO) -> {

            RestClient.authorizedGetRequest(task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<BaseUserDTO> authMeResponse = task.getValue();

                            if (authMeResponse.isError()) {
                                Frontend.pushPopup("Hubo un error inesperado");
                            } else {
                                RestClient.authorizedGetRequest(t -> {
                                            Frontend.loadingOverlay.bindToTask(t);
                                            t.setOnSucceeded(e -> {
                                                ApiResponse<Optional<ClassEntityDTO>> apiResponse2 = t.getValue();
                                                if (!apiResponse2.isError() && apiResponse2.data().isPresent()) {
                                                    RestClient.authorizedPostRequest(
                                                            task2 -> {
                                                                Frontend.loadingOverlay.bindToTask(task2);
                                                                task2.setOnSucceeded(event2 -> {
                                                                    ApiResponse<Void> apiResponse = task2.getValue();

                                                                    if (apiResponse.isError()) {
                                                                        if (apiResponse.code() == HttpStatus.BAD_REQUEST) {
                                                                            Frontend.pop();
                                                                            Frontend.pushPopup("Los datos usados ya han sido registrados");
                                                                        } else {
                                                                            Frontend.pushPopup("Hubo un error inesperado");
                                                                        }
                                                                    } else {
                                                                        Frontend.pop();
                                                                        init();
                                                                    }
                                                                });
                                                            }, "/api/dal",
                                                            new DALPayloadDTO(
                                                                    authMeResponse.data().getId(),
                                                                    deviceEntityDTO.getId(),
                                                                    apiResponse2.data().get().getId(),
                                                                    ""
                                                            ),
                                                            new ParameterizedTypeReference<Void>() {}
                                                    );
                                                }
                                            });
                                        }, "api/students/{user_id}",
                                        new ParameterizedTypeReference<Optional<ClassEntityDTO>>() {},
                                        authMeResponse.data().getId());

                            }
                        });
                    }, "/api/auth/me",
                    new ParameterizedTypeReference<BaseUserDTO>() {});
        }, null);
    }
}