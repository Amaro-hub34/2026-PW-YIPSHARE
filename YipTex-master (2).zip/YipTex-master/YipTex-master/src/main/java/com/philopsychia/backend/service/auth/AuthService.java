package com.philopsychia.backend.service.auth;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.database.entity.user.UserEntity;
import com.philopsychia.backend.database.registration.user.StudentUserRegistration;
import com.philopsychia.backend.database.registration.user.TeacherUserRegistration;
import com.philopsychia.backend.database.registration.user.TechnicianUserRegistration;
import com.philopsychia.backend.database.repository.MappingRepository;
import com.philopsychia.backend.database.repository.UserRepository;
import com.philopsychia.backend.service.group.ClassService;
import com.philopsychia.backend.service.mapping.MappingEntryService;
import com.philopsychia.backend.util.exception.BadRequestException;
import com.philopsychia.backend.util.exception.UnauthorizedAPICallException;
import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.auth.*;
import com.philopsychia.shared.dto.auth.register_request.BaseRegisterRequestDTO;
import com.philopsychia.shared.dto.auth.register_request.StudentRegisterRequestDTO;
import com.philopsychia.shared.dto.auth.register_request.TeacherRegisterRequestDTO;
import com.philopsychia.shared.dto.auth.register_request.TechnicianRegisterRequestDTO;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.mapping_table.MappingEntryDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.Role;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {
    
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JWTService jwtService;
    private final MappingEntryService mappingEntryService;
    private final ClassService classService;

    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder, JWTService jwtService, MappingEntryService mappingEntryService, ClassService classService) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
        this.mappingEntryService = mappingEntryService;
        this.classService = classService;
    }

    public BaseUserDTO getUserInformation(GUID uuid) {
        Optional<BaseUserDTO> obtainedUserDTO = userRepository.findUserByUserId(uuid);
        if (obtainedUserDTO.isPresent()) return obtainedUserDTO.get();
        else throw new IllegalArgumentException("User not found");
    }

    public Optional<JwtDTO> tryLogin(String username, String password) {
        if (username != null && password != null && !password.isEmpty() && !username.isEmpty()) {
            Identifier identifier = parseIdentifier(username);

            return switch (identifier.identifierType) {
                case STUDENT_ID -> tryLoginStudentID(Long.parseLong(identifier.value), password);
                case STUDENT_INSTITUTIONAL_EMAIL, NON_STUDENT_INSTITUTIONAL_EMAIL -> tryLoginNonAdminInstitutionalEmail(username, password);
                case ADMIN_USERNAME -> tryLoginAdminByUsername(username, password);
            };
        }
        return Optional.empty();
    }

    private Optional<JwtDTO> tryLoginStudentID(long studentId, String password) {
        Optional<UserEntity> user = userRepository.findStudentByStudentID(studentId);
        if (user.isPresent()) {
            UserEntity entity = user.get();

            return passwordEncoder.matches(password, entity.password_hash())
                    ? Optional.of(jwtService.createToken(entity.id()))
                    : Optional.empty();
        }
        return Optional.empty();
    }

    private Optional<JwtDTO> tryLoginNonAdminInstitutionalEmail(String institutionalEmail, String password) {
        Optional<UserEntity> user = userRepository.findNonAdminUserByEmail(institutionalEmail);
        if (user.isPresent()) {
            UserEntity entity = user.get();

            return passwordEncoder.matches(password, entity.password_hash())
                    ? Optional.of(jwtService.createToken(entity.id()))
                    : Optional.empty();
        }
        return Optional.empty();
    }

    private Optional<JwtDTO> tryLoginAdminByUsername(String username, String password) {
        Optional<UserEntity> user = userRepository.findAdminByUsername(username);
        if (user.isPresent()) {
            UserEntity entity = user.get();

            return passwordEncoder.matches(password, entity.password_hash())
                    ? Optional.of(jwtService.createToken(entity.id()))
                    : Optional.empty();
        }
        return Optional.empty();
    }

    public JwtDTO tryRegister(BaseRegisterRequestDTO request, Role auth) {

        if (auth != Role.ADMIN) {
            if (!(request.getRole() == Role.STUDENT && (auth == null || auth == Role.STUDENT)))
                throw new UnauthorizedAPICallException("Tried to register an account but lacked permissions");
        }

        switch (request.getRole()) {
            case ADMIN -> {
            }
            case STUDENT -> {
                if (request instanceof  StudentRegisterRequestDTO studentRequest) {
                    if (userRepository.findStudentByStudentID(studentRequest.getStudentId()).isEmpty()
                    && userRepository.findNonAdminUserByEmail(studentRequest.getInstitutional_email()).isEmpty()) {
                        ClassEntityDTO classEntityDTO;
                        try {
                             classEntityDTO = classService.getClassByName(studentRequest.getGroup());
                        } catch (Exception e) {
                            throw new BadRequestException("Could not find matching class");
                        }

                        StudentUserRegistration studentUserRegistration = new StudentUserRegistration(
                                hashPassword(studentRequest.getPassword()),
                                Role.STUDENT,
                                studentRequest.getName(),
                                studentRequest.getPaternal_surname(),
                                studentRequest.getMaternal_surname(),
                                studentRequest.getInstitutional_email(),
                                studentRequest.getStudentId()
                        );
                        userRepository.registerStudentUser(studentUserRegistration);

                        mappingEntryService.createMappingEntry(new MappingEntryDTO(
                                studentUserRegistration.uuid(),
                                classEntityDTO.getId()
                        ), MappingRepository.MappingTable.PENDING_STUDENT_CLASS);

                        return jwtService.createToken(studentUserRegistration.uuid());
                    } else {
                        throw new UnauthorizedAPICallException("Student account with id " + studentRequest.getStudentId() + " is already registered");
                    }
                } else {
                    throw new IllegalArgumentException("Unexpected type found while trying to parse a request with role of student");
                }
            }
            case TEACHER -> {
                if (request instanceof TeacherRegisterRequestDTO teacherRequest) {
                    if (userRepository.findNonAdminUserByEmail(teacherRequest.getInstitutional_email()).isEmpty()
                    && userRepository.findTeacherUserByRfc(teacherRequest.getRfc()).isEmpty()) {
                        TeacherUserRegistration teacherUserRegistration = new TeacherUserRegistration(
                                hashPassword(teacherRequest.getPassword()),
                                Role.TEACHER,
                                teacherRequest.getName(),
                                teacherRequest.getPaternal_surname(),
                                teacherRequest.getMaternal_surname(),
                                teacherRequest.getInstitutional_email(),
                                teacherRequest.getRfc()
                        );
                        userRepository.registerTeacherUser(teacherUserRegistration);
                        return jwtService.createToken(teacherUserRegistration.uuid());
                    } else {
                        throw new UnauthorizedAPICallException("Teacher account with " + teacherRequest.getInstitutional_email() + " is already registered");
                    }
                } else {
                    throw new IllegalArgumentException("Unexpected type found while trying to parse a request with role of teacher");
                }
            }
            case TECHNICIAN -> {
                if (request instanceof TechnicianRegisterRequestDTO technicianRequest) {
                    if (userRepository.findNonAdminUserByEmail(technicianRequest.getInstitutional_email()).isEmpty()
                            && userRepository.findTeacherUserByRfc(technicianRequest.getRfc()).isEmpty()){
                        TechnicianUserRegistration technicianUserRegistration = new TechnicianUserRegistration(
                                hashPassword(technicianRequest.getPassword()),
                                Role.TECHNICIAN,
                                technicianRequest.getName(),
                                technicianRequest.getPaternal_surname(),
                                technicianRequest.getMaternal_surname(),
                                technicianRequest.getInstitutional_email(),
                                technicianRequest.getRfc()
                        );
                        userRepository.registerTechnicianUser(technicianUserRegistration);
                        return jwtService.createToken(technicianUserRegistration.uuid());
                    } else {
                        throw new UnauthorizedAPICallException("Teacher account with " + technicianRequest.getInstitutional_email() + " is already registered");
                    }
                } else {
                    throw new IllegalArgumentException("Unexpected type found while trying to parse a request with role of technician");
                }
            }
        }
        throw new IllegalStateException("Unexpected exception happened while attempting to register an account");
    }

    public String hashPassword(String password) {
        return passwordEncoder.encode(password);
    }

    private record Identifier(String value, IdentifierType identifierType) {
    }

    private static Identifier parseIdentifier(String identifier) {
        if (Regexes.studentIdRegex.matcher(identifier).matches()) {
            return new Identifier(identifier, IdentifierType.STUDENT_ID);
        } else if (Regexes.institutionalEmailStudentRegex.matcher(identifier).matches()) {
            return new Identifier(identifier, IdentifierType.STUDENT_INSTITUTIONAL_EMAIL);
        } else if (Regexes.institutionalEmailNonStudentRegex.matcher(identifier).matches()) {
            return new Identifier(identifier, IdentifierType.NON_STUDENT_INSTITUTIONAL_EMAIL);
        } else {
            return new Identifier(identifier, IdentifierType.ADMIN_USERNAME);
        }
    }

    private enum IdentifierType {
        STUDENT_ID,
        STUDENT_INSTITUTIONAL_EMAIL,
        NON_STUDENT_INSTITUTIONAL_EMAIL,
        ADMIN_USERNAME
    }
}
