package com.philopsychia.frontend.components;

import com.philopsychia.frontend.util.Paints;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;

public class CircleGradientCanvas extends Canvas {


    public void draw(){
        GraphicsContext gc = getGraphicsContext2D();

        gc.setFill(Paints.BASE_PAINT);
        gc.fillRect(0, 0, getWidth(), getHeight());

        gc.setFill(Paints.GRADIENT_PAINT);

        int rows = (int) (getWidth()/50)+2;
        double columnsAnalog = ((getHeight()/2)/50)+1;
        int columns = (int) Math.ceil(columnsAnalog);

        double startSize = 100;

        double height = getHeight();
        for (int y = 0; y < columns; y++) {

            double fraction = (double) y / columnsAnalog;
            double size = startSize*(1-fraction);

            for (int x = 0; x < rows; x++) {
                gc.fillOval(x*50-25-(size/2), height - y*50-25, size, size);
            }
        }

        gc.setStroke(Color.WHITE);

        double scale = ((getWidth() / 500) + (getHeight() / 500))/2;
        gc.setLineWidth(10*scale/4+5);
        gc.strokeOval(-100*scale, -100*scale, 250*scale, 250*scale);

        double circleSize = 200 * scale;
        double offset = 130 * scale;

        double x2 = getWidth() - offset;
        double y2 = getHeight() - offset;

        gc.strokeOval(x2, y2, circleSize, circleSize);

    }

    @Override
    public boolean isResizable() {
        return true;
    }

    @Override
    public void resize(double width, double height) {
        super.setWidth(width);
        super.setHeight(height);
        draw();
    }

    @Override
    public double prefWidth(double height) {
        return 0;
    }

    @Override
    public double prefHeight(double width) {
        return 0;
    }

    @Override
    public double maxHeight(double width) {
        return Double.MAX_VALUE;
    }

    @Override
    public double maxWidth(double height) {
        return Double.MAX_VALUE;
    }
}
