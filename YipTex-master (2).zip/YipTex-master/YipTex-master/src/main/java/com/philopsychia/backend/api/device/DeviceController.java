package com.philopsychia.backend.api.device;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.service.auth.AuthService;
import com.philopsychia.backend.service.device.DeviceService;
import com.philopsychia.shared.dto.device.DeviceEntityDTO;
import com.philopsychia.shared.dto.device.DevicePayloadDTO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@PreAuthorize("hasAuthority('ADMIN')")
@RequestMapping("/api/devices")
public class DeviceController {

    private final DeviceService deviceService;

    public DeviceController(DeviceService deviceService) {
        this.deviceService = deviceService;
    }

    @GetMapping
    public List<DeviceEntityDTO> getAllDevices(@AuthenticationPrincipal UserDetails userDetails,
                                               @RequestParam(required = false, name = "number_id") Integer numberId,
                                               @RequestParam(required = false, name = "room_id") GUID roomId) {
        if (numberId != null && roomId != null) {
            return List.of(deviceService.getDevice(numberId, roomId));
        }
        return deviceService.getAllDevices();
    }

    @GetMapping("/{uuid}")
    public DeviceEntityDTO getDevice(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        return deviceService.getDevice(uuid);
    }

    @PutMapping("/{uuid}")
    public void modifyDevice(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid, @RequestBody DevicePayloadDTO dto) {
        deviceService.modifyDevice(uuid, dto);
    }

    @DeleteMapping("/{uuid}")
    public void deleteDevice(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        deviceService.deleteDevice(uuid);
    }

}
