package com.philopsychia.frontend;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.shared.JacksonGUIDDeserializer;
import com.philopsychia.shared.JacksonGUIDSerializer;
import com.philopsychia.shared.dto.auth.JwtDTO;
import javafx.application.Platform;
import javafx.concurrent.Task;
import org.jspecify.annotations.NonNull;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.client.RestClient.RequestHeadersSpec.ConvertibleClientHttpResponse;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.module.SimpleModule;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.function.Supplier;


public final class RestClient {

    private static final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();


    private static org.springframework.web.client.RestClient REST_CLIENT;

    static {
        String targetUrl = "http://localhost:8080";

        try {
            String homeDir = System.getProperty("user.home");
            String portFilePath = homeDir + File.separator + ".philopsychia" + File.separator + "yiptex" + File.separator + "yiptex.port";

            String port = new String(Files.readAllBytes(Paths.get(portFilePath))).trim();
            targetUrl = "http://localhost:" + port;


        } catch (Exception e) {
            System.out.println("Could not read port file from home directory. Backend might not be running.");
        }


        SimpleModule module = new SimpleModule("SharedGuidModule");
        module.addSerializer(GUID.class, new JacksonGUIDSerializer());
        module.addDeserializer(GUID.class, new JacksonGUIDDeserializer());

        JsonMapper javaFxMapper = JsonMapper.builder()
                .addModule(module)
                .build();

        REST_CLIENT = org.springframework.web.client.RestClient.builder()
                .baseUrl(targetUrl)
                .configureMessageConverters(builder -> {
                    var modernConverter = new org.springframework.http.converter.json.JacksonJsonHttpMessageConverter(javaFxMapper);

                    builder
                            .registerDefaults()
                            .withJsonConverter(modernConverter);
                })
                .build();

    }

    public static <U> Task<ApiResponse<U>> unauthorizedGetRequest(Consumer<Task<ApiResponse<U>>> taskSetup,
                                                                  String endpoint,
                                                                  ParameterizedTypeReference<U> responseType,
                                                                  Object... params) {
        return handleRequest(taskSetup, () -> {
            ResponseEntity<U> response = REST_CLIENT.get().uri(endpoint, params)
                    .exchange((request, clientResponse) -> parseResponse(request, clientResponse, responseType));

            return getApiResponse(responseType, response);
        }, responseType);
    }

    public static <T, U> Task<ApiResponse<U>> unauthorizedPostRequest(Consumer<Task<ApiResponse<U>>> taskSetup,
                                                                      String endpoint,
                                                                      T body,
                                                                      ParameterizedTypeReference<U> responseType,
                                                                      Object... params) {
        return handleRequest(taskSetup, () -> {
            ResponseEntity<U> response = REST_CLIENT.post().uri(endpoint, params).contentType(MediaType.APPLICATION_JSON).body(body)
                    .exchange((request, clientResponse) -> parseResponse(request, clientResponse, responseType));

            return getApiResponse(responseType, response);
        }, responseType);
    }

    public static <T, U> Task<ApiResponse<U>> unauthorizedPutRequest(Consumer<Task<ApiResponse<U>>> taskSetup,
                                                                     String endpoint,
                                                                     T body,
                                                                     ParameterizedTypeReference<U> responseType,
                                                                     Object... params) {
        return handleRequest(taskSetup, () -> {
            ResponseEntity<U> response = REST_CLIENT.put().uri(endpoint, params).contentType(MediaType.APPLICATION_JSON).body(body)
                    .exchange((request, clientResponse) -> parseResponse(request, clientResponse, responseType));

            return getApiResponse(responseType, response);
        }, responseType);
    }

    public static <U> Task<ApiResponse<U>> unauthorizedDeleteRequest(Consumer<Task<ApiResponse<U>>> taskSetup,
                                                                     String endpoint,
                                                                     ParameterizedTypeReference<U> responseType,
                                                                     Object... params) {
        return handleRequest(taskSetup, () -> {
            ResponseEntity<U> response = REST_CLIENT.delete().uri(endpoint, params)
                    .exchange((request, clientResponse) -> parseResponse(request, clientResponse, responseType));
            return getApiResponse(responseType, response);
        }, responseType);
    }

    public static <U> Task<ApiResponse<U>> authorizedGetRequest(Consumer<Task<ApiResponse<U>>> taskSetup,
                                                                String endpoint,
                                                                ParameterizedTypeReference<U> responseType,
                                                                Object... params) {
        try {
            return handleRequest(taskSetup, () -> {
                ResponseEntity<U> response = REST_CLIENT.get().uri(endpoint, params).headers(h -> h.setBearerAuth(getToken()))
                        .exchange((request, clientResponse) -> parseResponse(request, clientResponse, responseType));
                return getApiResponse(responseType, response);
            }, responseType);
        } catch (Exception e) {
        }
        return null;
    }

    public static <T, U> Task<ApiResponse<U>> authorizedPostRequest(Consumer<Task<ApiResponse<U>>> taskSetup,
                                                                    String endpoint,
                                                                    T body,
                                                                    ParameterizedTypeReference<U> responseType,
                                                                    Object... params) {
        return handleRequest(taskSetup, () -> {
            ResponseEntity<U> response = REST_CLIENT.post().uri(endpoint, params).headers(h -> h.setBearerAuth(getToken())).contentType(MediaType.APPLICATION_JSON).body(body)
                    .exchange((request, clientResponse) -> parseResponse(request, clientResponse, responseType));
            return getApiResponse(responseType, response);
        }, responseType);
    }

    public static <T, U> Task<ApiResponse<U>> authorizedPutRequest(Consumer<Task<ApiResponse<U>>> taskSetup,
                                                                   String endpoint,
                                                                   T body,
                                                                   ParameterizedTypeReference<U> responseType,
                                                                   Object... params) {
        return handleRequest(taskSetup, () -> {
            ResponseEntity<U> response = REST_CLIENT.put().uri(endpoint, params).headers(h -> h.setBearerAuth(getToken())).contentType(MediaType.APPLICATION_JSON).body(body)
                    .exchange((request, clientResponse) -> parseResponse(request, clientResponse, responseType));
            return getApiResponse(responseType, response);
        }, responseType);
    }

    public static <U> Task<ApiResponse<U>> authorizedDeleteRequest(Consumer<Task<ApiResponse<U>>> taskSetup,
                                                                   String endpoint,
                                                                   ParameterizedTypeReference<U> responseType,
                                                                   Object... params) {
        return handleRequest(taskSetup, () -> {
            ResponseEntity<U> response = REST_CLIENT.delete().uri(endpoint, params).headers(h -> h.setBearerAuth(getToken()))
                    .exchange((request, clientResponse) -> parseResponse(request, clientResponse, responseType));
            return getApiResponse(responseType, response);
        }, responseType);
    }

    private static String getToken() {
        return Frontend.dataStorage.get("session", JwtDTO.class).token();
    }

    private static <T> Task<ApiResponse<T>> handleRequest(Consumer<Task<ApiResponse<T>>> taskSetup, Supplier<ApiResponse<T>> request, ParameterizedTypeReference<T> response_type) {
        Task<ApiResponse<T>> task = new Task<>() {
            @Override
            protected ApiResponse<T> call() {
                try {
                    return request.get();
                } catch (Exception e) {
                    System.out.println(e);
                    return ApiResponse.error(HttpStatus.INTERNAL_SERVER_ERROR);
                }
            }
        };

        taskSetup.accept(task);
        executor.submit(task);
        return task;
    }

    private static <U> @NonNull ApiResponse<U> getApiResponse(ParameterizedTypeReference<U> responseType, ResponseEntity<U> response) {
        HttpStatus status = HttpStatus.valueOf(response.getStatusCode().value());

        if (status.isError()) {
            if (Frontend.dataStorage.has("session") && status == HttpStatus.UNAUTHORIZED) {
                logout(true);
            }
            return ApiResponse.error(status);
        }

        return ApiResponse.ok(response.getBody(), status);
    }

    public static void logout(boolean expired) {
        Frontend.dataStorage.remove("session");
        Platform.runLater(() -> {
            Frontend.reset("login");
            if (expired) Frontend.pushPopup("Ha caducado su sesion, porfavor vuelva a iniciar sesion");
        });
    }

    private static <T> ResponseEntity<T> parseResponse(HttpRequest response, ConvertibleClientHttpResponse clientResponse, ParameterizedTypeReference<T> responseType) throws IOException {

        if (clientResponse.getStatusCode().isError()) {
            return ResponseEntity.status(clientResponse.getStatusCode()).build();
        }

        T successBody = clientResponse.bodyTo(responseType);
        return ResponseEntity.status(clientResponse.getStatusCode()).body(successBody);
    }

    public static void shutdown() {
        executor.shutdown();
    }
}
