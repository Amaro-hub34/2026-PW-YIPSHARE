package com.philopsychia.frontend.control.util;

import lombok.Setter;

import java.util.function.Consumer;
import java.util.function.Supplier;

public abstract class IWithCallback<T> {

    @Setter
    protected Consumer<T> callback;
}
