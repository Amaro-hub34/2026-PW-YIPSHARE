package com.philopsychia.frontend.control.admin.data_input;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.control.util.IWithCallback;
import com.philopsychia.frontend.control.util.IWithLoadFunction;
import com.philopsychia.frontend.util.ScreenUtil;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.room.RoomPayloadDTO;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import org.controlsfx.control.textfield.CustomTextField;

public class RoomDataController extends IWithCallback<RoomPayloadDTO> implements IWithLoadFunction<RoomEntityDTO> {

    private static final String INVALID_NUMBER = "El numero ingresado es invalido";
    private static final String EMPTY_FIELD = "El campo no puede estar vacio";
    public Button returnButton;
    public GridPane gridContainer;
    public VBox roomNameVbox;
    public CustomTextField roomNameField;
    public VBox locationVBox;
    public CustomTextField locationField;
    public VBox acronymVBox;
    public CustomTextField acronymField;
    public VBox machineAmountVbox;
    public CustomTextField machineAmountField;
    public Button next;


    @FXML
    private void initialize() {
    }

    public void tryNext(MouseEvent mouseEvent) {
        cleanGUI();

        boolean passed = true;

        String roomName = roomNameField.getText().trim();
        if (roomName.isEmpty()) {
            roomNameVbox.getChildren().add(ScreenUtil.generateErrorMessage(EMPTY_FIELD));
            passed = false;
        }

        String location = locationField.getText().trim();
        if (location.isEmpty()) {
            locationVBox.getChildren().add(ScreenUtil.generateErrorMessage(EMPTY_FIELD));
            passed = false;
        }

        String acronym = acronymField.getText().trim();
        if (acronym.isEmpty()) {
            acronymVBox.getChildren().add(ScreenUtil.generateErrorMessage(EMPTY_FIELD));
            passed = false;
        }

        String computer_amount_txt = machineAmountField.getText().trim();
        int computer_amount = -1;
        try {
            computer_amount = Integer.parseInt(computer_amount_txt);
            if (computer_amount <= 0) {
                throw new IllegalStateException("Number must not be negative");
            }
        } catch (Exception e) {
            machineAmountVbox.getChildren().add(ScreenUtil.generateErrorMessage(INVALID_NUMBER));
            passed = false;
        }

        if (!passed) return;

        this.callback.accept(new RoomPayloadDTO(
                roomName,
                location,
                acronym,
                computer_amount
        ));
    }

    public void returnToPrevious(MouseEvent mouseEvent) {
        Frontend.pop();
    }

    private void cleanGUI() {
        roomNameVbox.getChildren().removeIf(node -> (node instanceof HBox));
        locationVBox.getChildren().removeIf(node -> (node instanceof HBox));
        acronymVBox.getChildren().removeIf(node -> (node instanceof HBox));
        machineAmountVbox.getChildren().removeIf(node -> (node instanceof HBox));
    }

    @Override
    public void load(RoomEntityDTO input) {
        if (input == null) return;
        roomNameField.setText(input.getName());
        locationField.setText(input.getLocation());
        acronymField.setText(input.getAcronym());
        machineAmountField.setText(String.valueOf(input.getDevice_amount()));
    }
}
