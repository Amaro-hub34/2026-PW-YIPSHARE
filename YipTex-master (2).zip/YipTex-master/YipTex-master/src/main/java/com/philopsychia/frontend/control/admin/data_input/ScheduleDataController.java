package com.philopsychia.frontend.control.admin.data_input;

import com.dlsc.gemsfx.TimePicker;
import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.control.util.IWithCallback;
import com.philopsychia.frontend.control.util.IWithLoadFunction;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ScreenUtil;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.schedule.ScheduleEntityDTO;
import com.philopsychia.shared.dto.schedule.SchedulePayloadDTO;
import com.philopsychia.shared.dto.schedule.Weekday;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import com.philopsychia.shared.dto.user.payload.TeacherPayloadDTO;
import javafx.concurrent.Task;
import javafx.concurrent.WorkerStateEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import org.controlsfx.control.textfield.CustomTextField;
import org.springframework.core.ParameterizedTypeReference;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class ScheduleDataController extends IWithCallback<SchedulePayloadDTO> implements IWithLoadFunction<ScheduleEntityDTO>, IController {

    private static final String INVALID_NUMBER = "El numero ingresado es invalido";
    private static final String EMPTY_FIELD = "El campo no puede estar vacio";

    private static final String MALFORMED_NAME = "Solo caracteres de un alfabeto, apostrofes, guiones y espacios";
    private static final String MALFORMED_SURNAME = "Solo caracteres de un alfabeto, apostrofes y guiones";
    private static final String MALFORMED_EMAIL = "Solo terminacion \"@ipn.mx\"";
    private static final String INVALID_SELECTION = "Seleccione una opcion";

    private static final String MALFORMED_RFC = "El RFC ingresado no es valido";
    public static final String INVALID_TIMELINE_STATE = "Tiempo final debe ser mayor al tiempo inicial";
    public static final String TIMELINE_WITHIN_BOUNDS_STATE = "Tiempo debe de estar en un rango de 7am a 9pm";
    public static final LocalTime _7AM = LocalTime.of(6, 59, 59);
    public static final LocalTime _9PM = LocalTime.of(21, 0, 1);

    public GridPane gridContainer;
    public Button returnButton;

    public VBox classVBox;
    public ChoiceBox<String> classField;

    public VBox roomVBox;
    public ChoiceBox<String> roomField;

    public VBox weekdayVBox;
    public ChoiceBox<String> weekdayField;

    public VBox timeVBox;
    public Button next;

    public TimePicker startTime;
    public TimePicker endTime;

    private final List<GUID> classes = new ArrayList<>();
    private final List<GUID> rooms = new ArrayList<>();

    private Task<ApiResponse<List<ClassEntityDTO>>> task1;
    private Task<ApiResponse<List<RoomEntityDTO>>> task2;

    @FXML
    private void initialize() {
    }

    public void tryNext(MouseEvent mouseEvent) {
        cleanGUI();

        boolean passed = true;

        int group = classField.getSelectionModel().getSelectedIndex();
        if (group <= 0) {
            classVBox.getChildren().add(ScreenUtil.generateErrorMessage(INVALID_SELECTION));
            passed = false;
        }

        int room = roomField.getSelectionModel().getSelectedIndex();
        if (room <= 0) {
            roomVBox.getChildren().add(ScreenUtil.generateErrorMessage(INVALID_SELECTION));
            passed = false;
        }

        int weekday = weekdayField.getSelectionModel().getSelectedIndex();
        if (weekday <= 0) {
            weekdayVBox.getChildren().add(ScreenUtil.generateErrorMessage(INVALID_SELECTION));
            passed = false;
        }

        LocalTime start = startTime.getTime();
        LocalTime end = endTime.getTime();

        if (end.isBefore(start) || end.equals(start)) {
            timeVBox.getChildren().add(ScreenUtil.generateErrorMessage(INVALID_TIMELINE_STATE));
            passed = false;
        }

        if (!(start.isAfter(_7AM)) && (start.isBefore(_9PM))
        || !(end.isAfter(_7AM)) && (end.isBefore(_9PM))) {
            timeVBox.getChildren().add(ScreenUtil.generateErrorMessage(TIMELINE_WITHIN_BOUNDS_STATE));
            passed = false;
        }

        if (!passed) return;

        this.callback.accept(new SchedulePayloadDTO(
                classes.get(group-1),
                rooms.get(room-1),
                switch (weekday) {
                    case 1 -> Weekday.MONDAY;
                    case 2 -> Weekday.TUESDAY;
                    case 3 -> Weekday.WEDNESDAY;
                    case 4 -> Weekday.THURSDAY;
                    case 5 -> Weekday.FRIDAY;
                    default -> throw new IllegalStateException("Unexpected value: " + weekday);
                },
                start,
                end
        ));
    }

    public void returnToPrevious(MouseEvent mouseEvent) {
        Frontend.pop();
    }

    private void cleanGUI() {
        classVBox.getChildren().removeIf(node -> (node instanceof HBox));
        roomVBox.getChildren().removeIf(node -> (node instanceof HBox));
        weekdayVBox.getChildren().removeIf(node -> (node instanceof HBox));
        timeVBox.getChildren().removeIf(node -> (node instanceof HBox));
    }

    @Override
    public void load(ScheduleEntityDTO input) {
        if (input == null) return;
        EventHandler<WorkerStateEvent> event = task1.getOnSucceeded();
        task1.setOnSucceeded(e -> {
            event.handle(e);

            EventHandler<WorkerStateEvent> event2 = task2.getOnSucceeded();
            task2.setOnSucceeded(e2 -> {
                event2.handle(e2);

                classField.getSelectionModel().select(classes.indexOf(input.getClass_id())+1);
                roomField.getSelectionModel().select(rooms.indexOf(input.getRoom_id())+1);
                weekdayField.getSelectionModel().select(switch (input.getWeekday()) {
                    case MONDAY -> 1;
                    case TUESDAY -> 2;
                    case WEDNESDAY -> 3;
                    case THURSDAY -> 4;
                    case FRIDAY, SATURDAY, SUNDAY -> 5;
                });

                startTime.setTime(input.getStart_time());
                endTime.setTime(input.getEnd_time());
            });
        });
    }

    @Override
    public void init() {
        classField.getItems().addAll("Seleccione una clase");

        this.task1 = RestClient.authorizedGetRequest(
                t -> {
                    Frontend.loadingOverlay.bindToTask(t);
                    t.setOnSucceeded(event -> {
                        ApiResponse<List<ClassEntityDTO>> apiResponse = t.getValue();

                        if (apiResponse.isError()) {
                            ViewLoader.generatePopup("Hubo un error insperado");
                        } else {
                            int i = 0;
                            for (ClassEntityDTO group : apiResponse.data()) {
                                i++;

                                classes.add(group.getId());
                                classField.getItems().add(group.getName());
                            }

                            this.task2 = RestClient.authorizedGetRequest(
                                    t2 -> {
                                        Frontend.loadingOverlay.bindToTask(t2);
                                        t2.setOnSucceeded(e -> {
                                            ApiResponse<List<RoomEntityDTO>> apiResponse2 = t2.getValue();

                                            if (apiResponse2.isError()) {
                                                ViewLoader.generatePopup("Hubo un error insperado");
                                            } else {
                                                int i2 = 0;
                                                for (RoomEntityDTO room : apiResponse2.data()) {
                                                    i2++;

                                                    rooms.add(room.getId());
                                                    roomField.getItems().add(room.getName());
                                                }
                                            }
                                        });
                                    }, "/api/rooms",
                                    new ParameterizedTypeReference<List<RoomEntityDTO>>() {}
                            );
                        }
                    });
                }, "/api/classes",
                new ParameterizedTypeReference<List<ClassEntityDTO>>() {}
        );

        roomField.getItems().addAll("Seleccione un laboratorio");


        weekdayField.getItems().addAll(
                "Seleccione un dia",
                "Lunes",
                "Martes",
                "Miercoles",
                "Jueves",
                "Viernes"
        );

        classField.getSelectionModel().select(0);
        roomField.getSelectionModel().select(0);
        weekdayField.getSelectionModel().select(0);
    }
}
