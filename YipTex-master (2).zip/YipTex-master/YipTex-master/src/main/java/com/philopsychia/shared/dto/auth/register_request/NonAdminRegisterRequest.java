package com.philopsychia.shared.dto.auth.register_request;

import com.philopsychia.shared.Regexes;
import com.philopsychia.shared.dto.user.Role;
import lombok.Getter;
import lombok.Setter;

public abstract class NonAdminRegisterRequest extends BaseRegisterRequestDTO{
    @Getter
    @Setter
    private String name;
    @Getter
    @Setter
    private String paternal_surname;
    @Getter
    @Setter
    private String maternal_surname;
    @Getter
    @Setter
    private String institutional_email;

    public NonAdminRegisterRequest() {
        super();
    }

    public NonAdminRegisterRequest(String password, Role role, String name, String paternalSurname, String maternalSurname, String institutionalEmail) {
        super(password, role);
        this.name = name;
        paternal_surname = paternalSurname;
        maternal_surname = maternalSurname;
        institutional_email = institutionalEmail;
    }

    @Override
    public boolean validate() {
        return super.validate()
                && Regexes.nameRegex.matcher(getName()).matches()
                && Regexes.surnameRegex.matcher(getPaternal_surname()).matches()
                && Regexes.surnameRegex.matcher(getMaternal_surname()).matches()
                && Regexes.institutionalEmailRegex.matcher(getInstitutional_email()).matches();
    }
}
