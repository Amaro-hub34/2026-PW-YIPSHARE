package com.philopsychia.shared.dto.user.profile;

public record ProfileDTO(String name,
                         String paternal_surname,
                         String maternal_surname,
                         String institutional_email) {
}
