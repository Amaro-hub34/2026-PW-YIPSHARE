package com.philopsychia.backend.database.registration.user;

import com.philopsychia.shared.dto.user.Role;

public class AdminUserRegistration extends UserRegistration {
    private final String account_username;

    public AdminUserRegistration(String account_username, String password_hash, Role role) {
        super(password_hash, role);
        this.account_username = account_username;
    }

    public String account_username() {
        return account_username;
    }
}
