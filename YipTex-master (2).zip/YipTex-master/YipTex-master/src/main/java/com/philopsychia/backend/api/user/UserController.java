package com.philopsychia.backend.api.user;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.backend.service.auth.AuthService;
import com.philopsychia.backend.service.user.UserService;
import com.philopsychia.backend.util.exception.BadRequestException;
import com.philopsychia.backend.util.exception.ResourceNotFound;
import com.philopsychia.backend.util.exception.UnauthorizedAPICallException;
import com.philopsychia.shared.dto.auth.register_request.BaseRegisterRequestDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.Role;
import com.philopsychia.shared.dto.user.payload.BasePayloadDTO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@PreAuthorize("hasAuthority('ADMIN')")
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private final AuthService authService;

    public UserController(UserService userService, AuthService authService) {
        this.userService = userService;
        this.authService = authService;
    }

    @GetMapping
    public List<BaseUserDTO> getAllUsers(@AuthenticationPrincipal UserDetails userDetails) {
        return userService.getAllUsers();
    }

    @PostMapping
    public void createUser(@AuthenticationPrincipal UserDetails userDetails, @RequestBody BaseRegisterRequestDTO dto) {
        try {
            Optional<Role> role = userDetails.getAuthorities().stream()
                    .filter(Role.class::isInstance)
                    .map(Role.class::cast)
                    .findFirst();

            if (role.isEmpty()) throw new ResourceNotFound("Couldnt obtain role");
            authService.tryRegister(dto, role.get());
        } catch (UnauthorizedAPICallException e) {
            throw new BadRequestException("Resource already registered");
        }

    }

    @GetMapping("/{uuid}")
    public BaseUserDTO getUser(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        return authService.getUserInformation(uuid);
    }

    @PutMapping("/{uuid}")
    public void modifyUser(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid, @RequestBody BasePayloadDTO dto) {
        userService.modify(dto, uuid);
    }

    @DeleteMapping("/{uuid}")
    public void deleteUser(@AuthenticationPrincipal UserDetails userDetails, @PathVariable("uuid") GUID uuid) {
        userService.deleteUser(uuid);
    }

}
