package com.philopsychia.backend.database.entity.user;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.shared.dto.user.Role;

public class AdminUserEntity extends UserEntity {
    private final String account_username;

    public AdminUserEntity(GUID id, String accountUsername, String password_hash, Role role) {
        super(id, password_hash, role);
        account_username = accountUsername;
    }

    public String account_username() {
        return account_username;
    }
}
