package com.philopsychia.backend;

import com.github.f4b6a3.uuid.alt.GUID;
import com.github.javakeyring.Keyring;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.source.ImmutableJWKSet;
import com.nimbusds.jose.jwk.source.JWKSource;
import com.nimbusds.jose.proc.DefaultJOSEObjectTypeVerifier;
import com.nimbusds.jose.proc.JWSKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jwt.JWTClaimNames;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.proc.ConfigurableJWTProcessor;
import com.nimbusds.jwt.proc.DefaultJWTClaimsVerifier;
import com.nimbusds.jwt.proc.DefaultJWTProcessor;
import com.philopsychia.backend.database.driver.DatabaseDriver;
import com.philopsychia.backend.database.driver.impl.H2Driver;
import com.philopsychia.backend.database.driver.impl.MySQLDriver;
import com.philopsychia.backend.util.data.AppKeyPair;
import com.philopsychia.backend.util.function.SchemaUtil;
import com.philopsychia.shared.JacksonGUIDDeserializer;
import com.philopsychia.shared.JacksonGUIDSerializer;
import lombok.Getter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import tools.jackson.databind.JacksonModule;
import tools.jackson.databind.ObjectMapper;
import tools.jackson.databind.json.JsonMapper;
import tools.jackson.databind.module.SimpleModule;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;

@Configuration
public class Config {

    @Bean
    public DatabaseDriver databaseDriver(Environment environment) {
        String dbType = environment.getProperty("app.db.type", "h2");

        try {
            if (dbType.equalsIgnoreCase("mysql")) {
                MySQLDriver mysqlDriver = new MySQLDriver();
                mysqlDriver.initialize(SchemaUtil.getSchemaInit());
                return mysqlDriver;
            }
        } catch (Exception ex) {
            System.out.println("Error initializing database driver with type " + dbType + ", falling back to H2: " + ex.getMessage());
        }

        H2Driver h2Driver = new H2Driver();
        h2Driver.initialize(SchemaUtil.getSchemaInit());
        return h2Driver;
    }

    @Bean
    public AppKeyPair jwkSet() {
        try (Keyring keyring = Keyring.create()) {
            try {
                String masterKey = keyring.getPassword("philopsychia.com", "master-file-encryption-key");
                return AppKeyPair.load(masterKey.getBytes(StandardCharsets.UTF_8));
            } catch (Exception e) {
                return AppKeyPair.create(keyring);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Bean
    public ConfigurableJWTProcessor<SecurityContext> jwtProcessor() {
        try {
            ConfigurableJWTProcessor<SecurityContext> jwtProcessor = new DefaultJWTProcessor<>();

            jwtProcessor.setJWSTypeVerifier(
                    new DefaultJOSEObjectTypeVerifier<>(
                            JOSEObjectType.JWT,
                            new JOSEObjectType("at+jwt"),
                            null));

            JWKSource<SecurityContext> keySource =
                    new ImmutableJWKSet<>(jwkSet().publicKeyAPI());

            JWSAlgorithm expectedJWSAlg = JWSAlgorithm.RS256;

            JWKSet jwkSet = new com.nimbusds.jose.jwk.JWKSet(jwkSet().keypair());

            JWSKeySelector<SecurityContext> keySelector =
                    new com.nimbusds.jose.proc.JWSVerificationKeySelector<>(
                            com.nimbusds.jose.JWSAlgorithm.RS256,
                            new com.nimbusds.jose.jwk.source.ImmutableJWKSet<>(jwkSet)
                    );
            jwtProcessor.setJWSKeySelector(keySelector);

            jwtProcessor.setJWTClaimsSetVerifier(new DefaultJWTClaimsVerifier<>(
                    new JWTClaimsSet.Builder().issuer("https://philopsychia.com").build(),
                    new HashSet<>(Arrays.asList(
                            JWTClaimNames.SUBJECT,
                            JWTClaimNames.ISSUED_AT,
                            JWTClaimNames.EXPIRATION_TIME,
                            JWTClaimNames.JWT_ID))));
            return jwtProcessor;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Bean
    @Primary
    public JsonMapper jackson3ObjectMapper() {
        SimpleModule module = new SimpleModule("SharedGuidModule");
        module.addSerializer(GUID.class, new JacksonGUIDSerializer());
        module.addDeserializer(GUID.class, new JacksonGUIDDeserializer());

        return JsonMapper.builder()
                .addModule(module)
                .build();
    }
}
