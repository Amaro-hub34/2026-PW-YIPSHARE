package com.philopsychia.frontend.control.teacher;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.group.ClassEntityDTO;
import com.philopsychia.shared.dto.group.ClassPayloadDTO;
import com.philopsychia.shared.dto.group.Schedule;
import com.philopsychia.shared.dto.mapping_table.MappingEntryDTO;
import com.philopsychia.shared.dto.user.entity.BaseUserDTO;
import com.philopsychia.shared.dto.user.entity.StudentUserDTO;
import com.philopsychia.shared.dto.user.entity.TeacherUserDTO;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.support.RestClientAdapter;

import java.util.ArrayList;
import java.util.List;

public class ClassesScreenController implements IController  {

    public GridPane pendingUsersTable;
    public GridPane usersTable;
    public HBox groupsBar;
    public VBox contents;

    private List<Button> classButtons = new ArrayList<>();

    @FXML
    private void initialize(){
        contents.setVisible(false);
        contents.setDisable(true);
    }

    @Override
    public void init() {

        RestClient.authorizedGetRequest(task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<BaseUserDTO> apiResponse = task.getValue();

                        if (!apiResponse.isError()) {
                            BaseUserDTO user = apiResponse.data();
                            if (user instanceof TeacherUserDTO teacherUserDTO) {
                                RestClient.authorizedGetRequest(t -> {
                                            Frontend.loadingOverlay.bindToTask(t);
                                            t.setOnSucceeded(e -> {
                                                ApiResponse<List<ClassEntityDTO>> apiResponse2 = t.getValue();
                                                if (!apiResponse2.isError()) {
                                                    if (apiResponse2.data().isEmpty()) {
                                                        Label label = new Label("No tiene clases asignadas");
                                                        label.setFont(Font.font("Encode Sans Semi Expanded Light", FontWeight.NORMAL, FontPosture.REGULAR, 15 ));
                                                        label.setStyle("-fx-text-fill: black;");
                                                        groupsBar.getChildren().add(label);
                                                        var x = groupsBar.getChildren();
                                                        System.out.println("test");
                                                    } else {
                                                        for (ClassEntityDTO classEntityDTO : apiResponse2.data()) {
                                                            Button button = new Button(classEntityDTO.getName());
                                                            button.setStyle("-fx-background-color: #991859FF; -fx-text-fill: #FFFFFFFF");
                                                            button.setOnMouseClicked(e2 -> selectedClass(e2, classEntityDTO, button));
                                                            classButtons.add(button);
                                                            groupsBar.getChildren()
                                                                    .add(button);
                                                        }
                                                    }
                                                }
                                            });
                                        }, "api/classes?teacherId={teacherId}",
                                        new ParameterizedTypeReference<List<ClassEntityDTO>>() {},
                                        teacherUserDTO.getId());
                            }
                        }
                    });
                }, "/api/auth/me",
                new ParameterizedTypeReference<BaseUserDTO>() {});
    }

    private void selectedClass(MouseEvent mouseEvent, ClassEntityDTO classEntityDTO, Button button) {
        classButtons.forEach(nonSelectedButton -> nonSelectedButton.setStyle("-fx-background-color: #991859FF; -fx-text-fill: #FFFFFFFF"));
        button.setStyle("-fx-background-color: #bd3f61; -fx-text-fill: #212121");

        contents.setVisible(true); contents.setDisable(false);

        clearTable(pendingUsersTable);
        clearTable(usersTable);

        RestClient.authorizedGetRequest(t -> {
            Frontend.loadingOverlay.bindToTask(t);
            t.setOnSucceeded(event -> {
                ApiResponse<List<MappingEntryDTO>> mappingEntriesApiResponse
                        = t.getValue();
                if (!mappingEntriesApiResponse.isError()) {
                    int i = 0;
                    for (MappingEntryDTO mappingEntryDTO : mappingEntriesApiResponse.data()) {
                        i++;
                        int finalI = i;
                        RestClient.authorizedGetRequest(t2 -> {
                                    Frontend.loadingOverlay.bindToTask(t2);
                                    t2.setOnSucceeded(e2 -> {
                                        ApiResponse<BaseUserDTO> userDTOApiResponse = t2.getValue();
                                        if (!userDTOApiResponse.isError() && userDTOApiResponse.data() instanceof StudentUserDTO student) {
                                            List<Node> nodesForRow = List.of(
                                                    new Label(String.format("%s %s %s", student.getName(), student.getPaternal_surname(), student.getMaternal_surname())),
                                                    new Label(String.valueOf(student.getStudentId())),
                                                    new Label(student.getInstitutional_email()),
                                                    new Button("", new FontIcon(Feather.CHECK) {{this.setIconColor(Color.WHITE);}}) {
                                                        {
                                                            this.setStyle("-fx-background-color: #84cc1e; -fx-background-radius: 100");
                                                            this.setOnMouseClicked(event -> acceptStudent(mouseEvent, classEntityDTO, button, student));
                                                        }
                                                    },
                                                    new Button("", new FontIcon(Feather.X) {{this.setIconColor(Color.WHITE);}}) {
                                                        {
                                                            this.setStyle("-fx-background-color: #ce2c2c; -fx-background-radius: 100");
                                                            this.setOnMouseClicked(event -> denyStudent(mouseEvent, classEntityDTO, button, student));
                                                        }
                                                    }
                                            );

                                            int j = 0;
                                            for (Node node : nodesForRow) {
                                                pendingUsersTable.add(node,j, finalI);
                                                GridPane.setHalignment(node, HPos.CENTER);
                                                j++;
                                            }

                                            pendingUsersTable.getRowConstraints().add(
                                                    new RowConstraints(50)
                                            );
                                        }
                                    });
                                }, "api/users/{id}",
                                new ParameterizedTypeReference<BaseUserDTO>() {},
                                mappingEntryDTO.getUser_id());
                    }
                }
            });
            }, "/api/classes/{class_id}/pending_students",
                new ParameterizedTypeReference<List<MappingEntryDTO>>() {},
                classEntityDTO.getId());

        RestClient.authorizedGetRequest(t -> {
                    Frontend.loadingOverlay.bindToTask(t);
                    t.setOnSucceeded(event -> {
                        ApiResponse<List<MappingEntryDTO>> mappingEntriesApiResponse
                                = t.getValue();
                        if (!mappingEntriesApiResponse.isError()) {
                            int i = 0;
                            for (MappingEntryDTO mappingEntryDTO : mappingEntriesApiResponse.data()) {
                                i++;
                                int finalI = i;
                                RestClient.authorizedGetRequest(t2 -> {
                                            Frontend.loadingOverlay.bindToTask(t2);
                                            t2.setOnSucceeded(e2 -> {
                                                ApiResponse<BaseUserDTO> userDTOApiResponse = t2.getValue();
                                                if (!userDTOApiResponse.isError() && userDTOApiResponse.data() instanceof StudentUserDTO student) {
                                                    List<Node> nodesForRow = List.of(
                                                            new Label(String.format("%s %s %s", student.getName(), student.getPaternal_surname(), student.getMaternal_surname())),
                                                            new Label(String.valueOf(student.getStudentId())),
                                                            new Label(student.getInstitutional_email()),
                                                            new Button("", new FontIcon(Feather.MONITOR) {{this.setIconColor(Color.WHITE);}}) {
                                                                {
                                                                    this.setStyle("-fx-background-color: #991859; -fx-background-radius: 100");
                                                                    this.setOnMouseClicked(event -> {
                                                                        Frontend.pushWithIO("teacher/show_devices", null, student.getId());
                                                                    });
                                                                }
                                                            },
                                                            new Button("", new FontIcon(Feather.TRASH) {{this.setIconColor(Color.WHITE);}}) {
                                                                {
                                                                    this.setStyle("-fx-background-color: #212121; -fx-background-radius: 100");
                                                                    this.setOnMouseClicked(event -> deleteStudent(mouseEvent, classEntityDTO, button, student));
                                                                }
                                                            }
                                                    );

                                                    int j = 0;
                                                    for (Node node : nodesForRow) {
                                                        usersTable.add(node,j, finalI);
                                                        GridPane.setHalignment(node, HPos.CENTER);
                                                        j++;
                                                    }

                                                    usersTable.getRowConstraints().add(
                                                            new RowConstraints(50)
                                                    );
                                                }
                                            });
                                        }, "api/users/{id}",
                                        new ParameterizedTypeReference<BaseUserDTO>() {},
                                        mappingEntryDTO.getUser_id());
                            }
                        }
                    });
                }, "/api/classes/{class_id}/students",
                new ParameterizedTypeReference<List<MappingEntryDTO>>() {},
                classEntityDTO.getId());
    }

    private void denyStudent(MouseEvent mouseEvent, ClassEntityDTO classEntityDTO, Button button, StudentUserDTO student) {
        Frontend.pushConfirmation("Esta seguro de que desea denegar este alumno", () -> {
            RestClient.authorizedDeleteRequest(t -> {
                        Frontend.loadingOverlay.bindToTask(t);
                        t.setOnSucceeded(e2 -> {
                            ApiResponse<Void> voidResponse = t.getValue();

                            if (voidResponse.isError()) {
                                Frontend.pushPopup("Hubo un error inesperado");
                            } else {
                                RestClient.authorizedDeleteRequest(t2 -> {
                                            Frontend.loadingOverlay.bindToTask(t2);
                                            t2.setOnSucceeded(e3 -> {
                                                ApiResponse<Void> voidResponse2 = t2.getValue();

                                                if (voidResponse2.isError()) {
                                                    Frontend.pushPopup("Hubo un error inesperado");
                                                } else {
                                                    selectedClass(mouseEvent, classEntityDTO, button);
                                                }
                                            });
                                        }, "/api/users/{uuid}",
                                        new ParameterizedTypeReference<Void>() {},
                                        student.getId());
                            }
                        });
                    }, "/api/classes/{class_id}/pending_students/{user_id}",
                    new ParameterizedTypeReference<Void>() {},
                    classEntityDTO.getId(),
                    student.getId());
        });
    }

    private void deleteStudent(MouseEvent mouseEvent, ClassEntityDTO classEntityDTO, Button button, StudentUserDTO student) {
        Frontend.pushConfirmation("Esta seguro de que desea borrar este alumno", () -> {
            RestClient.authorizedDeleteRequest(t2 -> {
                        Frontend.loadingOverlay.bindToTask(t2);
                        t2.setOnSucceeded(e3 -> {
                            ApiResponse<Void> voidResponse2 = t2.getValue();

                            if (voidResponse2.isError()) {
                                Frontend.pushPopup("Hubo un error inesperado");
                            } else {
                                selectedClass(mouseEvent, classEntityDTO, button);
                            }
                        });
                    }, "/api/users/{uuid}",
                    new ParameterizedTypeReference<Void>() {},
                    student.getId());
        });
    }

    private void acceptStudent(MouseEvent mouseEvent, ClassEntityDTO classEntityDTO, Button button, StudentUserDTO student) {
        Frontend.pushConfirmation("Esta seguro de que desea aceptar este alumno", () -> {
            RestClient.authorizedDeleteRequest(t -> {
                        Frontend.loadingOverlay.bindToTask(t);
                        t.setOnSucceeded(e2 -> {
                            ApiResponse<Void> voidResponse = t.getValue();

                            if (voidResponse.isError()) {
                                Frontend.pushPopup("Hubo un error inesperado");
                            } else {

                                RestClient.authorizedPostRequest(t2 -> {
                                            Frontend.loadingOverlay.bindToTask(t2);
                                            t2.setOnSucceeded(e3 -> {
                                                ApiResponse<Void> voidResponse2 = t2.getValue();

                                                if (voidResponse2.isError()) {
                                                    Frontend.pushPopup("Hubo un error inesperado");
                                                } else {
                                                    selectedClass(mouseEvent, classEntityDTO, button);
                                                }
                                            });
                                        }, "/api/classes/{class_id}/students",
                                        student.getId(),
                                        new ParameterizedTypeReference<Void>() {},
                                        classEntityDTO.getId());
                            }
                        });
                    }, "/api/classes/{class_id}/pending_students/{user_id}",
                    new ParameterizedTypeReference<Void>() {},
                    classEntityDTO.getId(),
                    student.getId());
        });
    }

    private void clearTable(GridPane gridPane) {
        List<Node> nodesToRemove = new ArrayList<>();
        for (Node node : gridPane.getChildren()) {
            Integer rowIndex = GridPane.getRowIndex(node);
            if (rowIndex != null && rowIndex > 0) {
                nodesToRemove.add(node);
            }
        }

        gridPane.getRowConstraints().removeIf(x -> {
            return gridPane.getRowConstraints().indexOf(x) != 0;
        });

        gridPane.getChildren().removeAll(nodesToRemove);
    }

    public void createClass(MouseEvent mouseEvent) {
        Frontend.pushWithIO("admin/data_input/class_data", (ClassPayloadDTO classPayloadDto) -> {

            RestClient.authorizedPostRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                if (apiResponse.code() == HttpStatus.BAD_REQUEST) {
                                    Frontend.pop(); Frontend.pop();
                                    Frontend.pushPopup("Los datos usados ya han sido registrados");
                                } else {
                                    Frontend.pushPopup("Hubo un error inesperado");
                                }
                            } else {
                                Frontend.pop();
                                init();
                            }
                        });
                    }, "/api/classes",
                    classPayloadDto,
                    new ParameterizedTypeReference<Void>() {}
            );
        }, null);
    }

    private void modifyClass(MouseEvent mouseEvent, ClassEntityDTO input, GUID id) {
        Frontend.pushWithIO("admin/data_input/class_data", (ClassPayloadDTO classPayloadDto) -> {
            RestClient.authorizedPutRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                if (apiResponse.code() == HttpStatus.BAD_REQUEST) {
                                    Frontend.pop();
                                    Frontend.pushPopup("Los datos usados ya han sido registrados");
                                } else {
                                    Frontend.pushPopup("Hubo un error inesperado");
                                }
                            } else {
                                Frontend.pop();
                                init();
                            }
                        });
                    }, "/api/classes/{id}",
                    classPayloadDto,
                    new ParameterizedTypeReference<Void>() {},
                    id
            );
        }, input);
    }

    private void deleteClass(MouseEvent mouseEvent, GUID id) {
        Frontend.pushConfirmation("Esta seguro de que desea borrar esta clase", () -> {
            RestClient.authorizedDeleteRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                ViewLoader.generatePopup("Hubo un error insperado");
                            } else {
                                init();
                            }
                        });
                    }, "/api/classes/{id}",
                    new ParameterizedTypeReference<Void>() {},
                    id
            );
        });
    }
}