package com.philopsychia.frontend.control.admin;

import com.github.f4b6a3.uuid.alt.GUID;
import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.control.util.IController;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ViewLoader;
import com.philopsychia.shared.dto.room.RoomEntityDTO;
import com.philopsychia.shared.dto.room.RoomPayloadDTO;
import javafx.fxml.FXML;
import javafx.geometry.HPos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.paint.Color;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.List;

public class RoomsScreenController implements IController  {
    public Button newButton;
    public GridPane roomTable;

    @FXML
    private void initialize(){}

    @Override
    public void init() {

        List<Node> nodesToRemove = new ArrayList<>();
        for (Node node : roomTable.getChildren()) {
            Integer rowIndex = GridPane.getRowIndex(node);
            if (rowIndex != null && rowIndex > 0) {
                nodesToRemove.add(node);
            }
        }

        roomTable.getRowConstraints().removeIf(x -> {
            return roomTable.getRowConstraints().indexOf(x) != 0;
        });

        roomTable.getChildren().removeAll(nodesToRemove);

        RestClient.authorizedGetRequest(
                task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<List<RoomEntityDTO>> apiResponse = task.getValue();

                        if (apiResponse.isError()) {
                            ViewLoader.generatePopup("Hubo un error insperado");
                        } else {
                            int i = 0;
                            for (RoomEntityDTO roomEntityDTO : apiResponse.data()) {
                                i++;

                                List<Node> nodesForRow = List.of(
                                        new Label(roomEntityDTO.getName()),
                                        new Label(roomEntityDTO.getLocation()),
                                        new Label(roomEntityDTO.getAcronym()),
                                        new Label(String.valueOf(roomEntityDTO.getDevice_amount())),
                                        new Button("", new FontIcon(Feather.PEN_TOOL) {{this.setIconColor(Color.WHITE);}}) {
                                            {
                                                this.setStyle("-fx-background-color: #991859; -fx-background-radius: 100");
                                                this.setOnMouseClicked(event -> modifyRoom(event, roomEntityDTO, roomEntityDTO.getId()));
                                            }
                                        },
                                        new Button("", new FontIcon(Feather.TRASH) {{this.setIconColor(Color.WHITE);}}) {
                                            {
                                                this.setStyle("-fx-background-color: #262626; -fx-background-radius: 100");
                                                this.setOnMouseClicked(event -> deleteRoom(event, roomEntityDTO.getId()));
                                            }
                                        }
                                );

                                int j = 0;
                                for (Node node : nodesForRow) {
                                    roomTable.add(node,j, i);
                                    GridPane.setHalignment(node, HPos.CENTER);
                                    j++;
                                }

                                roomTable.getRowConstraints().add(
                                        new RowConstraints(50)
                                );
                            }
                        }
                    });
                }, "/api/rooms",
                new ParameterizedTypeReference<List<RoomEntityDTO>>() {}
        );

    }

    public void createRoom(MouseEvent mouseEvent) {
        Frontend.pushWithIO("admin/data_input/room_data", (RoomPayloadDTO roomPayloadDTO) -> {
            RestClient.authorizedPostRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                Frontend.pop();
                                if (apiResponse.code() == HttpStatus.BAD_REQUEST)
                                    Frontend.pushPopup("Los datos usados ya estan registrados");
                                else Frontend.pushPopup("Hubo un error insperado");
                            } else {
                                Frontend.pop();
                                init();
                            }
                        });
                    }, "/api/rooms",
                    roomPayloadDTO,
                    new ParameterizedTypeReference<Void>() {}
            );
        }, null);
    }

    private void modifyRoom(MouseEvent mouseEvent, RoomEntityDTO input, GUID id) {
        Frontend.pushWithIO("admin/data_input/room_data", (RoomPayloadDTO roomPayloadDTO) -> {
            RestClient.authorizedPutRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                Frontend.pop();
                                if (apiResponse.code() == HttpStatus.BAD_REQUEST)
                                    Frontend.pushPopup("Los datos usados ya estan registrados");
                                else Frontend.pushPopup("Hubo un error insperado");
                            } else {
                                Frontend.pop();
                                init();
                            }
                        });
                    }, "/api/rooms/{id}",
                    roomPayloadDTO,
                    new ParameterizedTypeReference<Void>() {},
                    id
            );
        }, input);
    }

    private void deleteRoom(MouseEvent mouseEvent, GUID id) {
        Frontend.pushConfirmation("Esta seguro de que desea borrar este salon", () -> {
            RestClient.authorizedDeleteRequest(
                    task -> {
                        Frontend.loadingOverlay.bindToTask(task);
                        task.setOnSucceeded(event -> {
                            ApiResponse<Void> apiResponse = task.getValue();

                            if (apiResponse.isError()) {
                                ViewLoader.generatePopup("Hubo un error insperado");
                            } else {
                                init();
                            }
                        });
                    }, "/api/rooms/{id}",
                    new ParameterizedTypeReference<Void>() {},
                    id
            );
        });
    }
}