package com.philopsychia.frontend.control;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.RestClient;
import com.philopsychia.frontend.util.ApiResponse;
import com.philopsychia.frontend.util.ScreenUtil;
import com.philopsychia.frontend.util.TransitionUtil;
import com.philopsychia.shared.dto.auth.JwtDTO;
import com.philopsychia.shared.dto.auth.LoginRequestDTO;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Paint;
import org.controlsfx.control.textfield.CustomPasswordField;
import org.controlsfx.control.textfield.CustomTextField;
import org.kordamp.ikonli.feather.Feather;
import org.kordamp.ikonli.javafx.FontIcon;
import org.springframework.core.ParameterizedTypeReference;

public class LoginController {

    private static final Paint START_COLOR = Paint.valueOf("000000FF");
    private static final Paint HOVER_COLOR = Paint.valueOf("D0D0D0FF");

    public LoginController() {}

    @FXML
    private CustomPasswordField passwordField;

    @FXML
    private CustomTextField usernameField;

    @FXML
    public Button loginButton;

    @FXML
    private void initialize() {
        usernameField.setLeft(new FontIcon(Feather.USER));

        ScreenUtil.initializePasswordField(passwordField);

        TransitionUtil.applyHoverTransition(loginButton, START_COLOR, HOVER_COLOR);
    }

    public void sendLoginRequest(MouseEvent mouseEvent) {
        RestClient.unauthorizedPostRequest(
                task -> {
                    Frontend.loadingOverlay.bindToTask(task);
                    task.setOnSucceeded(event -> {
                        ApiResponse<JwtDTO> apiResponse = task.getValue();
                        if (!apiResponse.isError()) {
                            Frontend.dataStorage.put("session", apiResponse.data());
                            Frontend.reset("main");
                        } else {
                            Frontend.pushPopup(
                                    switch (apiResponse.code()) {
                                        case UNAUTHORIZED -> "Los datos ingresados son incorrectos";
                                        default -> "Hubo un error inesperado";
                                    }
                            );

                        }
                    });
                }, "/api/auth/login", new LoginRequestDTO(this.usernameField.getText(), this.passwordField.getText()),
                new ParameterizedTypeReference<JwtDTO>() {}
        );

    }

    public void createAccountRedirect(MouseEvent mouseEvent) {
        Frontend.reset("registration_screen");
    }
}
