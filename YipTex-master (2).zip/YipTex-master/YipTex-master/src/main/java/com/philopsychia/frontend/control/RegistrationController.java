package com.philopsychia.frontend.control;

import com.philopsychia.frontend.Frontend;
import com.philopsychia.frontend.data_store.FirstPhaseRegistrationData;
import com.philopsychia.frontend.util.ScreenUtil;
import com.philopsychia.frontend.util.TransitionUtil;
import com.philopsychia.shared.Regexes;
import javafx.animation.*;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Paint;
import org.controlsfx.control.textfield.CustomTextField;

public class RegistrationController {

    private static final Paint START_COLOR = Paint.valueOf("000000FF");
    private static final Paint HOVER_COLOR = Paint.valueOf("D0D0D0FF");

    private static final CornerRadii radii = new CornerRadii(15);

    private static final String MALFORMED_NAME = "Solo caracteres de un alfabeto, apostrofes, guiones y espacios";
    private static final String MALFORMED_SURNAME = "Solo caracteres de un alfabeto, apostrofes y guiones";

    public Button next;
    public VBox nameVBox;
    public CustomTextField nameField;
    public VBox paternalSurnameVBox;
    public CustomTextField paternalSurnameField;
    public VBox maternalSurnameVBox;
    public CustomTextField maternalSurnameField;
    public Button returnButton;

    public RegistrationController() {}


    @FXML
    private void initialize() {
        TransitionUtil.applyHoverTransition(next, START_COLOR, HOVER_COLOR);
    }

    public void tryNext(MouseEvent mouseEvent) {
        cleanGUI();

        boolean passed = true;

        String name = nameField.getText().trim();
        if (!Regexes.nameRegex.matcher(name).matches()) {
            nameVBox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_NAME));
            passed = false;
        }

        String paternalSurname = paternalSurnameField.getText().trim();
        if (!Regexes.surnameRegex.matcher(paternalSurname).matches()) {
            paternalSurnameVBox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_SURNAME));
            passed = false;
        }

        String maternalSurname = maternalSurnameField.getText().trim();
        if (!Regexes.surnameRegex.matcher(maternalSurname).matches()) {
            maternalSurnameVBox.getChildren().add(ScreenUtil.generateErrorMessage(MALFORMED_SURNAME));
            passed = false;
        }

        if (!passed) return;

        Frontend.dataStorage.put("first_stage_registration_data", new FirstPhaseRegistrationData(
                name,
                paternalSurname,
                maternalSurname
        ));

        Frontend.push("registration_screen2");
    }

    private void cleanGUI() {
        nameVBox.getChildren().removeIf(node -> (node instanceof HBox));
        paternalSurnameVBox.getChildren().removeIf(node -> (node instanceof HBox));
        maternalSurnameVBox.getChildren().removeIf(node -> (node instanceof HBox));
    }

    public void returnToPrevious(MouseEvent mouseEvent) {
        Frontend.reset("login");
    }
}
