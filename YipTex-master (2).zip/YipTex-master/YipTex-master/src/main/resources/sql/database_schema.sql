CREATE TABLE IF NOT EXISTS account (
    id BINARY(16) PRIMARY KEY,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'student', 'teacher', 'technician') NOT NULL
);

CREATE TABLE IF NOT EXISTS admin_profile (
    account_id BINARY(16) PRIMARY KEY,
    account_username VARCHAR(255) NOT NULL,
    CONSTRAINT fk_admin_profile_account FOREIGN KEY (account_id) REFERENCES account(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS profile (
    account_id BINARY(16) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    paternal_surname VARCHAR(255) NOT NULL,
    maternal_surname VARCHAR(255) NOT NULL,
    institutional_email VARCHAR(255) NOT NULL,
    CONSTRAINT fk_profile_account FOREIGN KEY (account_id) REFERENCES account(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS student_profile (
    account_id BINARY(16) PRIMARY KEY,
    student_id BIGINT NOT NULL UNIQUE,
    CONSTRAINT fk_student_profile_account FOREIGN KEY (account_id) REFERENCES account(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS teacher_profile (
    account_id BINARY(16) PRIMARY KEY,
    rfc CHAR(13) NOT NULL UNIQUE,
    CONSTRAINT fk_teacher_profile_account FOREIGN KEY (account_id) REFERENCES account(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS technician_profile (
    account_id BINARY(16) PRIMARY KEY,
    rfc CHAR(13) NOT NULL UNIQUE,
    CONSTRAINT fk_technician_profile_account FOREIGN KEY (account_id) REFERENCES account(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS class (
    id BINARY(16) PRIMARY KEY,
    name VARCHAR(6) NOT NULL UNIQUE,
    schedule ENUM('morning', 'evening') NOT NULL,
    primary_teacher_id BINARY(16) NULL,
    CONSTRAINT fk_class_primary_teacher FOREIGN KEY (primary_teacher_id) REFERENCES account(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS student_class (
    user_id BINARY(16) NOT NULL,
    class_id BINARY(16) NOT NULL,
    PRIMARY KEY (user_id, class_id),
    CONSTRAINT fk_student_class_student FOREIGN KEY (user_id) REFERENCES account(id) ON DELETE CASCADE,
    CONSTRAINT fk_student_class_class FOREIGN KEY (class_id) REFERENCES class(id) ON DELETE CASCADE

);

CREATE TABLE IF NOT EXISTS pending_student_class (
    user_id BINARY(16) NOT NULL,
    class_id BINARY(16) NOT NULL,
    PRIMARY KEY (user_id, class_id),
    CONSTRAINT fk_pending_student_class_student FOREIGN KEY (user_id) REFERENCES account(id) ON DELETE CASCADE,
    CONSTRAINT fk_pending_student_class_class FOREIGN KEY (class_id) REFERENCES class(id) ON DELETE CASCADE
    );

CREATE TABLE IF NOT EXISTS auxiliary_teacher_class (
    user_id BINARY(16) NOT NULL,
    class_id BINARY(16) NOT NULL,
    PRIMARY KEY (user_id, class_id),
    CONSTRAINT fk_auxiliary_teacher_class_teacher FOREIGN KEY (user_id) REFERENCES account(id) ON DELETE CASCADE,
    CONSTRAINT fk_auxiliary_teacher_class_class FOREIGN KEY (class_id) REFERENCES class(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS room (
    id BINARY(16) PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    location VARCHAR(255) NOT NULL,
    acronym VARCHAR(255) NOT NULL UNIQUE,
    device_amount INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS device (
    id BINARY(16) PRIMARY KEY,
    number_id INTEGER NOT NULL,
    room_id BINARY(16) NOT NULL,
    CONSTRAINT fk_device_room FOREIGN KEY (room_id) REFERENCES room(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS schedule (
    id BINARY(16) PRIMARY KEY,
    class_id BINARY(16) NOT NULL,
    room_id BINARY(16) NOT NULL,
    weekday ENUM('monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday') NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    CONSTRAINT chk_time CHECK (end_time > start_time),
    CONSTRAINT fk_schedule_class FOREIGN KEY (class_id) REFERENCES class(id) ON DELETE CASCADE,
    CONSTRAINT fk_schedule_room FOREIGN KEY (room_id) REFERENCES room(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS ticket (
    id BINARY(16) PRIMARY KEY,
    created_by BINARY(16) NOT NULL,
    device_id BINARY(16) NOT NULL,
    description TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status ENUM('open', 'in_progress', 'resolved', 'closed') NOT NULL,
    CONSTRAINT fk_ticket_created_by FOREIGN KEY (created_by) REFERENCES account(id) ON DELETE CASCADE,
    CONSTRAINT fk_ticket_device FOREIGN KEY (device_id) REFERENCES device(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS device_assignment_log (
    id BINARY(16) PRIMARY KEY,
    user_id BINARY(16) NOT NULL,
    device_id BINARY(16) NOT NULL,
    class_id BINARY(16) NOT NULL,
    assigned_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    assignment_reason TEXT NULL,
    CONSTRAINT fk_dal_student FOREIGN KEY (user_id) REFERENCES account(id) ON DELETE CASCADE,
    CONSTRAINT fk_dal_device FOREIGN KEY (device_id) REFERENCES device(id) ON DELETE CASCADE,
    CONSTRAINT fk_dal_class FOREIGN KEY (class_id) REFERENCES class(id) ON DELETE CASCADE
    );